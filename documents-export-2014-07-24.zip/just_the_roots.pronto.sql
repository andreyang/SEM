
column a new_val dd;
column b new_val mm;
column c new_val ww;
column d new_val yest;

select
  '&&1' a,
  to_char(to_date('&&1','yyyymmdd'),'yyyymm')||'01' b,
  to_char(next_day(to_date('&&1','yyyymmdd'),'sun')-7,'yyyymmdd') c,
  to_char(to_date('&&1','yyyymmdd')-1,'yyyymmdd') d
from dual
;

drop table ap_temp_ml_root_pgtype purge;
drop table ap_temp_semlprt purge;
drop table ap_temp_ml_root purge;
drop table ap_temp_allroots purge;
drop table ap_temp_twiturl purge;

set serveroutput on;
set trimspool on;
set heading off;
set linesize 255;
whenever sqlerror exit;
spool /home/dw/apicker/Logs/summary_job.pronto.log;

-----------------------------------------------------------------------------------------
-- START 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' START roots' from dual;

create table ap_temp_ml_root nologging as
select distinct 
  nvl(rt.siteid,1) siteid,
  rt.channel, rt.featuremodule type, rt.partner, rt.snippetid,
  rt.requestid, rt.cookieid, rt.ipaddress, rt.micrositein, rt.userid,
  rt.adid, rt.creativeid, rt.ovraw, rt.ovkey, rt.ovmtc, rt.ovkwid, rt.site,
  rt.pmatchtype, rt.pnetwork, rt.ptype, rt.prandom, rt.ptarget, rt.paceid,
  rt.pmobile, rt.pkeywordid, rt.pcampaignid, rt.padgroupid, rt.pkeyword, rt.pfeedid,
  rt.timestamp2, rt.insertdate, rt.abtestingid, rt.countrycode,
  rt.browseid, rt.hasadsponsor, rt.keyword, 
  nvl(rt.isfirstvisit,1) isfirstvisit, rt.fvaction
from 
  dw.roots partition (part_&&yest) rt, 
  stg.comm_all_request partition (part_&&mm) ar
where ar.rootid = rt.requestid
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
;

alter table ap_temp_ml_root modify
 (insertdate date default sysdate,
  siteid number default 1)
;

-----------------------------------------------------------------------------------------
-- All Roots 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' All Roots' from dual;

create table ap_temp_allroots nologging as
select rootid, nvl(max(isfirstvisit),1) isfirstvisit, max(fvaction) fvaction
from stg.comm_all_request partition (part_&&mm)
where rootid is not null
and timestamp2 >= to_date('&&dd','yyyymmdd')
and timestamp2  < to_date('&&dd','yyyymmdd')+1
group by rootid
;

alter table ap_temp_allroots
add constraint tmpallrt_pk
primary key (rootid)
using index tablespace temp_index
;

analyze table ap_temp_allroots compute statistics for table for all indexes for all indexed columns
;

-----------------------------------------------------------------------------------------
-- Page Type 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' Page Type' from dual;

create table ap_temp_ml_root_pgtype nologging as
with srch_adspon as
 (select distinct requestid
  from stg.comm_search_adsponsor partition (part_&&mm)
  where timestamp2 >= to_date('&&dd','yyyymmdd')
  and timestamp2 < to_date('&&dd','yyyymmdd')+1)
select
  s.requestid, 1 siteid, userid,
  s.pagetype pgtype, s.pagenumber, s.snippettrackingid snippetid,
  creativeid, coalesce(disambiguationcategoryid,topdisambiguationoption,'v1') browseid, ovraw, ovkey, ovmtc, ovkwid, micrositeid,
  pmatchtype, pnetwork, ptype, prandom, ptarget, paceid, pmobile, pkeywordid, pcampaignid, padgroupid, pkeyword, pfeedid,
  substrb(site,1,255) site, s.abtestingid, substrb(s.keyword,1,50) keyword,
  altsearch, numsearchhits searchdepth,
  decode(a.requestid,null,0,1) hasadsponsor
from stg.comm_search_header partition (part_&&mm) s, srch_adspon a
where s.requestid = a.requestid(+)
and s.timestamp2 >= to_date('&&dd','yyyymmdd')
and s.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  requestid, 1 siteid, userid,
  decode(nvl(merchantproductid,0),0,'cg','sg') pgtype, c.pagenumber, null snippetid,
  creativeid, nvl(disambiguationcategoryid,'v1') browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  substrb(site,1,255) site, c.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.comm_grid_header partition (part_&&mm) c
where c.timestamp2 >= to_date('&&dd','yyyymmdd')
and c.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  requestid, 1 siteid, userid,
  'br' pgtype, null pagenumber, null snippetid,
  null creativeid, browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, b.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.comm_browse_header b
where b.timestamp2 >= to_date('&&dd','yyyymmdd')
and b.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  requestid, 1 siteid, max(userid),
  'hp' pgtype, null pagenumber, null snippetid,
  null creativeid, max(nvl(disambiguationcategoryid,'v1')) browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, max(micrositeid) micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, max(h.abtestingid) abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.comm_homepage_header partition (part_&&mm) h
where h.timestamp2 >= to_date('&&dd','yyyymmdd')
and h.timestamp2 < to_date('&&dd','yyyymmdd')+1
group by requestid
UNION ALL
select
  requestid, 1 siteid, userid,
  'bp' pgtype, null pagenumber, null snippetid,
  null creativeid, null browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, b.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.comm_brand_header b
where b.timestamp2 >= to_date('&&dd','yyyymmdd')
and b.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  requestid, 1 siteid, userid,
  'pr' pgtype, null pagenumber, null snippetid,
  null creativeid, null browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, null micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, p.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.comm_profile p
where p.timestamp2 >= to_date('&&dd','yyyymmdd')
and p.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  requestid, 1 siteid, userid,
  'bg' pgtype, null pagenumber, null snippetid,
  null creativeid, null browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, null micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, g.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.buying_guide g
where g.timestamp2 >= to_date('&&dd','yyyymmdd')
and g.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  requestid, 1 siteid, userid,
  decode(nr.type,'community.account.registration.CompatibilitySurveyPayoffResponse','pop','rf') pgtype, null pagenumber, null snippetid,
  null creativeid, null browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, null micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, nr.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.new_registration nr
where nr.timestamp2 >= to_date('&&dd','yyyymmdd')
and nr.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  bl.requestid, 1 siteid, bl.userid,
  'lcl' pgtype, null pagenumber, null snippetid,
  null creativeid, null browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, null micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, bl.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.browse_local partition (part_&&mm) bl
where bl.timestamp2 >= to_date('&&dd','yyyymmdd')
and bl.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  lp.requestid, 1 siteid, lp.userid,
  'lcl' pgtype, null pagenumber, null snippetid,
  null creativeid, null browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, null micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  null site, lp.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.local_products partition (part_&&mm) lp
where lp.timestamp2 >= to_date('&&dd','yyyymmdd')
and lp.timestamp2 < to_date('&&dd','yyyymmdd')+1
UNION ALL
select
  ar.requestid, 1 siteid, ar.userid,
  decode(ar.type,
    'SeasonalPageResponse','ss',
    'community.MerchantOverviewResponse','str',
    'ListViwerResponse','lst',
    'NotFoundResponse','404',
    'ProductRedirectionResponse','re') pgtype, 
  null pagenumber, null snippetid,
  ar.creativeid, null browseid, null ovraw, null ovkey, null ovmtc, null ovkwid, micrositeid,
  null pmatchtype, null pnetwork, null ptype, null prandom, null ptarget, null paceid, null pmobile, null pkeywordid, null pcampaignid, null padgroupid, null pkeyword, null pfeedid,
  site, ar.abtestingid, null keyword,
  null altsearch, 0 searchdepth,
  0 hasadsponsor
from stg.comm_all_request partition (part_&&mm) ar
where ar.type in 
 ('SeasonalPageResponse'
 ,'community.MerchantOverviewResponse'
 ,'ListViwerResponse'
 ,'NotFoundResponse'
 ,'ProductRedirectionResponse')
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
;

create unique index tempmlrtpgtype_idx
on ap_temp_ml_root_pgtype(requestid)
logging
tablespace temp_index
;

analyze table ap_temp_ml_root_pgtype
compute statistics
;

-----------------------------------------------------------------------------------------
-- InterCo
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' InterCo' from dual;

insert into ap_temp_ml_root
 (siteid,
  channel, type, partner,
  requestid, cookieid, ipaddress,
  micrositein,
  adid, creativeid, site,
  pmatchtype, pnetwork, ptype, prandom,
  ptarget, paceid, pcampaignid, padgroupid, pkeyword,
  timestamp2, insertdate,
  abtestingid, countrycode)
select
  22,
  rt.channel, rt.featuremodule, rt.partner,
  ar.requestid, ar.cookieid, ar.ipaddress,
  decode(ar.papipartnerid,'20120106-FINECOMB','finecomb','pronto'),
  rt.adid, rt.creativeid, rt.site,
  rt.pmatchtype, rt.pnetwork, rt.ptype, rt.prandom,
  rt.ptarget, rt.paceid, rt.pcampaignid, rt.padgroupid, rt.pkeyword,
  ar.timestamp2, rt.insertdate,
  nvl(rt.abtestingid,0), ar.countrycode
from stg.comm_all_request partition (part_&&mm) ar, dw.fc_pronto_roots partition (part_&&dd) rt
where ar.parentid = rt.requestid
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
;

insert into ap_temp_ml_root
 (siteid,
  channel, type, partner,
  requestid, cookieid, ipaddress,
  micrositein,
  adid, creativeid, site,
  pmatchtype, pnetwork, ptype, prandom,
  ptarget, paceid, pcampaignid, padgroupid, pkeyword,
  timestamp2, insertdate,
  abtestingid, countrycode)
select
  10,
  rt.channel, rt.featuremodule, rt.partner,
  ar.requestid, ar.cookieid, ar.ipaddress,
  decode(ar.type,'ProductRedirectionResponse','allblox','pronto'),
  rt.adid, rt.creativeid, rt.site,
  rt.pmatchtype, rt.pnetwork, rt.ptype, rt.prandom,
  rt.ptarget, rt.paceid, null pcampaignid, null padgroupid, rt.pkeyword,
  ar.timestamp2, rt.insertdate,
  nvl(rt.abtestingid,0), ar.countrycode
from stg.comm_all_request partition (part_&&mm) ar, dw.ab_pronto_roots partition (part_&&dd) rt
where ar.parentid = rt.requestid
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
;

insert into ap_temp_ml_root
 (siteid,
  channel, type,
  requestid, cookieid, ipaddress,
  micrositein,
  adid, abtestingid,
  timestamp2)
select
  301,
  rt.channel, rt.featuremodule,
  ar.requestid, rt.uti, ar.ipaddress,
  'pricefinder',
  rt.adid, rt.abtestingid,
  ar.timestamp2
from stg.comm_all_request partition (part_&&mm) ar, dw.pf_pronto_roots partition (part_&&dd) rt
where ar.parentid = rt.requestid
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
;

--insert into ap_temp_ml_root
-- (siteid,
--  channel, type,
--  requestid, cookieid, ipaddress,
--  micrositein,
--  timestamp2, abtestingid, countrycode)
--select
--  coalesce(
--    rt.siteid,
--    2000+nvl(stg.getnumber(stg.parse_pcn_tracking(ar.papiuserid,'siteid')),1),
--    2001
--  ) siteid,
--  nvl(rt.channel,'other'), nvl(rt.featuremodule,'-'),
--  ar.requestid, ar.cookieid, ar.ipaddress,
--  'pronto',
--  ar.timestamp2, ar.abtestingid, ar.countrycode
--from
--  dw.pcn_roots partition (part_&&dd) rt,
--  stg.comm_all_request partition (part_&&mm) ar
--where exists
-- (select /*+ dynamic_sampling (ar 3) dynamic_sampling (c 3) */ * 
--  from stg.content_papi_id c
--  where ar.papipartnerid = c.papipartnerid)
--and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
--and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
--and stg.parse_pcn_tracking(ar.papiuserid,'sessionid') = rt.sessionid(+)
--;

commit;
-----------------------------------------------------------------------------------------
-- SEM
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' SEM' from dual;

create table ap_temp_semlprt nologging as
select 
  requestid, adid, creativeid, ovraw, ovkey, ovmtc, ovkwid,
  substrb(site,1,255) site
from stg.comm_sem_landing_page
where timestamp2 >= to_date('&&dd','yyyymmdd')
and   timestamp2  < to_date('&&dd','yyyymmdd')+1
;

alter table ap_temp_semlprt
add constraint tempsemlprt_pk
primary key (requestid)
using index tablespace temp_index
;

insert into ap_temp_ml_root
 (channel,
  partner,  
  type, 
  requestid,
  cookieid,
  micrositein, 
  adid,  
  creativeid, 
  ovraw, 
  ovkey, 
  ovmtc, 
  ovkwid,
  site,
  userid,
  ipaddress,
  timestamp2,
  pmatchtype,
  pnetwork,
  ptype,
  prandom,
  ptarget,
  paceid,
  pmobile,
  pkeywordid,
  pcampaignid,
  padgroupid,
  pkeyword,
  pfeedid,
  countrycode)
with ar as 
 (select /*+ materialize */ *  
  from stg.comm_all_request partition (part_&&mm)  
  where adid is not null
  and type not in (select type from stg.landing_page_exclusion)
  and timestamp2 >= to_date('&&dd','yyyymmdd')
  and timestamp2  < to_date('&&dd','yyyymmdd')+1) 
select
--  decode(ar.papipartnerid,
--    '20090722-GOOGLEGADGETADS','Google Gadget',
--    'SEM') channel,
  'SEM' channel,
  substrb(coalesce(pg.site,lp.site,ar.site,ar.searchengine),1,1000) partner,
  nvl(pg.pgtype,'o') type,
  coalesce(ar.rootid,ar.parentid,ar.requestid) requestid,
  ar.cookieid,
  coalesce(pg.micrositeid,ar.micrositeid) micrositeid,
--  decode(ar.papipartnerid,
--    '20090722-GOOGLEGADGETADS',m.adgroupid||'_gga',
--    ar.adid) adid,
  ar.adid,
  coalesce(pg.creativeid,lp.creativeid) creativeid,
  coalesce(pg.ovraw,lp.ovraw),
  coalesce(pg.ovkey,lp.ovkey),
  coalesce(pg.ovmtc,lp.ovmtc),
  coalesce(pg.ovkwid,lp.ovkwid),
  coalesce(pg.site,lp.site),
  ar.userid,
  ar.ipaddress,
  ar.timestamp2,
  pg.pmatchtype,
  pg.pnetwork,
  pg.ptype,
  pg.prandom,
  pg.ptarget,
  pg.paceid,
  pg.pmobile,
  pg.pkeywordid,
  pg.pcampaignid,
  pg.padgroupid,
  pg.pkeyword,
  pg.pfeedid,
  ar.countrycode
from
  ar,  
--  stg.gga_adgroup_map m,
  ap_temp_ml_root_pgtype pg,
  ap_temp_semlprt lp 
where exists 
 (select null from 
   (select rootid, null requestid 
    from ap_temp_allroots rt 
    UNION ALL
    select null, requestid 
    from ap_temp_semlprt) vw
  where (ar.requestid = vw.rootid or ar.parentid = vw.requestid))
--and replace(ar.adid,'_gga') = m.fingerprint(+)
and ar.parentid = lp.requestid(+)
and ar.requestid = pg.requestid(+)
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (rt 3) */ * from ap_temp_ml_root rt where rt.requestid = ar.requestid)
;

commit;
--**/ 
-----------------------------------------------------------------------------------------
-- Feed Syndication / Affiliate / Marketing 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' Feed Syndication / Affiliate / Marketing' from dual;

insert into ap_temp_ml_root
 (channel,
  partner,
  type,
  requestid,
  cookieid,
  micrositein,
  userid,
  ipaddress,
  timestamp2,
  countrycode)
select
  nvl(p.channel,'Marketing'),
  nvl(p.partner,ar.affiliateid),
  decode(p.affiliateid,
    null,substrb(ar.campaign||'^'||ar.affiliateid||'^'||ar.affiliatesubid||'^'||ar.trackingcode,1,190),
    ar.type),
  ar.requestid,
  ar.cookieid,
  ar.micrositeid,
  decode(p.affiliateid,null,ar.userid),
  ar.ipaddress,
  ar.timestamp2,
  ar.countrycode
from
  stg.comm_all_request partition (part_&&mm) ar,
  stg.syndication_partners p
where
  ar.timestamp2 >= to_date('&&dd','yyyymmdd')
  and ar.timestamp2 < to_date('&&dd','yyyymmdd')+1
  and ar.newsourcetracking = 'true'
  and ar.affiliateid is not null
  and ar.affiliateid = p.affiliateid(+)
  and not exists (select /*+ dynamic_sampling (ar 3)  dynamic_sampling (rt 3) */ * from ap_temp_ml_root rt where requestid = ar.requestid)
  and exists (select /*+ dynamic sampling (ar3) dynamic sampling (rt 3) */ * from ap_temp_allroots rt where rt.rootid = ar.requestid)
;

commit;
--**/ 
-----------------------------------------------------------------------------------------
-- Newsletter 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' Newsletter' from dual;

insert into ap_temp_ml_root
 (channel, 
  type, 
  requestid, 
  cookieid,
  micrositein,
  userid,
  ipaddress,
  timestamp2,
  countrycode)
select
  'Newsletter',
  ar.parentid,
  ar.requestid,
  ar.cookieid,
  ar.micrositeid,
  nvl(ar.userid,ar.softuserid),
  ar.ipaddress,
  ar.timestamp2,
  ar.countrycode
from 
  stg.comm_all_request partition (part_&&mm) ar
where
  ar.timestamp2 >= to_date('&&dd','yyyymmdd')
  and ar.timestamp2 < to_date('&&dd','yyyymmdd')+1
  and ar.parentid like 'newsletter%'
  and not exists (select /*+ dynamic_sampling (ar 3)  dynamic_sampling (rt 3) */ * from ap_temp_ml_root rt where requestid = ar.requestid)
;

commit;
--**/ 
-----------------------------------------------------------------------------------------
-- Invitee 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' Invitee' from dual;

insert into ap_temp_ml_root
 (channel, 
  type, 
  requestid, 
  cookieid,
  micrositein,
  ipaddress,
  timestamp2,
  countrycode)
select
  'Invitee',
  f.fromuserid,
  ar.requestid,
  ar.cookieid,
  ar.micrositeid,
  ar.ipaddress,
  ar.timestamp2,
  ar.countrycode
from
  stg.comm_all_request partition (part_&&mm) ar,
 (select nr.fromuserid, nr.requestid
  from stg.new_registration nr
  where nr.timestamp2 >= to_date('&&dd','yyyymmdd')
  and nr.timestamp2 < to_date('&&dd','yyyymmdd')+1
  and nr.fromuserid != 0
  UNION ALL 
  select rf.fromuserid, rf.requestid
  from stg.registration_form rf
  where rf.timestamp2 >= to_date('&&dd','yyyymmdd')
  and rf.timestamp2 < to_date('&&dd','yyyymmdd')+1
  and rf.fromuserid != 0
  UNION ALL
  select fr.fromuserid, fr.requestid
  from stg.friend_response fr
  where fr.timestamp2 >= to_date('&&dd','yyyymmdd')
  and fr.timestamp2 < to_date('&&dd','yyyymmdd')+1
  and fr.fromuserid != 0) f
where 
  f.requestid = ar.requestid
  and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
  and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
  and not exists (select /*+ dynamic_sampling (ar 3)  dynamic_sampling (rt 3) */ * from ap_temp_ml_root rt where requestid = ar.requestid)
  and exists (select /*+ dynamic sampling (ar3) dynamic sampling (rt 3) */ * from ap_temp_allroots rt where rt.rootid = ar.requestid)
;
	
commit;
--**/ 
-----------------------------------------------------------------------------------------
-- PAPI 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' PAPI' from dual;

insert into ap_temp_ml_root
 (channel,
  partner,
  type,
  requestid,
  cookieid,
  micrositein,
  ipaddress,
  timestamp2,
  countrycode)
select
  nvl(c.channel,'PAPI'),
  ar.papipartnerid||'^'||ar.papiuserid,
  case
    when ar.papipartnerid = '20061004-PRONTOINC'
      or ar.papiuserid = 'test'
      or ar.papiuserid like '%eval%'
      then 'invalid'
    else substrb((ar.querystring||'^'||ar.pagelocation),1,50) end -- keyword^querytype 
  ,
  ar.requestid,
  ar.cookieid,
  ar.micrositeid,
  ar.ipaddress,
  ar.timestamp2,
  ar.countrycode
from
  stg.content_papi_id c,
  stg.comm_all_request partition (part_&&mm) ar
where
  ar.timestamp2 >= to_date('&&dd','yyyymmdd')-1
  and ar.timestamp2 < to_date('&&dd','yyyymmdd')+1
  and ar.papipartnerid is not null
  and ar.papipartnerid = c.papipartnerid(+)
  and not exists (select /*+ dynamic_sampling (ar 3)  dynamic_sampling (rt 3) */ * from ap_temp_ml_root rt where requestid = ar.requestid)
  and exists (select /*+ dynamic sampling (ar3) dynamic sampling (rt 3) */ * from ap_temp_allroots rt where rt.rootid = ar.requestid)
;
	
commit;
--**/ 
-----------------------------------------------------------------------------------------
-- SEO 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' SEO' from dual;

insert into ap_temp_ml_root
 (channel, 
  type, 
  partner, 
  requestid, 
  cookieid,
  micrositein,
  ipaddress,
  timestamp2,
  countrycode)
with fr as 
 (select /*+ materialize */
    requestid,
    substr(url,cd,instr(url,'&',cd)-cd) pos
  from
   (select
      requestid, fullreferrer||'&' url,
      decode(instr(fullreferrer,'&'||'cd='),0,decode(instr(fullreferrer,'?cd='),0,-4,instr(fullreferrer,'?cd=')),instr(fullreferrer,'&'||'cd='))+4 cd
    from stg.full_referrer partition (part_&&ww)
    where timestamp2 >= to_date('&&dd','yyyymmdd')
    and timestamp2 < to_date('&&dd','yyyymmdd')+1
    and fullreferrer like '%google%')
  where cd != 0)
select
  'SEO',
  substrb(fr.pos||'^'||nvl(pg.pgtype,'o')||'^'||nvl(pg.keyword,ar.querystring),1,90),
  se.searchengine,
  ar.requestid,
  ar.cookieid,
  ar.micrositeid,
  ar.ipaddress,
  ar.timestamp2,
  ar.countrycode
from
  ap_temp_ml_root_pgtype pg,
  stg.seo_engines se,
  stg.comm_all_request partition (part_&&mm) ar,
  fr
where
  ar.timestamp2 >= to_date('&&dd','yyyymmdd')
  and ar.timestamp2 < to_date('&&dd','yyyymmdd')+1
  and ar.type not in (select type from stg.landing_page_exclusion)
  and ar.querystring is not null
  and ar.searchengine = se.searchengine
  and ar.requestid = pg.requestid(+)
  and ar.requestid = fr.requestid(+)
  and not exists (select /*+ dynamic_sampling (ar 3)  dynamic_sampling (rt 3) */ * from ap_temp_ml_root rt where requestid = ar.requestid)
  and exists (select /*+ dynamic sampling (ar3) dynamic sampling (rt 3) */ * from ap_temp_allroots rt where rt.rootid = ar.requestid)
;
	
commit; 
--**/ 
-----------------------------------------------------------------------------------------
-- Papi Widget / Social Media / Referral / Blogs / Direct / App 
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' Papi Widget / Social Media / Direct / App' from dual;

create table ap_temp_twiturl nologging as
select '1' requestid, '1' url from dual;
--from stg.comm_url partition (part_&&ww) u
--where pagelocation = 'twitter'
--and timestamp2 >= to_date('&&dd','yyyymmdd')
--and timestamp2 < to_date('&&dd','yyyymmdd')+1
--;

analyze table ap_temp_twiturl compute statistics
;

insert into ap_temp_ml_root
 (channel,
  type,
  partner,
  requestid,
  cookieid,
  micrositein,
  userid,
  ipaddress,
  timestamp2,
  countrycode)
select
  case
    when se.channel is not null then se.channel
    when ar.pagelocation = 'twitter' then 'Social Media'
    when ar.type = 'search.ProductsOnlySearchResponse' 
      or ar.pagelocation like 'WebbAcc%' then 'APP'
    when ar.machineid is not null then 'APP'
    else 'DIRECT'
  end channel,
  substr(case
    when se.channel is not null then decode(se.channel,'Referral',ar.querystring,nvl(pg.pgtype,ar.type))
    when ar.pagelocation = 'twitter' then t.url||'^'||nvl(pg.pgtype,ar.type)
    when ar.type = 'search.ProductsOnlySearchResponse' then ar.type 
    when ar.pagelocation like 'WebAcc%' then ar.pagelocation||'^'||nvl(pg.pgtype,ar.type)
    else nvl(pg.pgtype,ar.type)
  end,1,200) type,
  case
    when se.channel is not null then se.displayname
    when ar.pagelocation = 'twitter' then 'twitter.com'
    when ar.type = 'search.ProductsOnlySearchResponse' 
      or ar.pagelocation like 'WebAcc%' then 'WebAcc'
    when ar.machineid is not null then ar.bhoname
    else null
  end partner,
  ar.requestid,
  ar.cookieid,
  ar.micrositeid,
  ar.userid,
  ar.ipaddress,
  ar.timestamp2,
  ar.countrycode
from
  ap_temp_ml_root_pgtype pg,
  ap_temp_twiturl t,
  stg.comm_all_request partition (part_&&mm) ar,
-- (select 
--    requestid,
--    decode(responsetype,
--      1,'sub_toast',
--      2,'sub_toast',
--      3,'sub_toast',
--      5,'sub_toast',
--      0,'compare_toast',
--      4,'compare_toast',
--      6,'compare_toast') rt
--  from stg.product_detail
--  where timestamp2 >= to_date('&&dd','yyyymmdd')-1
--  and timestamp2 < to_date('&&dd','yyyymmdd')+1) pd, 
 (select 'PAPI-widget' channel, searchengine, displayname
  from stg.widget_engines
  where status = 'A'
  UNION ALL
  select 'Referral' channel, searchengine, searchengine 
  from stg.referral_engines
  where status = 'A'
  UNION ALL
  select channel, searchengine, searchengine
  from stg.social_media_engines
  where status = 'A') se
where
  ar.timestamp2 >= to_date('&&dd','yyyymmdd')
  and ar.timestamp2 < to_date('&&dd','yyyymmdd')+1
--  and ar.requestid = pd.requestid(+)
  and ar.requestid = pg.requestid(+)
  and ar.requestid = t.requestid(+)
  and ar.searchengine = se.searchengine(+)
  and not exists (select /*+ dynamic_sampling (ar 3)  dynamic_sampling (rt 3) */ * from ap_temp_ml_root rt where requestid = ar.requestid)
  and exists (select /*+ dynamic sampling (ar3) dynamic sampling (rt 3) */ * from ap_temp_allroots rt where rt.rootid = ar.requestid)
;

commit;
--**/ 
-----------------------------------------------------------------------------------------
-- dw.roots  
-----------------------------------------------------------------------------------------
select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' dw.roots' from dual;

create index ap_temp_ml_root$id on ap_temp_ml_root (requestid) tablespace temp_index;
analyze table ap_temp_ml_root compute statistics;

declare
  xdrop varchar2(25);
  xadd varchar2(25);
begin

  select 'part_'||to_char(add_months(to_date('&&dd','yyyymmdd'),-24),'yyyymmdd')
  into xdrop
  from dual;

  select 'part_'||to_char(to_date('&&dd','yyyymmdd'),'yyyymmdd')
  into xadd
  from dual;

  begin
    dbms_output.put_line('alter table dw.roots drop partition '||xdrop);
    execute immediate 'alter table dw.roots drop partition '||xdrop;
  exception when others then null;
  end;

  begin
    dbms_output.put_line('alter table dw.roots drop partition '||xadd);
    execute immediate 'alter table dw.roots drop partition '||xadd;
  exception when others then null;
  end;

  begin
    dbms_output.put_line('alter table dw.roots add partition '||xadd||' values (to_date('||to_char(to_date('&&dd','yyyymmdd'),'yyyymmddhh24miss')||',''yyyymmddhh24miss''))');
    execute immediate 'alter table dw.roots add partition '||xadd||' values (to_date('||to_char(to_date('&&dd','yyyymmdd'),'yyyymmddhh24miss')||',''yyyymmddhh24miss''))';
  exception when others then
    dbms_output.put_line('PARTITION ERROR (3): dw.roots: '||substrb(sqlerrm,1,210));
  end;

exception when others then
  dbms_output.put_line('PARTITION ERROR (4): dw.roots: '||substrb(sqlerrm,1,210));
end;
/

insert into dw.roots partition (part_&&dd)
 (channel, featuremodule, partner, siteid,
  requestid, cookieid, ipaddress, micrositein, userid,
  adid, creativeid, ovraw, ovkey, ovmtc, ovkwid, site,
  timestamp2, insertdate, rootdate,
  browseid, pgtype, abtestingid,
  altsearch, searchdepth, snippetid,
  pmatchtype, pnetwork, ptype, prandom, ptarget, paceid, pmobile, pkeywordid, pcampaignid, padgroupid, pkeyword, pfeedid,
  countrycode, hasadsponsor, 
  keyword, isfirstvisit, fvaction)
select
  r.channel, r.type, r.partner, r.siteid,
  r.requestid, r.cookieid, r.ipaddress, r.micrositein, r.userid,
  r.adid, r.creativeid, r.ovraw, r.ovkey, r.ovmtc, r.ovkwid, r.site,
  r.timestamp2, r.insertdate, to_date('&&dd','yyyymmdd'),
  nvl(p.browseid,r.browseid), substr(p.pgtype,1,10), decode(nvl(r.siteid,1),1,nvl(p.abtestingid,r.abtestingid),nvl(r.abtestingid,p.abtestingid)),
  substr(nvl(p.altsearch,'false'),1,10), nvl(p.searchdepth,0), nvl(r.snippetid,p.snippetid),
  nvl(r.pmatchtype,p.pmatchtype), nvl(r.pnetwork,p.pnetwork), nvl(r.ptype,p.ptype), nvl(r.prandom,p.prandom), 
  nvl(r.ptarget,p.ptarget), nvl(r.paceid,p.paceid), nvl(r.pmobile,p.pmobile), nvl(r.pkeywordid,p.pkeywordid), 
  nvl(r.pcampaignid,p.pcampaignid), nvl(r.padgroupid,p.padgroupid), nvl(r.pkeyword,p.pkeyword), nvl(r.pfeedid,p.pfeedid),
  r.countrycode, coalesce(r.hasadsponsor,p.hasadsponsor,0), 
  substr(nvl(r.keyword,p.keyword),1,50), 
  nvl(greatest(r.isfirstvisit,ar.isfirstvisit),1), nvl(r.fvaction,ar.fvaction)
from ap_temp_ml_root r, ap_temp_ml_root_pgtype p, ap_temp_allroots ar
where r.requestid = p.requestid(+)
and r.requestid = ar.rootid(+)
;

commit;

drop table ap_temp_twiturl purge;

spool off;
quit;
--**/ 

/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************/ 
/******************************************************************* 
      OLD CHANNELS 
	   
2/19/2010  
--CPU  

insert into ap_temp_ml_root
 
(channel,  
  partner,  
  type,  
  requestid,  
  cookieid, 
  priority, 
  ipaddress, 
  timestamp2) 
select 
  'CPU', 
  max(cpu.partnerid||'^'||cpu.publisher), 
  decode(max(cpu.isunique),'true','unique','golden')||'^'||max(cpu.whichtab)||'^'||max(unitsize)||'^'||decode(max(unittype),'campaign','campaign',max(querystring))||'^'||max(unitstyle)||'^'||max(colorscheme)||'^'||max(productid), 
  cpu.parentid, 
  null cookieid, 
  90, 
  max(cpu.ipaddress), 
  min(cpu.timestamp2) 
from 
  stg.contextual_product_unit cpu 
where 
  cpu.timestamp2 >= to_date('&&dd','yyyymmdd') 
  and cpu.timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and cpu.type = 'productClick' 
  and cpu.ispreview = 'false' 
group by cpu.parentid 
; 
--CPU 

02/19/2010
 
-Affiliate 
insert into ap_temp_ml_root 
 (channel,  
  partner,  
  type,  
  requestid, 
  cookieid, 
  micrositein, 
  priority,  
  ipaddress, 
  timestamp2) 
select 
  'Affiliate', 
  af.affiliateid||'^'||af.affiliatesubid||'^'||af.trackingdata, 
  decode(pd.responsetype,null,'search',1,'sub_toast',2,'sub_toast',3,'sub_toast',5,'sub_toast',0,'compare_toast',4,'compare_toast',6,'compare_toast','homepage'), 
  af.requestid, 
  null cookieid, 
  null, 
  90, 
  af.ipaddress, 
  af.timestamp2 
from 
  stg.affiliate_redirect af, 
  stg.product_detail pd 
where 
  af.timestamp2 >= to_date('&&dd','yyyymmdd') 
  and af.timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and af.requestid = pd.requestid(+) 
  and not exists (select * from ap_temp_ml_root where requestid = af.requestid) 
UNION ALL 
select 
  'Affiliate', 
  substrb(h.affiliateid||'^'||h.affiliatesubid||'^'||h.trackingcode,1,2000), 
  'search',  
  h.requestid, 
  h.cookieid, 
  ar.micrositeid, 
  40, 
  h.ipaddress, 
  h.timestamp2 
from 
  stg.comm_search_header h, 
  stg.comm_all_request ar 
where 
  h.timestamp2 >= to_date('&&dd','yyyymmdd') 
  and h.timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and ar.timestamp2 >= to_date('&&dd','yyyymmdd') 
  and ar.timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and h.requestid = ar.requestid 
  and ar.requestid = ar.rootid 
  and ar.newsourcetracking = 'true' 
  and h.affiliateid is not null 
  and h.adid is null 
  and not exists (select * from ap_temp_ml_root where requestid = h.requestid) 
; 
--Affiliate 

02/19/2010
 
- DRDM (direct response display media) 
insert into ap_temp_ml_root 
 (channel,  
  partner,  
  type,  
  requestid,  
  cookieid, 
  micrositein, 
  priority,  
  ipaddress, 
  timestamp2) 
select 
  'DRDM', 
  ar.affiliateid, 
  substrb(ar.campaign||'^'||ar.affiliateid||'^'||ar.affiliatesubid||'^'||ar.trackingcode,1,60), 
  ar.requestid, 
  ar.cookieid, 
  ar.micrositeid, 
  30, 
  ar.ipaddress, 
  ar.timestamp2 
from 
  stg.comm_all_request ar 
where 
  ar.timestamp2 >= to_date('&&dd','yyyymmdd') 
  and ar.timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and ar.requestid = ar.rootid 
  and ar.campaign = 'drdm' 
  and ar.newsourcetracking = 'true' 
  and not exists (select * from ap_temp_ml_root where requestid = ar.requestid) 
; 
--DRDM 


 
/30/2009 
---TIER2 PPC 
insert into ap_temp_ml_root(channel, partner, type, requestid, adid, priority, iscomm) 
 select 
  'TIER2 PPC', 
  'Kontera', 
  'SEM', 
  requestid, 
  adid, 
  1.6, 
  'false' 
 from 
  stg.all_request ar 
 where 
  timestamp2 >= to_date('&&dd','yyyymmdd') 
  and timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and adid like '%_ko' 
  and requestid = rootid 
  and not exists (select * from ap_temp_ml_root where requestid = ar.requestid) 
 UNION ALL  
 select 
  'TIER2 PPC', 
  'Kontera', 
  'SEM', 
  requestid, 
  adid, 
  1.6, 
  'true' 
 from 
  stg.comm_all_request ar 
 where 
  timestamp2 >= to_date('&&dd','yyyymmdd') 
  and timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and adid like '%_ko' 
  and requestid = rootid 
  and not exists (select * from ap_temp_ml_root where requestid = ar.requestid) 
; 
---TIER2 PPC 


 
/30/2009 
---COBRAND SEM 
insert into ap_temp_ml_root(channel, partner, type, requestid, adid, priority, iscomm) 
 select 
  'COBRAND', 
  'lycos^', 
  'SEM', 
  requestid, 
  adid, 
  1.7, 
  'false' 
 from 
  stg.all_request ar 
 where 
  timestamp2 >= to_date('&&dd','yyyymmdd') 
  and timestamp2 < to_date('&&dd','yyyymmdd')+1 
  and adid like 'ly-%' 
  and requestid = rootid 
  and not exists (select * from ap_temp_ml_root where requestid = ar.requestid) 
; 
---COBRAND SEM  

*******************************************************************/ 
