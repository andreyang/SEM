
column dd new_val dd;
column mm new_val mm;
column wk new_val wk;

select
  '&&1' dd,
  to_char(to_date('&&1','yyyymmdd'),'yyyymm')||'01' mm,
  to_char(next_day(to_date('&&1','yyyymmdd'),'sun')-7,'yyyymmdd') wk
from dual
;

drop table ap_temp_asl_click purge;
drop table ap_temp_rc_pronto purge;
drop table ap_temp_rc_pronto2 purge;
drop table ap_temp_adword_lead_cat purge;
drop table ap_temp_ad_dup purge;

set serveroutput on;
set trimspool on;
set heading off;
set linesize 255;
spool /home/dw/apicker/Logs/adword.pronto.log;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' START adwords' from dual;

--allocate adword clicks to mexp categoryid using product count 

set timing on;

create table ap_temp_ad_dup nologging as
with ad as
 (select requestid, parentid, domain, cookieid, timestamp2
  from stg.comm_adword_click partition (part_&&mm) a
  where not exists (select /*+ dynamic_sampling (a 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = a.ipaddress)  
  and timestamp2 >= to_date('&&dd','yyyymmdd')
  and timestamp2  < to_date('&&dd','yyyymmdd')+1)
select requestid
from ad ad
where exists
 (select *
  from ad ad2 
  where ad2.parentid = ad.parentid
  and ad2.domain = ad.domain
  and ad2.cookieid = ad.cookieid
  and ad2.timestamp2  < ad.timestamp2
  and ad2.timestamp2 >= ad.timestamp2-(5/60/60/24))
;

create table ap_temp_rc_pronto nologging as
select 
  requestid, mexpcategoryid, 
  count(*) prod_ct, 'prod' pagetype
from 
  stg.comm_grid_header partition (part_&&mm) cg, 
  stg.golden_category gc 
where cg.goldencategoryid = gc.goldencategoryid
and cg.timestamp2 >= to_date('&&dd','yyyymmdd')
and cg.timestamp2  < to_date('&&dd','yyyymmdd')+1
group by requestid, mexpcategoryid
UNION ALL
select 
  requestid, mexpcategoryid, 
  sum(prod_ct) prod_ct, max(pagetype) pagetype
from
 (select 
    requestid, mexpcategoryid, 
    count(*) prod_ct, max(decode(pagetype, 'ds', 'prod', 'nonprod')) pagetype
  from stg.comm_search_unique partition (part_&&wk) sc, stg.golden_category gc
  where sc.goldencategoryid = gc.goldencategoryid
  and sc.timestamp2 >= to_date('&&dd','yyyymmdd')
  and sc.timestamp2  < to_date('&&dd','yyyymmdd')+1
  --and DISAMBIGUATIONCATEGORYID is null 
  group by requestid, mexpcategoryid
  union all
  select 
    requestid, mexpcategoryid, 
    count(*) prod_ct, max(decode(pagetype, 'ds', 'prod', 'nonprod')) pagetype
  from stg.comm_search_golden partition (part_&&wk) sc, stg.golden_category gc
  where sc.goldencategoryid = gc.goldencategoryid
  and sc.timestamp2 >= to_date('&&dd','yyyymmdd')
  and sc.timestamp2  < to_date('&&dd','yyyymmdd')+1
  --and DISAMBIGUATIONCATEGORYID is null 
  group by requestid, mexpcategoryid)
group by requestid, mexpcategoryid
;

analyze table ap_temp_rc_pronto compute statistics;

create table ap_temp_rc_pronto2 nologging as
select requestid, sum(prod_ct) prod_ct, max(pagetype) pagetype
from ap_temp_rc_pronto
group by requestid
;

analyze table ap_temp_rc_pronto2 compute statistics;

create table ap_temp_asl_click nologging as
select 
  requestid, timestamp2, parentid, rootid, 
  cobrandid, abtestingid, userid, cookieid, 
  micrositeid micrositeout, countrycode,
  ipaddress
from stg.comm_all_request partition (part_&&mm) ar
where type in ('RedirectionResponse','AdWordRedirectionResponse')
and timestamp2 >= to_date('&&dd','yyyymmdd')
and timestamp2  < to_date('&&dd','yyyymmdd')+1
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = ar.ipaddress) 
;

analyze table ap_temp_asl_click estimate statistics sample 5 percent;

create table ap_temp_adword_lead_cat nologging as
select
  siteid,
  requestid,
  parentid,
  rootid,
  cookieid,
  substrb(channel,1,100) channel,
  substrb(featuremodule,1,200) featuremodule,
  ispuresearch,
  clickdate,
 --content adword click discounted
 --adwowrd from auto disambiguated pages are boosted
  decode(isdup,'y',0,cpc
   *decode(pagetype, 'prod', 1.65, 1)
   *(case 
       when adid like '%_gc' then .65
       when (adid like '%_ms' or adid like '%_m_s') then 1.04
       when adid like '%_ys' then 1.15
       --when adid like '%_ssp' then 1.4  
       when adid like '%_ls' then .25
       when adid like '%_as' then .75  
       when adid like '%_gs' then decode(siteid, 22, .9, 1.05)
       else 1.2
     end)) cpc,
  numclick,
  type,
  pagenumber,
  adid,
  abtestingid,
  mexpcategoryid,
  substrb(partner,1,2000) partner,
  iscomm,
  userid,
  creativeid,
  ovraw,
  ovkey,
  ovmtc,
  ovkwid,
  site,
  pagelocation,
  position,
  domain,
  micrositein,
  micrositeout,
  countrycode,
  padgroupid, pcampaignid, pfeedid, pkeyword, pkeywordid,
  pmatchtype, pmobile, pnetwork, prandom, ptarget, ptype,
  isdup,
  hasadext, adexttype,
  ipaddress,
  isfirstvisit
from
 (select
    max(nvl(rt.siteid,1)) siteid,
    ar.requestid,
    max(ar.parentid) parentid,
    max(ar.rootid) rootid,
    max(ar.cookieid) cookieid,
    max(nvl(rt.channel,'Other')) channel,
    max(nvl(rt.featuremodule,'Other')) featuremodule,
    'n' ispuresearch,
    max(trunc(ar.timestamp2)) clickdate,
    max(nvl(acc.cpc, ac.cpc)) cpc,
    max(nvl(rc.prod_ct/rc2.prod_ct, 1)) numclick,
    max(rc2.pagetype) pagetype,
    nvl(max(pg.pgtype),'o') type,
    max(pg.pagenumber) pagenumber,
    nvl(min(rt.adid),'X') adid,
    min(coalesce(rt.abtestingid,ar.abtestingid,'X')) abtestingid,
    nvl(acc.mexpcategoryid,-99) mexpcategoryid,
    'true' iscomm,
    max(rt.partner) partner,
    max(nvl(ar.userid,rt.userid)) userid,
    max(rt.creativeid) creativeid,
    max(rt.ovraw) ovraw,
    max(rt.ovkey) ovkey,
    max(rt.ovmtc) ovmtc,
    max(rt.ovkwid) ovkwid,
    max(rt.site) site,
    max(cac.pagelocation) pagelocation,
    max(cac.position) position,
    max(cac.domain) domain,
    max(decode(rt.siteid,22,'pronto',10,'pronto',rt.micrositein)) micrositein,
    max(ar.micrositeout) micrositeout,
    max(ar.countrycode) countrycode,
    max(rt.padgroupid) padgroupid,
    max(rt.pcampaignid) pcampaignid, 
    max(rt.pfeedid) pfeedid,
    max(rt.pkeyword) pkeyword, 
    max(rt.pkeywordid) pkeywordid,
    max(rt.pmatchtype) pmatchtype, 
    max(rt.pmobile) pmobile,
    max(rt.pnetwork) pnetwork,
    max(rt.prandom) prandom,
    max(rt.ptarget) ptarget,
    max(rt.ptype) ptype,
    max(decode(dup.requestid,null,'n','y')) isdup,
    max(hasadext) hasadext,
    max(adexttype) adexttype,
    substr(max(ar.ipaddress),1,25) ipaddress,
    nvl(max(rt.isfirstvisit),1) isfirstvisit
  from
    stg.comm_adword_click partition (part_&&mm) cac,
    dw.roots partition (part_&&dd) rt,
    ap_temp_asl_click ar,
    ap_temp_ml_root_pgtype pg,
    stg.adword_cpc ac,
    stg.adword_category_cpc acc,
    ap_temp_rc_pronto rc,
    ap_temp_rc_pronto2 rc2,
    ap_temp_ad_dup dup
  where
    ar.rootid = rt.requestid(+)
    and nvl(rt.featuremodule,'n') != 'invalid'
    and ar.parentid = pg.requestid(+)
    and ar.parentid = rc.requestid(+)
    and nvl(rc.mexpcategoryid,-99) = acc.mexpcategoryid(+)
    and ar.parentid = rc2.requestid(+)
    and ar.requestid = cac.requestid(+)
    and ar.requestid = dup.requestid(+)
  group by ar.requestid, nvl(acc.mexpcategoryid,-99))
where nvl(partner,'null') != 'saleboy^'
and nvl(partner,'null') not like '20070817-SALEBOY%'
;

set timing off;

--9/2/2008 
truncate table dw.adword_lead_category_pronto;

insert into dw.adword_lead_category_pronto
 (siteid, requestid, channel, featuremodule, ispuresearch, clickdate, 
  cpc, 
  numclick, 
  type, pagenumber, adid, abtestingid, mexpcategoryid, partner, iscomm, userid, creativeid,
  pagelocation, position, domain, parentid, rootid, cookieid, ovraw, ovkey, ovmtc, ovkwid, site,
  micrositein, micrositeout, countrycode,
  padgroupid, pcampaignid, pfeedid, pkeyword, pkeywordid,
  pmatchtype, pmobile, pnetwork, prandom, ptarget, ptype,
  isdup,
  hasadext, adexttype,
  ipaddress, isfirstvisit)
select 
  siteid, requestid, channel, featuremodule, ispuresearch, clickdate, 
  decode(t.isdup,'y',0,1)*round(nvl(greatest(nvl(t3.cpc,t2.cpc)-nvl(position/100, 0), 0.05)*0.85, 1.1*t.cpc)*decode(trim(to_char(clickdate, 'DAY')), 'FRIDAY', .97, 'SATURDAY', .96, 'SUNDAY', .96, .98), 4)*decode(replace(lower(t.domain), 'www.', ''), 'local.com', .8, 'target.com', .8, 'target.com/freeshipping', .8, 'ebay.ca', .8, 'ebay.com', .8, 1.0)*(case when t.adid like '%-mbl_gs' then .75 else 1 end),
  numclick,
  substr(t.type, 1, 5), t.pagenumber, t.adid, abtestingid, mexpcategoryid, partner, iscomm, userid, creativeid,
  pagelocation, position, t.domain, t.parentid, t.rootid, t.cookieid, t.ovraw, t.ovkey, t.ovmtc, t.ovkwid, t.site,
  t.micrositein, t.micrositeout, countrycode,
  t.padgroupid, t.pcampaignid, t.pfeedid, t.pkeyword, t.pkeywordid,
  t.pmatchtype, t.pmobile, t.pnetwork, t.prandom, t.ptarget, t.ptype,
  t.isdup,
  t.hasadext, t.adexttype,
  t.ipaddress, t.isfirstvisit
from ap_temp_adword_lead_cat t, dw.adword_adid_cpc t2, dw.adword_adid_cpc t3
where regexp_replace(replace(t.adid, 'RLD-', ''), '(\d)-\d+\D+bmx\D+$', '\1') = t2.adid(+)
and regexp_replace(replace(t.adid, 'RLD-', ''), '(\d)\D+$', '\1') = t3.adid(+)
;

commit;

--truncate table ap_temp_adword_lead_cat; 

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' START adword_lead' from dual;

delete from dw.adword_lead partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 1
and iscomm = 'true'
;

delete from dw.adword_lead partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and micrositein = 'pronto'
;

insert into dw.adword_lead partition (part_&&mm)
 (siteid, requestid, channel, featuremodule, ispuresearch, clickdate,
  cpc, type, pagenumber, adid, abtestingid, partner, iscomm, userid, creativeid,
  pagelocation, position, domain, parentid, rootid, cookieid, ovraw, ovkey, ovmtc, ovkwid, site,
  micrositein, micrositeout, countrycode,
  padgroupid, pcampaignid, pfeedid, pkeyword, pkeywordid,
  pmatchtype, pmobile, pnetwork, prandom, ptarget, ptype,
  isdup, hasadext, adexttype,
  ipaddress, isfirstvisit)
select max(siteid), requestid, max(channel), max(featuremodule), max(ispuresearch), max(clickdate),
  sum(cpc*numclick)/sum(numclick), max(type), max(pagenumber), max(adid), max(abtestingid), max(partner), max(iscomm), max(userid), max(creativeid),
  max(pagelocation), max(position), max(domain), max(parentid), max(rootid), max(cookieid), max(ovraw), max(ovkey), max(ovmtc), max(ovkwid), max(site),
  max(micrositein), max(micrositeout), max(countrycode),
  max(padgroupid), max(pcampaignid), max(pfeedid), max(pkeyword), max(pkeywordid),
  max(pmatchtype), max(pmobile), max(pnetwork), max(prandom), max(ptarget), max(ptype),
  max(isdup), max(hasadext), max(adexttype),
  max(ipaddress), max(isfirstvisit)
from dw.adword_lead_category_pronto
group by requestid
;

commit;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' START adword' from dual;

delete from dw.adword partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 1
and iscomm = 'true'
;

insert into dw.adword partition (part_&&mm)
 (channel, featuremodule, ispuresearch, clickdate, cpc, type, adid, abtestingid, partner, mexpcategoryid, numclick, iscomm, siteid)
select 
  channel, featuremodule, ispuresearch, clickdate, sum(cpc*numclick)/sum(numclick) cpc, type, adid, abtestingid, nvl(partner,'null'), mexpcategoryid, sum(numclick), iscomm, siteid
from dw.adword_lead_category_pronto
where siteid = 1
group by channel, featuremodule, ispuresearch, clickdate, type, adid, abtestingid, nvl(partner,'null'), mexpcategoryid, iscomm, siteid
;

commit;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' START adword_category' from dual;

delete from dw.adword_category partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 1
;

insert into dw.adword_category partition (part_&&mm)
 (clickdate, siteid, mexpcategoryid, channel, numclick, cpc)
select
  clickdate, 1 siteid, mexpcategoryid, channel, 
  sum(numclick), sum(numclick*cpc)/sum(numclick)
from dw.adword_lead_category_pronto
group by clickdate, mexpcategoryid, channel
;

commit;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' START adword_adid' from dual;

delete from dw.adword_adid partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 1
and channel != 'COBRAND'
;

insert into dw.adword_adid partition (part_&&mm)
 (adid, clickdate, channel, 
  numclick, 
  cpc, 
  siteid)
select 
  adid, clickdate, channel,
  round(sum(numclick),2) numclick,
  round(sum(cpc*numclick)/sum(numclick), 4) cpc, 
  siteid
from dw.adword_lead_category_pronto
where siteid = 1
group by adid, clickdate, channel, siteid
;

commit;

spool off;
drop table dw.adword_adid_bid_pronto purge;
spool /home/dw/apicker/Logs/adword.pronto.log append;

/**
create table ayang.ay_msn_ds_adid_boost nologging as
select distinct adid msn_adid
from stg.comm_search_header
where timestamp2 > '11-Oct-2012'
and timestamp2 < '19-Oct-2012'
and adid like '%m_s'
and pagetype = 'ds'
;
analyze table ayang.ay_msn_ds_adid_boost compute statistics;
update dw.adword_adid  
set cpc_actual = 1.4*nvl(cpc_actual, cpc)   
where clickdate between '12-Oct-2012' and '18-Oct-2012'
and siteid = 1
and adid in (select msn_adid from ayang.ay_msn_ds_adid_boost)
;
commit;
drop table ayang.ay_msn_ds_adid_boost purge;
**/

create table dw.adword_adid_bid_pronto nologging as
select 	adid, 
	sum(nvl(cpc_actual, cpc)*numclick) rev8,
	sum(numclick) ad_lead8,
	sum(nvl(cpc_actual, cpc)*(case when clickdate >= trunc(sysdate) - 7 then 1 else 0 end)*numclick) rev1,
	sum(numclick*(case when clickdate >= trunc(sysdate) - 7 then 1 else 0 end)) ad_lead1,
	sum(nvl(cpc_actual, cpc)*(case when clickdate >= trunc(sysdate) - 28 then 1 else 0 end)*numclick) rev4,
	sum(numclick*(case when clickdate >= trunc(sysdate) - 28 then 1 else 0 end)) ad_lead4
from dw.adword_adid ad
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) 
and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and channel = 'SEM'
and siteid = 1
group by adid
;

analyze table dw.adword_adid_bid_pronto estimate statistics sample 20 percent;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' END adwords' from dual;

spool off; 
drop table ap_temp_asl_click purge;
drop table ap_temp_rc_pronto purge;
drop table ap_temp_rc_pronto2 purge;
drop table ap_temp_adword_lead_cat purge;
quit;



