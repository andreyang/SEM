spool /home/dw/ayang/Log/GoogleFeedAPIMerge.log

/**
--remove header rows
create table ay_temp_account_total tablespace stage_temp_data nologging as
select customerid, sum(clicks) clicks
from stg.google_ad_api_daily
group by customerid;
commit;

analyze table ay_temp_account_total compute statistics
;

delete from stg.google_ad_api_daily t
where clicks > (select 0.49*clicks from ay_temp_account_total
where customerid = t.customerid
)
;

commit;

drop table ay_temp_account_total purge;
**/

drop table ay_temp_g_account_search;
create table ay_temp_g_account_search tablespace stage_temp_data nologging as
select distinct clientid, lower(accountname) accountname, accountid
from titan.account@be1
where searchengine = 'Google'
;
commit;

analyze table ay_temp_g_account_search compute statistics
;

delete from stg.google_ad_api where clickdate = to_date('&1', 'yyyy-mm-dd');
delete from stg.google_ad_api_imp where clickdate = to_date('&1', 'yyyy-mm-dd');
commit;

insert into stg.google_ad_api_imp
(
network,
clickdate,
AdGroup,
AdGroupId,
AdWordsType,
AdGroupStatus,
BottomPosition,
DailyBudget,
CampaignStatus,
Campaign,
CampaignId,
Clicks,
Cost,
Cpc,
CreativeStatus,
CreativeType,
CreativeVisionURL,
CreativeId,
Ctr,
DescriptionLine1,
DescriptionLine2,
DestinationUrl,
DescriptionLine3,
Impressions,
Keyword,
MinimumCpc,
KeywordId,
KeywordDestinationUrl,
KeywordStatus,
KeywordType,
MaxContentCPC,
MaximumCpc,
PageViewCount,
AveragePosition,
TopPosition,
Adid,
AccountName,
qualityscore,
customerid, 
accountid
) 
select
network,
startdate,
AdGroup,
AdGroupId,
AdWordsType,
AdGroupStatus,
BottomPosition,
DailyBudget,
CampaignStatus,
Campaign,
CampaignId,
Clicks,
Cost,
Cpc,
CreativeStatus,
CreativeType,
CreativeVisionURL,
CreativeId,
Ctr,
DescriptionLine1,
DescriptionLine2,
DestinationUrl,
DescriptionLine3,
Impressions,
Keyword,
MinimumCpc,
KeywordId,
KeywordDestinationUrl,
KeywordStatus,
KeywordType,
MaxContentCPC,
MaximumCpc,
PageViewCount,
AveragePosition,
TopPosition,
--specifying -1 in instr function find the position of the last pattern
substr(keyworddestinationurl, instr(keyworddestinationurl, 'adid=', -1) + 5,
least(greatest(instr(keyworddestinationurl, '_gs', -1) + 3, instr(keyworddestinationurl, '_gc}', -1) + 4) - instr(keyworddestinationurl, 'adid=', -1) - 5, 100)),
a.AccountName,
qualityscore,
customerid,
accountid
from stg.google_ad_api_daily ad, ay_temp_g_account_search a
where ad.customerid = a.clientid(+)
;

commit;

update stg.google_ad_api_imp
set adid = substr(adid, instr(adid, '{ifsearch:') + 10, instr(adid, '_gs') + 3 - instr(adid, '{ifsearch:') - 10)
where   adid like '{ifsearch:%'
and clickdate = to_date('&1', 'yyyy-mm-dd')
;

/**
--to correct an issue introduced by Greg's CMX experiment.
update stg.google_ad_api_imp
set adid = substr(keyworddestinationurl, instr(keyworddestinationurl, '{ifSearch:') + 10, instr(keyworddestinationurl, '_gs') + 3 - instr(keyworddestinationurl, '{ifSearch:') - 10)
where   keyworddestinationurl like '{ifSearch:%'
and clickdate = to_date('&1', 'yyyy-mm-dd')
;
**/

/**
update stg.google_ad_api_imp
set adid = 'keywordless_gs'
where keyworddestinationurl = 'default URL'
and lower(campaign) like '%keywordless%'
and clickdate = to_date('&1', 'yyyy-mm-dd')
;
**/

commit;

insert into stg.google_ad_api
(
network,
clickdate,
AdGroup,
AdGroupId,
AdWordsType,
AdGroupStatus,
BottomPosition,
DailyBudget,
CampaignStatus,
Campaign,
CampaignId,
Clicks,
Cost,
Cpc,
CreativeStatus,
CreativeType,
CreativeVisionURL,
CreativeId,
Ctr,
DescriptionLine1,
DescriptionLine2,
DestinationUrl,
DescriptionLine3,
Impressions,
Keyword,
MinimumCpc,
KeywordId,
--KeywordDestinationUrl,
KeywordStatus,
KeywordType,
MaxContentCPC,
MaximumCpc,
PageViewCount,
AveragePosition,
TopPosition,
Adid,
AccountName,
qualityscore,
customerid,
accountid
)
select 
network,
clickdate,
AdGroup,
AdGroupId,
AdWordsType,
AdGroupStatus,
BottomPosition,
DailyBudget,
CampaignStatus,
Campaign,
CampaignId,
Clicks,
Cost,
Cpc,
CreativeStatus,
CreativeType,
CreativeVisionURL,
CreativeId,
Ctr,
DescriptionLine1,
DescriptionLine2,
DestinationUrl,
DescriptionLine3,
Impressions,
Keyword,
MinimumCpc,
KeywordId,
--KeywordDestinationUrl,
KeywordStatus,
KeywordType,
MaxContentCPC,
MaximumCpc,
PageViewCount,
AveragePosition,
TopPosition,
Adid,
AccountName,
qualityscore,
customerid,
accountid
from stg.google_ad_api_imp
where clickdate = to_date('&1', 'yyyy-mm-dd')
and (clicks <> 0 or cost <> 0)
;

commit;

truncate table stg.google_ad_api_daily
;

spool off

quit;

