
drop table ap_temp_amazoncpc_ml4 purge;
drop table ap_temp_amazoncpc_catsls4 purge;
drop table ap_temp_amazoncpc_totsls4 purge;

drop table ap_temp_amazoncpc_ml1 purge;
drop table ap_temp_amazoncpc_catsls1 purge;
drop table ap_temp_amazoncpc_totsls1 purge;

drop table ap_temp_amazoncpc_factor purge;

set serveroutput on;
set heading off;
set trimspool on;
set linesize 400;
spool /home/oracle/apicker/Sales/Logs/amazon_cpc.check.log;

create table ap_temp_amazoncpc_ml4 nologging as
select 
  ml.productsourceid, ml.mexpcategoryid,
  count(*) mlcnt, sum(least(mp.retailprice, 1000)) pricesum,
  sum(decode(least(mp.retailprice, 1000),null,1,0)) pricenotfound
from dw.merchant_lead ml, stg.merchant_product mp
where ml.merchantproductid = mp.merchantproductid(+)
and ml.productsourceid in (3,16,17,18)
and ml.status = 'v'
and ml.clickdate >= trunc(sysdate)-28
and ml.clickdate  < trunc(sysdate)
group by ml.productsourceid, ml.mexpcategoryid
;

create table ap_temp_amazoncpc_ml1 nologging as
select 
  ml.productsourceid, ml.mexpcategoryid,
  count(*) mlcnt, sum(least(mp.retailprice, 1000)) pricesum,
  sum(decode(least(mp.retailprice, 1000),null,1,0)) pricenotfound
from dw.merchant_lead ml, stg.merchant_product mp
where ml.merchantproductid = mp.merchantproductid(+)
and ml.productsourceid in (3,16,17,18)
and ml.status = 'v'
and ml.clickdate >= trunc(sysdate)-7
and ml.clickdate  < trunc(sysdate)
group by ml.productsourceid, ml.mexpcategoryid
;

create table ap_temp_amazoncpc_catsls4 nologging as
select
  productsourceid, mexpcategoryid,
  sum(items_sold) catsls,
  sum(commission_amount) catrev,
  sum(sale_amount) catamz
from dw.sales_and_actuals
where productsourceid in (3,16,17,18)
and event_date >= trunc(sysdate)-28
and event_date  < trunc(sysdate)
and commission_amount > 0
and trackingid != 'prontocom99999-20' --Finecomb delta feed clicks
group by productsourceid, mexpcategoryid
;

create table ap_temp_amazoncpc_catsls1 nologging as
select
  productsourceid, mexpcategoryid,
  sum(items_sold) catsls,
  sum(commission_amount) catrev,
  sum(sale_amount) catamz
from dw.sales_and_actuals
where productsourceid in (3,16,17,18)
and event_date >= trunc(sysdate)-7
and event_date  < trunc(sysdate)
and commission_amount > 0
and trackingid != 'prontocom99999-20' --Finecomb delta feed clicks
group by productsourceid, mexpcategoryid
;

create table ap_temp_amazoncpc_totsls4 nologging as
select
  s.productsourceid,
  sum(s.items_sold) totsls,
  sum(s.commission_amount) totrev,
  sum(s.sale_amount) totamz,
  sum(decode(mc.mexpcategoryid,null,s.items_sold,0)) nocatsls,
  sum(decode(mc.mexpcategoryid,null,s.commission_amount,0)) nocatrev,
  sum(decode(mc.mexpcategoryid,null,s.sale_amount,0)) nocatamz
from dw.sales_and_actuals s, stg.mexp_category mc
where s.productsourceid in (3,16,17,18)
and s.event_date >= trunc(sysdate)-28
and s.event_date  < trunc(sysdate)
and s.commission_amount > 0
and s.trackingid != 'prontocom99999-20' --Finecomb delta feed clicks
and s.mexpcategoryid = mc.mexpcategoryid(+)
group by s.productsourceid
;

create table ap_temp_amazoncpc_totsls1 nologging as
select
  s.productsourceid,
  sum(s.items_sold) totsls,
  sum(s.commission_amount) totrev,
  sum(s.sale_amount) totamz,
  sum(decode(mc.mexpcategoryid,null,s.items_sold,0)) nocatsls,
  sum(decode(mc.mexpcategoryid,null,s.commission_amount,0)) nocatrev,
  sum(decode(mc.mexpcategoryid,null,s.sale_amount,0)) nocatamz
from dw.sales_and_actuals s, stg.mexp_category mc
where s.productsourceid in (3,16,17,18)
and s.event_date >= trunc(sysdate)-7
and s.event_date  < trunc(sysdate)
and s.commission_amount > 0
and s.trackingid != 'prontocom99999-20' --Finecomb delta feed clicks
and s.mexpcategoryid = mc.mexpcategoryid(+)
group by s.productsourceid
;

create table ap_temp_amazoncpc_factor nologging as
select
  decode(productsourceid,3,'amazon.com',16,'marketplace.amazon.com',17,'amazon.com',18,'marketplace.amazon.com') domain,
  productsourceid, mexpcategoryid, ratecardtext, pricemetricfloor, haircut,
  mlcnt, pricesum, pricenotfound,
  catsls, catrev, catamz,
  totsls, totrev, totamz,
  nocatsls, nocatrev, nocatamz,
  estsls, estrev, estamz, estpricesum,
  case
--    when mlcnt >= 100
    when mlcnt >= decode(mexpcategoryid,164,50,122,50,100)
    then nvl(haircut*(estrev/estpricesum),.0001)
    else .0001
  end cpc_factor,
  ceilingfactor
from
 (select
    productsourceid, mexpcategoryid, ratecardtext, pricemetricfloor, haircut, ceilingfactor,
    mlcnt, pricesum, pricenotfound,
    catsls, catrev, catamz,
    totsls, totrev, totamz,
    nocatsls, nocatrev, nocatamz,
    catsls+(catsls*(nocatsls/totsls)) estsls,
    catrev+(catrev*(nocatrev/totrev)) estrev,
    catamz+(catamz*(nocatamz/totamz)) estamz,
    pricesum+(pricesum*(pricenotfound/mlcnt)) estpricesum
  from
   (select
      pmf.productsourceid, pmf.mexpcategoryid, pmf.ratecardtext, pmf.pricemetricfloor, pmf.haircut, pmf.ceilingfactor,
      case when ml1.mlcnt >= 100 then ml1.mlcnt else ml4.mlcnt end mlcnt,
      case when ml1.mlcnt >= 100 then ml1.pricesum else ml4.pricesum end pricesum,
      case when ml1.mlcnt >= 100 then ml1.pricenotfound else ml4.pricenotfound end pricenotfound,
      case when ml1.mlcnt >= 100 then cs1.catsls else cs4.catsls end catsls,
      case when ml1.mlcnt >= 100 then cs1.catrev else cs4.catrev end catrev,
      case when ml1.mlcnt >= 100 then cs1.catamz else cs4.catamz end catamz,
      case when ml1.mlcnt >= 100 then ts1.totsls else ts4.totsls end totsls,
      case when ml1.mlcnt >= 100 then ts1.totrev else ts4.totrev end totrev,
      case when ml1.mlcnt >= 100 then ts1.totamz else ts4.totamz end totamz,
      case when ml1.mlcnt >= 100 then ts1.nocatsls else ts4.nocatsls end nocatsls,
      case when ml1.mlcnt >= 100 then ts1.nocatrev else ts4.nocatrev end nocatrev,
      case when ml1.mlcnt >= 100 then ts1.nocatamz else ts4.nocatamz end nocatamz
    from
     (select
        pmf.productsourceid, mc.mexpcategoryid,
        mc.ratecardtext, pmf.pricemetricfloor,
        h.haircut, h.ceilingfactor
      from stg.mexp_category mc, mexp.price_metric_floor pmf, stg.haircut_msc h
      where pmf.productsourceid in (3,16,17,18)
      and pmf.mexpcategoryid = mc.mexpcategoryid
      and pmf.productsourceid = h.productsourceid
      and pmf.mexpcategoryid = h.mexpcategoryid
      and decode(pmf.productsourceid,3,23821,17,23821,16,90000,18,90000) = h.merchantid) pmf,
      ap_temp_amazoncpc_ml1 ml1,
      ap_temp_amazoncpc_ml4 ml4,
      ap_temp_amazoncpc_catsls1 cs1,
      ap_temp_amazoncpc_catsls4 cs4,
      ap_temp_amazoncpc_totsls1 ts1,
      ap_temp_amazoncpc_totsls4 ts4
    where pmf.productsourceid = ml1.productsourceid(+)
    and pmf.mexpcategoryid = ml1.mexpcategoryid(+)
    and pmf.productsourceid = ml4.productsourceid(+)
    and pmf.mexpcategoryid = ml4.mexpcategoryid(+)
    and pmf.productsourceid = cs1.productsourceid(+)
    and pmf.mexpcategoryid = cs1.mexpcategoryid(+)
    and pmf.productsourceid = cs4.productsourceid(+)
    and pmf.mexpcategoryid = cs4.mexpcategoryid(+)
    and pmf.productsourceid = ts1.productsourceid(+)
    and pmf.productsourceid = ts4.productsourceid(+)))
;

merge into 
  stg.category_source_cpc a
using
 (select
    a.productsourceid, gc.goldencategoryid,
    greatest(.01,nvl(sum(estrev)/decode(sum(mlcnt),0,null,sum(mlcnt)),.01)) cpc
  from ap_temp_amazoncpc_factor a, stg.golden_category gc
  where a.mexpcategoryid = gc.mexpcategoryid
  group by a.productsourceid, gc.goldencategoryid) b
on 
 (a.productsourceid = b.productsourceid
  and a.goldencategoryid = b.goldencategoryid)
when matched then update
set a.cpc = b.cpc
when not matched then insert
 (a.goldencategoryid,
  a.productsourceid,
  a.cpc)
values
 (b.goldencategoryid,
  b.productsourceid,
  b.cpc)
;

commit;

spool off;
spool /home/oracle/apicker/Sales/Logs/amazon_cpc_report.log;

select
  to_char(next_day(trunc(sysdate),'Sun')-14,'mm/dd/yyyy')||' - '||
  to_char(next_day(trunc(sysdate),'Sun')-8,'mm/dd/yyyy')
from dual
;

select
  'Channel | Leads | Rev'
from dual;

select
  channel||' | '||
  sum(mlcnt)||' | '||
  round(sum(actrev),2)
from 
 (select channel, sum(mlcnt) mlcnt, 0 actrev
  from dw.leads
  where productsourceid in (3,16,17,18)
  and clickdate >= next_day(trunc(sysdate),'Sun')-14
  and clickdate  < next_day(trunc(sysdate),'Sun')-7
  group by channel
  UNION ALL
  select channel, 0 mlcnt, sum(commission_amount) actrev
  from dw.sales_and_actuals
  where productsourceid in (3,16,17,18)
  and event_date >= next_day(trunc(sysdate),'Sun')-14
  and event_date  < next_day(trunc(sysdate),'Sun')-7
  group by channel)
group by channel
order by channel
;

spool off;
spool /home/oracle/apicker/Sales/Logs/amazon.com.log;

select
  domain||'|'||
  productsourceid||'|'||
  mexpcategoryid||'|'||
  greatest(cpc_factor,.0001)||'|'||
  least(pricemetricfloor*ceilingfactor,1000*greatest(cpc_factor,.0001))
from apicker.ap_temp_amazoncpc_factor
where domain = 'amazon.com'
order by productsourceid, mexpcategoryid
;

spool off;
spool /home/oracle/apicker/Sales/Logs/marketplace.amazon.com.log;

select
  domain||'|'||
  productsourceid||'|'||
  mexpcategoryid||'|'||
  greatest(cpc_factor,.0001)||'|'||
  least(pricemetricfloor*ceilingfactor,1000*greatest(cpc_factor,.0001))
from apicker.ap_temp_amazoncpc_factor
where domain = 'marketplace.amazon.com'
order by productsourceid, mexpcategoryid
;

spool off;

drop table ap_temp_amazoncpc_ml4 purge;
drop table ap_temp_amazoncpc_catsls4 purge;
drop table ap_temp_amazoncpc_totsls4 purge;

drop table ap_temp_amazoncpc_ml1 purge;
drop table ap_temp_amazoncpc_catsls1 purge;
drop table ap_temp_amazoncpc_totsls1 purge;

drop table ap_temp_amazoncpc_factor purge;

quit;



