
column dd new_val dd;
column mm new_val mm;
column mm2 new_val mm2;

select
  to_char(to_date('&&1','mm/dd/yyyy'),'yyyymmdd') dd,
  to_char(to_date('&&1','mm/dd/yyyy'),'yyyymm')||'01' mm,
  to_char(to_date('&&1','mm/dd/yyyy')-1,'yyyymm')||'01' mm2
from dual
;

drop table ap_temp_pid1a purge;
drop table ap_temp_pid1 purge;
drop table ap_temp_pid_papi purge;
drop table ap_temp_pid2 purge;
drop table ap_temp_pid3 purge;
drop table ap_temp_pid5 purge;

set timing on;
set serveroutput on;
set trimspool on;
set heading off;
set linesize 500;
spool /home/dw/apicker/Logs/populate_parentid.log;
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
select 'apapapapap'||chr(10)||'START '||to_char(sysdate,'hh24.mi.ss') from dual;
select 'apapapapap'||chr(10)||'10: '||to_char(sysdate,'hh24.mi.ss') from dual;
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------ 
update stg.comm_all_request partition (part_&&mm)
set rootid = NULL
where &2 = 1
and timestamp2 >= to_date('&&dd','yyyymmdd')
and timestamp2  < to_date('&&dd','yyyymmdd')+1
;

commit;

update stg.comm_all_request partition (part_&&mm)
set parentid = NULL
where &2 = 1
and timestamp2 >= to_date('&&dd','yyyymmdd')
and timestamp2  < to_date('&&dd','yyyymmdd')+1
and type not in ('adSenseRedirect', 'productRedirect')
;

commit;

create table ap_temp_pid_papi nologging as
select
  requestid, parentid, rootid, timestamp2, ipaddress, cookieid, type,
  searchengine,
  adid, cobrandid, bhoname, 'true' iscomm, campaign, affiliateid, affiliatesubid, trackingcode, newsourcetracking,
  papipartnerid, papiuserid
from stg.comm_all_request partition (part_&&mm2)
where type = 'PAPI'
and timestamp2 >= to_date('&&dd','yyyymmdd')-1
and timestamp2  < to_date('&&dd','yyyymmdd')
;

create table ap_temp_pid1 nologging as
select
 requestid, parentid, rootid, timestamp2, ipaddress, nvl(cookieid,'null') cookieid, type, 
 searchengine, 
 adid, cobrandid, bhoname, iscomm, campaign, affiliateid, affiliatesubid, trackingcode, newsourcetracking,
 papipartnerid, papiuserid,
 rank() over(partition by nvl(cookieid,'null'), iscomm order by timestamp2, adid, decode(newsourcetracking,'true',1,2), decode(type,'PAPI',1,'LoadingMessageResponse',2,98), requestid) rk
from
 (select
    requestid,
    max(parentid) parentid,
    max(rootid) rootid,
    max(timestamp2) timestamp2,
    max(ipaddress) ipaddress,
    max(cookieid) cookieid,
    max(type) type,
    max(searchengine) searchengine,
    max(adid) adid,
    max(cobrandid) cobrandid,
    max(bhoname) bhoname,
    max(iscomm) iscomm,
    max(campaign) campaign,
    max(affiliateid) affiliateid,
    max(affiliatesubid) affiliatesubid,
    max(trackingcode) trackingcode,
    max(newsourcetracking) newsourcetracking,
    max(papipartnerid) papipartnerid,
    max(papiuserid) papiuserid
  from
   (select
      requestid, parentid, rootid, timestamp2,
      ipaddress, cookieid, type,
      searchengine, adid, cobrandid,
      bhoname, iscomm,
      campaign, affiliateid, affiliatesubid, trackingcode, newsourcetracking,
      papipartnerid, papiuserid
    from ap_temp_pid_papi
    UNION ALL
    select
      ar.requestid, ar.parentid,
      case
        when ar.parentid like 'newsletter%' then ar.requestid
        when ar.parentid = 'feed' then ar.requestid
        else ar.rootid
      end rootid, ar.timestamp2,
      ar.ipaddress, ar.cookieid, ar.type, 
      ar.searchengine, ar.adid, ar.cobrandid,
      ar.bhoname, 'true' iscomm,
      ar.campaign, ar.affiliateid, ar.affiliatesubid, ar.trackingcode, ar.newsourcetracking,
      ar.papipartnerid, ar.papiuserid
    from stg.comm_all_request ar
    where ar.type not in (select type from stg.landing_page_exclusion)
    and ar.timestamp2 >= to_date('&&dd','yyyymmdd')-(4/24)
    and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
    and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = ar.ipaddress)
    UNION ALL
    select
      requestid, parentid, 
      case
        when parentid like 'newsletter%' then requestid
        when parentid = 'feed' then requestid
        else null
      end rootid, timestamp2,
      ipaddress, cookieid, 'ProductRedirectionResponse' type,
      searchengine, adid, cobrandid,
      bhoname, 'true' iscomm,
      null campaignid, null affiliateid, null affiliatesubid, null trackingcode, null newsourcetracking,
      papipartnerid, papiuserid
    from stg.comm_redirect_event partition (part_&&mm) re
    where exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
    and timestamp2 >= to_date('&&dd','yyyymmdd')
    and timestamp2  < to_date('&&dd','yyyymmdd')+1
    UNION ALL
    select
      requestid, parentid, 
      case
        when parentid like 'newsletter%' then requestid
        when parentid = 'feed' then requestid
        else null
      end rootid, timestamp2,
      ipaddress, cookieid, 'AdWordRedirectionResponse' type,
      searchengine, adid, cobrandid,
      bhoname, 'true' iscomm,
      null campaignid, null affiliateid, null affiliatesubid, null trackingcode, null newsourcetracking,
      null papipartnerid, null papiuserid
    from stg.comm_adword_click partition (part_&&mm) re
    where exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
    and timestamp2 >= to_date('&&dd','yyyymmdd')
    and timestamp2  < to_date('&&dd','yyyymmdd')+1) 
  group by requestid)
;

create unique index aptemppid1$idx 
on ap_temp_pid1(cookieid, iscomm, rk, rk-1)
tablespace temp_index
;

analyze table ap_temp_pid1 compute statistics;

--**/
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
select 'apapapapap'||chr(10)||'20: '||to_char(sysdate,'hh24.mi.ss') from dual;
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------

create table ap_temp_pid2 nologging as
select
 requestid,
 max(iscomm) iscomm,
 max(rk) rk,
 max(cookieid) cookieid,
 max(ipaddress) ipaddress,
 max(timestamp2) timestamp2,
 max(type) type,
 max(parentid) parentid,
 max(rootid) rootid,
 max(which) which
from
(select
  a.requestid,
  a.iscomm,
  a.rk,
  a.cookieid,
  a.ipaddress,
  a.timestamp2,
  a.type,
  case 
   when 
    a.parentid is not null
    or a.rootid is not null
   then a.parentid
   when
    a.adid is not null
    then decode(b.type,'LandingPageResponse',b.requestid,null)
   when
     a.searchengine is not null
     and a.affiliateid = 'pronto'
     and a.newsourcetracking = 'true'
     then b.requestid
   when
    stg.is_pronto_searchengine(nvl(a.searchengine,'pronto')) = 'false'
    then decode(b.type,'PAPI',b.requestid,decode(nvl(b.cobrandid,'^'),'^',null,b.requestid))
   when
    a.type in ('PAPI','LandingPageResponse','cobrand.AskHomePageResponse','cobrand.FeaturedProductsHomePageResponse','xml.ProductDetailResponse2','xml.ProductDetailEvent2','cpuLoad')
    then null
   when
    a.papipartnerid is not null
    then decode(b.type,'PAPI',b.requestid)
   when  
    a.timestamp2 < b.timestamp2+(4/24) 
    then b.requestid 
   else 
    null 
  end parentid,
  case 
   when 
    a.parentid is not null
    or a.rootid is not null
    then case 
       when a.searchengine in ('finecomb','allblox','api.pronto.com')
         or a.searchengine like '%finecomb.com'
         or a.searchengine like '%allblox.com'
       then a.requestid
       else coalesce(a.rootid,ar.rootid,ar2.rootid,decode(a.papipartnerid,null,null,a.requestid))
     end
   when
    a.adid is not null
    then decode(b.type,'LandingPageResponse',b.requestid,a.requestid)
   when
     a.searchengine is not null
	 and a.affiliateid = 'pronto'
	 and a.newsourcetracking = 'true'
	 then b.rootid
   when
    stg.is_pronto_searchengine(nvl(a.searchengine,'pronto')) = 'false'
    then decode(b.type,'PAPI',b.requestid,decode(nvl(b.cobrandid,'^'),'^',a.requestid,b.requestid))
   when
    a.type in ('PAPI','LandingPageResponse','cobrand.AskHomePageResponse','cobrand.FeaturedProductsHomePageResponse','xml.ProductDetailResponse2','xml.ProductDetailEvent2','cpuLoad')
    then a.requestid
   when
    a.papipartnerid is not null
    then decode(b.type,'PAPI',coalesce(b.rootid,b.parentid,b.requestid),a.requestid)
   when  
    a.timestamp2 < b.timestamp2+(4/24) 
    then b.rootid
   else 
    a.requestid
  end rootid,
  case 
   when 
    a.parentid is not null
    or a.rootid is not null
    then case 
       when a.searchengine in ('finecomb','allblox','api.pronto.com')
         or a.searchengine like '%finecomb.com'
         or a.searchengine like '%allblox.com'
       then 11
       else 10
     end
   when
    a.adid is not null
    then decode(b.type,'LandingPageResponse',21,22)
   when
     a.searchengine is not null
	 and a.affiliateid = 'pronto'
	 and a.newsourcetracking = 'true'
	 then 28
   when
    stg.is_pronto_searchengine(nvl(a.searchengine,'pronto')) = 'false'
    then decode(b.type,'PAPI',31,decode(nvl(b.cobrandid,'^'),'^',32,33))
   when
    a.type = 'PAPI'
    then 41
   when
    a.papipartnerid is not null
    then 41.1
   when
    a.type = 'LandingPageResponse'
    then 42
   when
    a.type = 'cobrand.AskHomePageResponse'
    then 43
   when
    a.type = 'cobrand.FeaturedProductsHomePageResponse'
    then 44
   when
    a.type = 'xml.ProductDetailResponse2'
    then 45
   when
    a.type = 'xml.ProductDetailEvent2'
    then 46
   when
    a.type = 'cpuLoad'
    then 47
   when  
    a.timestamp2 < b.timestamp2+(4/24) 
    then 50
   else 
    60
  end which
 from
  ap_temp_pid1 a,
  ap_temp_pid1 b,
  stg.all_request ar,
  stg.comm_all_request ar2
 where a.cookieid = b.cookieid(+)
  and a.rk-1 = b.rk(+)
  and a.iscomm = b.iscomm(+)
  and a.parentid = ar.requestid(+)
  and to_date('&&dd','yyyymmdd')-(4/24) <= ar.timestamp2(+)
  and to_date('&&dd','yyyymmdd')+1 > ar.timestamp2(+)
  and a.parentid = ar2.requestid(+)
  and to_date('&&dd','yyyymmdd')-(4/24) <= ar2.timestamp2(+)
  and to_date('&&dd','yyyymmdd')+1 > ar2.timestamp2(+))
group by requestid
;

------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
select 'apapapapap'||chr(10)||'30: '||to_char(sysdate,'hh24.mi.ss') from dual;
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------

--made minor changes here to make sure uniqueness. it had big positive impact to the execution plan for the statement that creates ap_temp_pid5 that was hanging. -- andre 2/27/2010 

create table ap_temp_pid3 nologging as
select
 cookieid,
 min(ipaddress) ipaddress,
 iscomm,
 rk,
 min(rootid) rootid
from
 ap_temp_pid2
where
 rootid is not null
 and cookieid is not null
 and iscomm is not null
 and rk is not null
group by cookieid, iscomm, rk
;

alter table ap_temp_pid3
add constraint PID3_PK
primary key (cookieid, rk, iscomm)
using index tablespace temp_index
;

------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
select 'apapapapap'||chr(10)||'40: '||to_char(sysdate,'hh24.mi.ss') from dual;
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------

create table ap_temp_pid5 nologging as
select
 p2.requestid,
 p2.parentid,
 p3.rootid,
 p2.iscomm
from
(select a.requestid, a.parentid, a.iscomm, a.timestamp2, nvl(b.cookieid,a.cookieid) cookieid, nvl(b.rk,a.rk) rk 
 from ap_temp_pid2 a, ap_temp_pid2 b
 where a.timestamp2 >= to_date('&&dd','yyyymmdd') 
 and a.parentid = b.requestid(+)) p2,
 ap_temp_pid3 p3
where
 p2.cookieid = p3.cookieid
 and p2.iscomm = p3.iscomm
 and p3.rk = (select max(rk) from ap_temp_pid3
              where cookieid = p2.cookieid
              and iscomm = p2.iscomm 
              and rk <= p2.rk)
;

alter table ap_temp_pid5
add constraint PID4_PK
primary key (requestid)
using index tablespace temp_index
;

--**/
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
select 'apapapapap'||chr(10)||'46: '||to_char(sysdate,'hh24.mi.ss') from dual;
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------

merge into stg.comm_all_request partition (part_&&mm) a
using (select * from ap_temp_pid5 where iscomm = 'true') b
on 
(a.timestamp2 >= to_date('&&dd','yyyymmdd') 
 and a.timestamp2 < to_date('&&dd','yyyymmdd')+1 
 and a.requestid = b.requestid)
when matched then update
set
 a.parentid = b.parentid,
 a.rootid = b.rootid
;

commit;

------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
select 'apapapapap'||chr(10)||'MERGE COMPLETE '||to_char(sysdate,'hh24.mi.ss') from dual;
------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------
spool off;
/**
truncate table ap_temp_pid2;
truncate table ap_temp_pid3;
truncate table ap_temp_pid5;
--**/
quit;


