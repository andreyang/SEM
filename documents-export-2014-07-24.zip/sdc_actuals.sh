#!/bin/sh
. /u01/app/oracle/oraenv
ddcheck1=`/bin/date '+%Y%m%d'`

dblink="DWH"

#####
## date declaration
  if [ $1 ];
  then
    mdy=$1
    mm=${mdy:0:2}
    dd=${mdy:3:2}
    yy=${mdy:6}
    ymd="$yy$mm$dd"
    dow="Tmp"
  else
    mdy=`/bin/date -d yesterday '+%m/%d/%Y'`
    mm=`/bin/date -d yesterday '+%m'`
    dd=`/bin/date -d yesterday '+%d'`
    yy=`/bin/date -d yesterday '+%Y'`
    ymd=`/bin/date -d yesterday '+%Y%m%d'`
    dow=`/bin/date '+%a'`
  fi

mdy_today=`${ORACLE_HOME}/bin/sqlplus -s<<EOF
apicker/igot5onit@$dblink
set heading off
select
  to_char(to_date('$mdy','mm/dd/yyyy')+1,'mm/dd/yyyy')
from dual;
EOF`
mdy_today=`echo $mdy_today | sed 's#\s##g'`


#####
## rev share
#REV SHARE %
# default tier = 90.0%, additional 3% = 87.3%
# higher tier  = 92.5%, additional 3% = 89.725%
revshare=.87300
#revshare=.89725


#####
## directories
  slsdir="/home/oracle/apicker/Sales"
  sqldir="$slsdir/SQL"
  ctldir="$slsdir/Control"
  logdir="$slsdir/Logs"
  datadir="$slsdir/Data"


#####
## mysql creds
  un=rc
  pw=shop
  db=application_data
  hst=dbapp101
  prt=3306
  db="mysql --force -u$un -p$pw -D$db -h$hst -P$prt"


#####
## get sdc channel ids
  rm $logdir/sdc_channel_id.bad
  touch $logdir/sdc_channel_id.bad
  $db < $sqldir/get_sdc_channel_id.sql > $datadir/sdc_channel_id.out
  perl -pi -e 's#^domain.+$##' $datadir/sdc_channel_id.out
  perl -pi -e 's#^code.+$##' $datadir/sdc_channel_id.out

  sqlldr userid=loader/pr0nt0loader321@$dblink control=$ctldir/sdc_channel_id.ctl log=$logdir/sdc_channel_id.log
  badcnt=`sed -n '$=' $logdir/sdc_channel_id.bad`
  if [ $badcnt -gt 0 ];
  then
    mail -s "(warning) SDC Channel ID rejections" apicker@pronto.com < $logdir/sdc_channel_id.log
  fi

  sqlplus apicker/igot5onit@$dblink @$sqldir/sdc_channel_id.sql
  iserr=`grep ERROR $logdir/sdc_channel_id.bad`
  if [ -n "$iserr" ];
  then
    mail -s "(error) SDC Channel ID load" apicker@pronto.com < $logdir/sdc_channel_id.bad
    exit
  fi


#####
## get sale data from ftp
  while [ ! -f $datadir/sdc_actuals.out ];
  do
    perl $slsdir/sdc_get.pl $yy $mm $dd
    if [ ! -f $datadir/sdc_actuals.out ];
    then
      sleep 600 ## SDC FTP
      ddcheck2=`/bin/date '+%Y%m%d'`
      if [ $ddcheck1 != $ddcheck2 ];
      then
        touch $logdir/sdc_nofile.log
        mail -s "(warning) SDC Actuals File for $mdy DNE" apicker@pronto.com, bholstein@pronto.com < $logdir/sdc_nofile.log
        exit
      fi
    fi
  done


#####
## load sdc actuals
  sqlldr userid=loader/pr0nt0loader321@$dblink control=$ctldir/sdc_actuals.ctl log=$logdir/sdc_actuals.log
  badcnt=`sed -n '$=' $logdir/sdc_actuals.bad`
  if [ $badcnt -gt 0 ];
  then
    mail -s "(warning) SDC Actuals File rejections" apicker@pronto.com < $logdir/sdc_actuals.log
  fi


#####
## sql insert
  sqlplus apicker/igot5onit@$dblink @$sqldir/sdc_actuals.sql $revshare 
  iserr2=`grep ERROR $logdir/sdc_warn.log`
  if [ -n "$iserr2" ];
  then
    mail -s "(error) Bad SDC Data" apicker@pronto.com < $logdir/sdc_warn.log
    mv $datadir/sdc_actuals.out $datadir/sdc_actuals.out.$dd
    exit
  fi
  iserr=`grep ERROR $logdir/sdc.log`
  if [ -n "$iserr" ];
  then
    mail -s "(error) SDC Actuals insert" apicker@pronto.com < $logdir/sdc.log
    mv $datadir/sdc_actuals.out $datadir/sdc_actuals.out.$dd
    exit
  fi


#####
## summary_tables_updated
  sqlplus apicker/igot5onit@$dblink @$sqldir/update_complete_date.sql "sdc_actuals" "sdc_actuals" $ymd


#####
## sdc daily recon
  sqlplus apicker/igot5onit@$dblink @$sqldir/check_update.sql "merchant_lead','flanker.merchant_lead" "$mdy_today" "sdcact"
  isdone=`grep TRUE /home/oracle/apicker/Sales/Logs/check_update_sdcact.log`
  while [ ! "$isdone" ];
  do
    sleep 600 ## SDC ML sleep
    ddcheck2=`/bin/date '+%Y%m%d'`
    if [ $ddcheck1 != $ddcheck2 ];
    then
      mail -s "(error) SDC Daily Recon waiting for ML" apicker@pronto.com < /home/oracle/apicker/Sales/Logs/check_update_sdcact.log
      mv $datadir/sdc_actuals.out $datadir/sdc_actuals.out.$dd
      exit
    fi
    sqlplus apicker/igot5onit@$dblink @$sqldir/check_update.sql "merchant_lead','flanker.merchant_lead" "$mdy_today" "sdcact"
    isdone=`grep TRUE /home/oracle/apicker/Sales/Logs/check_update_sdcact.log`
  done

  sqlplus apicker/igot5onit@$dblink @$sqldir/sdc_daily_recon.sql $mdy $revshare
  grep -v '^$' $logdir/sdc_daily_recon.log > $logdir/sdc_daily_recon.log.2
  mv $logdir/sdc_daily_recon.log.2 $logdir/sdc_daily_recon.log
  perl -pi -e 's#^apapapapap$##' $logdir/sdc_daily_recon.log

  mail -s "SDC Daily Reconciliation - $mdy" apicker@pronto.com, Garrett.Nicholson@pronto.com, Zachary.Klaas@pronto.com < $logdir/sdc_daily_recon.log

  if [ -s $logdir/sdc_estact_warn.log ];
  then
    echo "date|source|est leads|act leads|lead %|est rev|act rev|rev %" > $logdir/sdc_estact_warn.log.2
    cat $logdir/sdc_estact_warn.log >> $logdir/sdc_estact_warn.log.2
    mv $logdir/sdc_estact_warn.log.2 $logdir/sdc_estact_warn.log
    mail -s "SDC Estimate vs Actual warning - $mdy" Garrett.Nicholson@pronto.com, Zachary.Klaas@pronto.com, bholstein@pronto.com < $logdir/sdc_estact_warn.log
  fi

#####
## clean-up
  mv $datadir/sdc_channel_id.out $datadir/sdc_channel_id.out.$dd
  mv $logdir/sdc_channel_id.log $logdir/sdc_channel_id.log.$dd
  mv $logdir/sdc_channel_id.bad $logdir/sdc_channel_id.bad.$dd
  mv $datadir/sdc_actuals.out $datadir/sdc_actuals.out.$dd
  mv $logdir/sdc_actuals.log $logdir/sdc_actuals.log.$dd
  mv $logdir/sdc_actuals.bad $logdir/sdc_actuals.log.$dd
  mv $logdir/sdc.log $logdir/sdc.log.$dd
  mv $logdir/sdc_daily_recon.log $logdir/sdc_daily_recon.log.$dd


#####
## partner daily recon
  /usr/bin/lockfile -1 $slsdir/partner_daily_recon.loc
  /bin/bash $slsdir/partner_daily_recon.sh &
  rm -f $slsdir/partner_daily_recon.loc


#####
## Threshold Alert
  ssh dw@dbwarehouse101 "/bin/bash /home/dw/apicker/ReportScripts/threshold_alert.sh" &


