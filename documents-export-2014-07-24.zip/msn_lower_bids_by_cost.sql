--on dw
--/**
drop table ay_temp_msn_bid_history purge;
create table ay_temp_msn_bid_history nologging as
select distinct adid
from stg.msn_bid_history
where createddate >= trunc(sysdate) - 28
;

drop table ay_temp_msn_click purge;
create table ay_temp_msn_click nologging as
select distinct * from
(select  adid,
        orderid adgroupid,
        campaignid,
        orderitemid keywordid,
        account accountid,
        lower(keyword) keyword,
        currentmaximumcpc maximumcpc,
        avgpos pos,
        deliveredmatchtype keywordtype,
        RANK() OVER (PARTITION BY orderitemid, orderid, deliveredmatchtype, campaignid, account ORDER BY clickdate desc, adid, avgpos, msnadid, distchannel) rk
from stg.msn_ad_api t
where clickdate >= trunc(sysdate) - 14
and clickdate < trunc(sysdate)
--and (ordername like '108-%' or ordername like '109-%' or ordername like '110-%' or ordername like '111-%' or ordername like '112-%' or ordername like '113-%' or ordername like '114-%' or ordername like '115-%' or ordername like '116-%' or ordername like '117-%' or ordername like '118-%' or ordername like '169-%' or ordername like '170-%' or ordername like '171-%')
--and adid like 'RLD-%'
--and adid not like '%bmx%'
--and adid not like '%d-%'
--and (lower(keyword) like '%halloween%' or lower(keyword) like '%costume%')
) ad
where rk = 1
and not exists (select * from ay_temp_msn_bid_history where adid = ad.adid)
;

drop table ay_temp_msn_click2 purge;
create table ay_temp_msn_click2 nologging as
select c.adid, rev, cost, click
from 	(select ad.adid, sum(clicks) click, sum(totalcost) cost
	from stg.msn_ad_api ad
	where clickdate >= trunc(sysdate) - 7
        and clickdate < trunc(sysdate)
	group by ad.adid) c,
	(select adid, sum(rev) rev
	from (select ad.adid, sum(cpc) rev from dw.merchant_lead ad
        where clickdate >= trunc(sysdate) - 7
        and clickdate < trunc(sysdate)
	and isdup = 'n'
	group by ad.adid
	union all
	select ad.adid, sum(nvl(cpc_actual, cpc)*numclick) rev from dw.adword_adid ad
        where clickdate >= trunc(sysdate) - 7
        and clickdate < trunc(sysdate)
	group by ad.adid
	)
	group by adid
	) r
where c.adid = r.adid(+)
and nvl(rev,0) < = .25*cost
--and c.click >= 2
--and rev > cost
;
--**/

set heading off
set linesize 300
set trimspool on
spool /home/dw/ayang/Log/bids.msn.lower.txt

select  distinct
        to_char(accountid)||'|'||
        to_char(adgroupid)||'|'||
        to_char(keywordid)||'|'||
	greatest(.05, round(maximumcpc*(1-greatest(.15, (6-pos)/20)), 2))||'|'||
        lower(substr(keywordtype, 1, 1))||'|'||
        t.adid||'|'||
        to_char(campaignid)
from ay_temp_msn_click t
where t.pos < 6
and greatest(.05, round(maximumcpc*(1-greatest(.15, (6-pos)/20)), 2)) < maximumcpc
and /**not**/ exists (select * from ay_temp_msn_click2 where adid = t.adid)
;
spool off

drop table ay_temp_msn_lower_adid purge;
create table ay_temp_msn_lower_adid nologging as
select distinct t.adid
from ay_temp_msn_click t
where t.pos < 6
and greatest(.05, round(maximumcpc*(1-greatest(.15, (6-pos)/20)), 2)) < maximumcpc
and /**not**/ exists (select * from ay_temp_msn_click2 where adid = t.adid)
;

drop table ay_temp_msn_click purge;
drop table ay_temp_msn_click2 purge;

quit
