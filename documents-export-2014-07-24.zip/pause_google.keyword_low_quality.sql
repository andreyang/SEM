--/**
drop table ay_temp_google_gf_click purge;
create table ay_temp_google_gf_click nologging as
select distinct * from
(select  adid,
        adgroupid,
        campaignid,
        keywordid,
        accountid,
        lower(keyword) keyword,
        keywordtype matchtype,
        campaign,
	adgroup adgroupname,
	qualityscore,
	RANK() OVER (PARTITION BY adid ORDER BY clickdate desc, lower(keyword), keywordid, adgroupid, campaignid, creativeid, keywordtype) rk
from stg.google_ad_api_gifts_imp t
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
) ad
where rk = 1
;

drop table ay_temp_google_gf_click_r purge;
create table ay_temp_google_gf_click_r nologging as
select keywordid
from dw.merchant_lead ml, ay_temp_google_gf_click t
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
and ml.adid = t.adid
and siteid = 62
and ml.adid like '%gs'
group by keywordid
having count(*) > 1
;
--**/

drop table ay_temp_google_gf_2_delete purge;
create table ay_temp_google_gf_2_delete nologging as
select t.* from ay_temp_google_gf_click t
where qualityscore <= 2
and not exists (select * from ay_temp_google_gf_click_r where keywordid = t.keywordid)
;

set heading off
set trimspool on
set linesize 300
spool /home/dw/ayang/Log/pause.google.gf.low_qs.txt

select  accountid||'|'||
        campaign||'|'||
        to_char(campaignid)||'|'||
        adgroupname||'|'||
        to_char(adgroupid)||'|'||
        to_char(keywordid)||'|'||
        adid||'|'||
        keyword||'|'||
        lower(substr(matchtype, 0, 1))
from ay_temp_google_gf_2_delete t
;

spool off

select clickdate||'|'||sum(clicks)||'|'||sum(cost/1000000)
from stg.google_ad_api_gifts ad, ay_temp_google_gf_2_delete t
where ad.adid = t.adid
and clickdate >= trunc(sysdate) - 7
group by clickdate
order by clickdate
;

select clickdate||'|'||sum(cpc*numclick)||'|'||sum(numclick)
from dw.adword_adid ad, ay_temp_google_gf_2_delete t
where ad.adid = t.adid
and clickdate >= trunc(sysdate) - 7
group by clickdate
order by clickdate
/

select clickdate||'|'||sum(cpc)||'|'||sum(1)
from dw.merchant_lead ad, ay_temp_google_gf_2_delete t
where ad.adid = t.adid
and clickdate >= trunc(sysdate) - 7
group by clickdate
order by clickdate
/
quit
