--/**
drop table ay_temp_msn_adid_c purge;
create table ay_temp_msn_adid_c nologging as
select adid, min(account) account, sum(totalcost) cost, min(lower(keyword)) keyword,
sum(clicks) clicks, sum(imp) imp, sum(imp*avgpos)/sum(imp) pos
from stg.msn_ad_api_imp ad
where clickdate >= trunc(sysdate) - 7
group by adid
having sum(imp) >= 10000
/

drop table ay_temp_msn_adid_r purge;
create table ay_temp_msn_adid_r nologging as
select adid, sum(ml) ml, sum(adl) adl, round(sum(ml_rev),2) ml_rev, round(sum(adl_rev),2) adl_rev
from (select adid, sum(cpc) ml_rev, count(*) ml, 0 adl_rev, 0 adl
	from dw.merchant_lead 
	where clickdate >= trunc(sysdate) - 7
	and adid like '%m_s'
	and isdup = 'n'
	and siteid = 1
	group by adid
--union all
--	select adid, 0, 0, sum(nvl(cpc_actual, cpc)*numclick), round(sum(numclick))
--	from dw.adword_adid 
--	where clickdate >= trunc(sysdate) - 7
--	and adid like '%m_s'
--	and siteid = 1
--	group by adid
--/
)
group by adid
;

select sum(imp), sum(clicks) 
from ay_temp_msn_adid_c
/

select sum(imp), sum(clicks), count(*)
from ay_temp_msn_adid_c c
where pos <= 6
and imp >= 10000
and (clicks/imp <= .0005)
;

drop table ay_temp_ctr_delete purge;
create table ay_temp_ctr_delete nologging as
select adid, keyword, imp, clicks
from ay_temp_msn_adid_c c
where pos <= 6
and imp >= 10000
and (clicks/imp <= .0005)
and not exists (select * from ay_temp_msn_adid_r where adid = c.adid and ml >= 10)
/

drop table ay_temp_msn_adid_c purge;
drop table ay_temp_msn_adid_r purge;

--**/

/**
set heading off
set trimspool on
set linesize 200
spool c:\keyword_ctr.txt

--select 'adid|keyword|imp|clicks|cost|pos|ml|adl|ml_rev|adl_rev' from dual
--union all

select c.adid||'|'||keyword||'|'||imp||'|'||clicks||'|'||cost||'|'||trunc(pos)||'|'||ml||'|'||adl||'|'||ml_rev||'|'||adl_rev
from ay_temp_msn_adid_c c, ay_temp_msn_adid_r r
where c.adid = r.adid(+)
order by imp desc
;

spool off
**/

connect ayang/redcarpet123@be1
drop table ay_temp_ctr_delete purge;
create table ay_temp_ctr_delete nologging as
select * 
from ayang.ay_temp_ctr_delete@dwh
/

analyze table ay_temp_ctr_delete compute statistics;

set heading off
set trimspool on
set linesize 300
spool /home/dw/ayang/Log/pause.msn.low_ctr.txt

select k.accountid||'|'||
        campaignname||'|'||
        to_char(k.campaignid)||'|'||
        adgroupname||'|'||
        to_char(k.adgroupid)||'|'||
        to_char(k.keywordid)||'|'||
        k.adid||'|'||
        k.keyword||'|'||
        lower(substr(k.matchtype, 0, 1))
from titan.keyword k, titan.adgroup g, titan.campaign c, ay_temp_ctr_delete t
where k.adgroupid = g.adgroupid
and k.campaignid = g.campaignid
and k.campaignid = c.campaignid
and k.adid = t.adid
and k.searchengine = 'Msn'
and k.status <> 'D'
--and t.adid like '%-oh_m_s'
;
spool off

/**
--after pause files are processed, run the query below
update titan.keyword
set status = 'D'
where adid in (select adid from ay_temp_ctr_delete)
and searchengine in ('Msn')
;
commit;
**/

drop table ay_temp_ctr_delete purge;

quit
