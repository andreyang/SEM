drop table ay_temp_similar_adid;
create table ay_temp_similar_adid nologging as
select adid, keyword
from titan.keyword@be1
where --adid like '1210337773-9536924d-%gc'
(keyword like 'ebay official site%'
)
and (adid like '%m_s' or adid like '%gc')
/**
union 
select adid, keyword
from titan.keyword@be1
where (adgroupid, campaignid) in (select adgroupid, campaignid from titan.keyword@be1 where adid like '1210340551-6692685d%gc')
**/
;

update dw.adword_adid_cpc t
set cpc = (select (case when t.adid like '%_gc' then 1 else 1 end)*cpc from ay_temp_cpc)
where exists (select * from ay_temp_similar_adid where replace(regexp_replace(adid, '(\d)\D+$', '\1'), 'RLD-','') = t.adid)
;

insert into dw.adword_adid_cpc
(adid, cpc)
select distinct replace(regexp_replace(adid, '(\d)\D+$', '\1'), 'RLD-',''), 
round(avg((case when adid like '%_gc' then 1 else 1 end)*cpc), 4)
from ay_temp_similar_adid t, ay_temp_cpc
where not exists (select * from dw.adword_adid_cpc where replace(regexp_replace(t.adid, '(\d)\D+$', '\1'), 'RLD-','') = adid)
group by replace(regexp_replace(adid, '(\d)\D+$', '\1'), 'RLD-','')
;

update dw.adword_adid
set cpc_actual = decode(siteid, 62, .73, .83)*(select cpc from ay_temp_cpc)
where adid in (select adid from ay_temp_similar_adid)
and clickdate >= trunc(sysdate) - 28
;

select distinct keyword from ay_temp_similar_adid;
select * from ay_temp_cpc;

commit;

