create table ay_temp_gc_adid_10_clicks nologging as
select REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid, cost, clicks, imp, pos
from (
select adgroup, sum(cost/1000000) cost, sum(clicks) clicks, sum(impressions) imp, round(sum(clicks*averageposition)/sum(clicks),2) pos
from stg.google_ad_api_content
where clickdate >= '16-Jan-2013'
group by adgroup
having sum(clicks) >= 5
)
;

create table ay_temp_gc_adid_10_clicks_ml nologging as
select adid, round(sum(cpc),2) ml_rev, count(*) ml, round(sum(decode(productsourceid, 13, cpc, 0)),2) sdc_rev, sum(decode(productsourceid, 13, 1, 0)) sdc_ml, round(sum(decode(productsourceid, 20, cpc, 0)),2) sz_rev, sum(decode(productsourceid, 20, 1, 0)) sz_ml, round(sum(decode(productsourceid, 19, cpc, 0)),2) pg_rev, sum(decode(productsourceid, 19, 1, 0)) pg_ml, round(sum(decode(productsourceid, 28, cpc, 0)),2) be_rev, sum(decode(productsourceid, 20, 1, 0)) be_ml, round(sum(decode(productsourceid, 3, cpc, 16, cpc, 0)),2) amazon_rev, sum(decode(productsourceid, 3, 1, 16, 1, 0)) amazon_ml, round(sum(decode(productsourceid, 15, cpc, 0)),2) mexp_rev, sum(decode(productsourceid, 15, 1, 0)) mexp_ml
from dw.merchant_lead
where clickdate >= '16-Jan-2013'
and siteid = 1
and isdup = 'n'
and adid like '%gc'
group by adid
;

create table ay_temp_gc_adid_10_clicks_ad nologging as
select adid, round(sum(numclick)) adl, round(sum(nvl(cpc_actual,cpc)*numclick),2) ad_rev
from dw.adword_adid
where clickdate >= '16-Jan-2013'
and siteid = 1
and adid like '%gc'
group by adid
;

connect ayang@be1/redcarpet123
create table ay_temp_gc_adid_with_rev2 nologging as
select distinct adid from ay_temp_gc_adid_10_clicks_ml@dwh
union 
select distinct adid from ay_temp_gc_adid_10_clicks_ad@dwh
;

create table ay_temp_gc_adid_with_rev nologging as
select t.adid, keyword, adgroupcpc
from titan.keyword k, titan.adgroup g, ay_temp_gc_adid_with_rev2 t
where k.adid = t.adid
and k.adgroupid = g.adgroupid
and k.campaignid = g.campaignid
;

drop table ay_temp_gc_adid_with_rev2 purge;

connect ayang/redcarpet123
create table ay_temp_gc_adid_with_rev nologging as
select * from ay_temp_gc_adid_with_rev@be1
;

connect ayang@be1/redcarpet123
drop table ay_temp_gc_adid_with_rev purge;

connect ayang/redcarpet123

set heading off
set linesize 200
set trimspool on
spool ./top_gc_keyword.txt

select 'adid|adid_comm|keyword|adgroupcpc|cost|clicks|imp|pos|adl|ad_rev|ml|ml_rev|sdc_ml|sdc_rev|sz_ml|sz_rev|pg_ml|pg_rev|be_ml|be_rev|mexp_ml|mexp_rev|amazon_ml|amazon_rev'
from dual;

select k.adid||'|'||c.adid||'|'||k.keyword||'|'||k.adgroupcpc||'|'||c.cost||'|'||c.clicks||'|'||c.imp||'|'||c.pos||'|'||adl||'|'||ad_rev||'|'||ml||'|'||ml_rev||'|'||sdc_ml||'|'||sdc_rev||'|'||sz_ml||'|'||sz_rev||'|'||pg_ml||'|'||pg_rev||'|'||be_ml||'|'||be_rev||'|'||mexp_ml||'|'||mexp_rev||'|'||amazon_ml||'|'||amazon_rev
from ay_temp_gc_adid_with_rev k, ay_temp_gc_adid_10_clicks c, ay_temp_gc_adid_10_clicks_ml ml, ay_temp_gc_adid_10_clicks_ad ad
where k.adid = ml.adid(+)
and k.adid = ad.adid(+)
and c.adid = REGEXP_REPLACE(k.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
;

spool off

quit
