spool /home/dw/ayang/Log/MSNGiftsFeedAPIMerge.log;

--remove header rows
/**
delete from stg.msn_ad_api_daily t
where to_number(regexp_replace(clicks, ',', '')) > (select 0.49*sum(to_number(regexp_replace(clicks, ',', '')))
	from stg.google_ad_api_daily
	where account = t.account
	)
;
**/
delete from stg.msn_gifts_ad_api
where clickdate = to_date('&1', 'yyyy-mm-dd')
;
commit;

delete from stg.msn_gifts_ad_api_imp
where clickdate = to_date('&1', 'yyyy-mm-dd')
;
commit;

insert into stg.msn_gifts_ad_api_imp
(
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
DestinationURL,
adid,
Currencycode,
Imp,
Clicks,
CTR,
AvgCPC,
TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
) 
select 
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
DestinationURL,
substr(replace(REGEXP_REPLACE(destinationurl,'.*adid=(.*_mbs|.*_mes|.*_mps|.*_{MatchType}_ms|.*_m{MatchType}s).*','\1'), '{MatchType}', decode(DeliveredMatchType, 'Broad', 'b', 'Exact', 'e', 'Phrase', 'p')), 1, 50),
Currencycode,
to_number(regexp_replace(Imp, ',', '')),
to_number(regexp_replace(Clicks, ',', '')),
CTR,
AvgCPC,
to_number(regexp_replace(TotalCost, ',', '')),
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
from stg.msn_gifts_ad_api_daily
;

--specifying -1 in instr function find the position of the last pattern
commit;

/**
update stg.msn_ad_api_imp
set adid = replace(adid, '{MatchType}', decode(DeliveredMatchType, 'Broad', 'b', 'Exact', 'e', 'Phrase', 'p'))
where adid like '%_{MatchType}_ms' or adid like '%_m{MatchType}s%'
;
commit;
**/

insert into stg.msn_gifts_ad_api
(
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
--DestinationURL,
adid,
Currencycode,
Imp,
Clicks,
CTR,
AvgCPC,
TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
)
select
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
--DestinationURL,
adid,
Currencycode,
Imp,
Clicks,
CTR,
AvgCPC,
TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
from stg.msn_gifts_ad_api_imp
where clickdate = to_date('&1', 'yyyy-mm-dd')
and (clicks <> 0 or totalcost <> 0)
;

commit;

truncate table stg.msn_gifts_ad_api_daily
;

spool off

quit;

