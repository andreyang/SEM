
column a new_val dd;
column b new_val tt;
column c new_val hh;
column d new_val nh;
column e new_val mm;

select
  '&1' a,
  '&2' b,
  decode('&2','d', 0,'&3') c,
  decode('&2','d',24,1+&3) d,
  to_char(to_date('&1','yyyymmdd'),'yyyymm')||'01' e
from dual
;

drop table ap_temp_ipfraud_p_&&tt purge;
drop table ap_temp_ipfraud_p2_&&tt purge;
drop table ap_temp_ipfraud_mbl_&&tt purge;
drop table ap_temp_ipfraud_mbl2_&&tt purge;
drop table ap_temp_ipfraud_c_&&tt purge;
drop table ap_temp_ipfraud_c2_&&tt purge;
drop table ap_temp_ipfraud_f_&&tt purge;
drop table ap_temp_ipfraud_f2_&&tt purge;
drop table ap_temp_ipfraud_pcn_&&tt purge;
drop table ap_temp_ipfraud_&&tt purge;


set linesize 500;
set trimspool on;
set heading off;
set serveroutput on;
set timing on;

create table ap_temp_ipfraud_p_&&tt nologging as
select
  ar.ipaddress,
  count(*) imps,
  sum(decode(ar.type,'ProductRedirectionResponse',1,'AdWordRedirectionResponse',1,0)) clks
from stg.comm_all_request partition (part_&&mm) ar
where ar.type != 'PAPI'
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = ar.ipaddress)
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = ar.ipaddress)
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by ar.ipaddress
;

create table ap_temp_ipfraud_p2_&&tt nologging as
select distinct
  ipaddress  
from stg.comm_redirect_event partition (part_&&mm) re
where not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
and   not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = re.ipaddress)
and re.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and re.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by ipaddress, to_char(timestamp2,'yyyymmddhh24miss')
having count(distinct merchantproductid) > 5
union 
select distinct
  ipaddress
from stg.comm_adword_click partition (part_&&mm) re
where not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
and   not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = re.ipaddress)
and re.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and re.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by ipaddress, to_char(timestamp2,'yyyymmddhh24miss')
having count(distinct domain) > 5
union
select distinct ipaddress from
 (select ipaddress, count(*) over(partition by substr(ipaddress,1,instr(ipaddress,'.',-1,1)), to_char(timestamp2,'yyyymmddhh24miss')) cnt
  from stg.comm_adword_click partition (part_&&mm)
  where 1 = 1
  and timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
  and timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)) re
where cnt >= 10
and not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
and not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = re.ipaddress)
;

create table ap_temp_ipfraud_mbl_&&tt nologging as
select
  ar.ipaddress,
  count(*) imps,
  sum(decode(ar.type,'productRedirect',1,'adSenseRedirect',1,0)) clks
from mbl.all_request partition (part_&&mm) ar
where not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = ar.ipaddress)
and   not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = ar.ipaddress)
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
group by ar.ipaddress
;

create table ap_temp_ipfraud_mbl2_&&tt nologging as
select distinct
  ipaddress
from mbl.product_redirect partition (part_&&mm) re
where not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
and   not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = re.ipaddress)
and re.timestamp2 >= to_date('&&dd','yyyymmdd')
and re.timestamp2  < to_date('&&dd','yyyymmdd')+1
group by ipaddress, to_char(timestamp2,'yyyymmddhh24miss')
having count(distinct merchantproductid) >= 5
union
select distinct
  ipaddress
from mbl.adword_redirect partition (part_&&mm) re
where not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
and   not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = re.ipaddress)
and re.timestamp2 >= to_date('&&dd','yyyymmdd')
and re.timestamp2  < to_date('&&dd','yyyymmdd')+1
group by ipaddress, to_char(timestamp2,'yyyymmddhh24miss')
having count(distinct domain) >= 3
;

create table ap_temp_ipfraud_c_&&tt nologging as
select
  ar.ipaddress,
  count(*) imps,
  sum(decode(ar.type,'ProductRedirectionResponse',1,'RedirectionResponse',1,0)) clks
from stg.all_request ar
where ar.type != 'PAPI'
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = ar.ipaddress)
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = ar.ipaddress)
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by ar.ipaddress
;

create table ap_temp_ipfraud_c2_&&tt nologging as
select distinct
  ipaddress  
from stg.redirect_event re
where not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
and   not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = re.ipaddress)
and re.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and re.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by ipaddress, to_char(timestamp2,'yyyymmddhh24miss')
having count(distinct merchantproductid) > 5
;

create table ap_temp_ipfraud_f_&&tt nologging as
select
  ar.ipaddress,
  count(*) imps,
  sum(decode(ar.type,'redirect-product',1,'redirect-adwords',1,0)) clks
from flanker.all_request partition (part_&&mm) ar
where ar.type != 'PAPI'
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = ar.ipaddress)
and not exists (select /*+ dynamic_sampling (ar 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = ar.ipaddress)
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by ar.ipaddress
; 

create table ap_temp_ipfraud_f2_&&tt nologging as
select distinct
  ipaddress  
from flanker.product_redirect partition (part_&&mm) re
where not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress)
and   not exists (select /*+ dynamic_sampling (re 3) dynamic_sampling (a 3) */ * from stg.allowed_ip a where ipaddress = re.ipaddress)
and re.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and re.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by ipaddress, to_char(timestamp2,'yyyymmddhh24miss')
having count(distinct merchantproductid) > 5
;

create table ap_temp_ipfraud_pcn_&&tt nologging as
select
  p.ipaddress,
  count(*) imps,
  sum(decode(p.pagetype,'ML',1,'ASL',1,0)) clks
from pcn.page partition (part_&&mm) p
where not exists (select /*+ dynamic_sampling (p 3) dynamic_sampling (b 3) */ * from pcn.banned_ip b where ipaddress = p.ipaddress)
and   not exists (select /*+ dynamic_sampling (p 3) dynamic_sampling (a 3) */ * from pcn.allowed_ip a where ipaddress = p.ipaddress)
and p.timestamp2 >= to_date('&&dd','yyyymmdd')+(&&hh/24)
and p.timestamp2  < to_date('&&dd','yyyymmdd')+(&&nh/24)
group by p.ipaddress
;

create table ap_temp_ipfraud_&&tt nologging as
select ipaddress, site, max(note) note from (
  select 
    'pronto' site, ipaddress,
    case
      when ipaddress like '172.16.%' then 'internal'
      when ipaddress like '192.168.%' then 'internal'
      when ipaddress like '10.%' then 'internal'
      when imps >= 1000 then 'ip with 1000 impressions in a day'
      when clks >=  100 then 'ip with 100 clicks in a day'
    end note
  from ap_temp_ipfraud_p_&&tt
  where imps >= 1000
  or clks >= 100
  or ipaddress like '172.16.%'
  or ipaddress like '192.168.%'
  --or ipaddress like '10.%'
  UNION ALL
  select
    'pronto' site, ipaddress,
    '5 leads in 1 second' note
  from ap_temp_ipfraud_p2_&&tt
  UNION ALL
  select 
    'pronto' site, ipaddress,
    case
      when ipaddress like '172.16.%' then 'internal'
      when ipaddress like '192.168.%' then 'internal'
      when ipaddress like '10.%' then 'internal'
      when imps >= 1000 then 'ip with 1000 impressions in a day'
      when clks >=  100 then 'ip with 100 clicks in a day'
    end note
  from ap_temp_ipfraud_mbl_&&tt
  where imps >= 1000
  or clks >= 100
  or ipaddress like '172.16.%'
  or ipaddress like '192.168.%'
  --or ipaddress like '10.%'
  UNION ALL
  select
    'pronto' site, ipaddress,
    '5 leads in 1 second' note
  from ap_temp_ipfraud_mbl2_&&tt
  UNION ALL
  select 
    'pronto' site, ipaddress,
    case
      when ipaddress like '172.16.%' then 'internal'
      when ipaddress like '192.168.%' then 'internal'
      when ipaddress like '10.%' then 'internal'
      when imps >= 1000 then 'ip with 1000 impressions in a day (cobrand)'
      when clks >=  100 then 'ip with 100 clicks in a day (cobrand)'
    end note
  from ap_temp_ipfraud_c_&&tt
  where imps >= 1000
  or clks >= 100
  or ipaddress like '172.16.%'
  or ipaddress like '192.168.%'
  --or ipaddress like '10.%'
  UNION ALL
  select
    'pronto' site, ipaddress,
    '5 leads in 1 second' note
  from ap_temp_ipfraud_c2_&&tt
  UNION ALL
  select 
    'pronto' site, ipaddress,
    case
      when ipaddress like '172.16.%' then 'internal'
      when ipaddress like '192.168.%' then 'internal'
      when ipaddress like '10.%' then 'internal'
      when imps >= 1000 then 'ip with 1000 impressions in a day (flanker)'
      when clks >=  100 then 'ip with 100 clicks in a day (flanker)'
    end note
  from ap_temp_ipfraud_f_&&tt
  where imps >= 1000
  or clks >= 100
  or ipaddress like '172.16.%'
  or ipaddress like '192.168.%'
  --or ipaddress like '10.%'
  UNION ALL
  select
    'pronto' site, ipaddress,
    '5 leads in 1 second' note
  from ap_temp_ipfraud_f2_&&tt
  UNION ALL
  select
    'pcn' site, ipaddress,
    case
      when ipaddress like '172.16.%' then 'internal'
      when ipaddress like '192.168.%' then 'internal'
      when ipaddress like '10.%' then 'internal'
      when imps >= 1000 then 'ip with 1000 impressions in a day (pcn)'
      when clks >=  100 then 'ip with 100 clicks in a day (pcn)'
    end note
  from ap_temp_ipfraud_pcn_&&tt
  where imps >= 1000
  or clks >= 100
  or ipaddress like '172.16.%'
  or ipaddress like '192.168.%'
  --or ipaddress like '10.%'
) group by ipaddress, site
;

/**
6/24/2011 - this offers no help
declare
  val raw(2000);
  md varchar2(50);
begin
  for y in 
   (select ipaddress, note||' (from pronto)' note 
    from ap_temp_ipfraud_&&tt
    where site = 'pronto')
  loop 
    val := utl_raw.cast_to_raw(y.ipaddress);
    md := dbms_obfuscation_toolkit.md5(input => val);
    insert into ap_temp_ipfraud_&&tt (ipaddress, note, site)
    select md, y.note, 'de'
    from dual
    where not exists
     (select * from de.banned_ip where ipaddress = md)
    and not exists
     (select * from ap_temp_ipfraud_&&tt where ipaddress = md and sited = 'de');
  end loop;
  commit;
end;
/
**/

insert into stg.banned_ip
 (ipaddress, note)
select
  ipaddress, note
from ap_temp_ipfraud_&&tt
where site = 'pronto'
;

insert into stg.banned_ip@DWI_link
 (ipaddress, note)
select
  ipaddress, note
from ap_temp_ipfraud_&&tt
where site = 'pronto'
;

insert into pcn.banned_ip
 (ipaddress, note)
select
  ipaddress, note
from ap_temp_ipfraud_&&tt
where site = 'pcn'
;

commit;

spool /home/dw/apicker/Logs/ip_fraud.&&tt..log;

select
  site||' | '||
  ipaddress||' | '||
  note
from
 (select
    'pronto' site,
    ipaddress,
    note
  from stg.banned_ip
  where createddate >= to_date('&&dd','yyyymmdd')
  and createddate < to_date('&&dd','yyyymmdd')+1
  UNION ALL
  select
    'pcn' site,
    ipaddress,
    note
  from pcn.banned_ip
  where createddate >= to_date('&&dd','yyyymmdd')
  and createddate < to_date('&&dd','yyyymmdd')+1
)
order by site desc, ipaddress
;

spool off;
set timing off;
spool /home/dw/apicker/Logs/ip_fraud.warn.log;

select 'Warning: no pronto IPs added since '||to_char(max(createddate),'mm/dd/yyyy')
from stg.banned_ip
where '&&tt' = 'd'
having trunc(max(createddate)) < trunc(sysdate-3)
;

spool off;

drop table ap_temp_ipfraud_p_&&tt purge;
drop table ap_temp_ipfraud_p2_&&tt purge;
drop table ap_temp_ipfraud_c_&&tt purge;
drop table ap_temp_ipfraud_c2_&&tt purge;
drop table ap_temp_ipfraud_f_&&tt purge;
drop table ap_temp_ipfraud_f2_&&tt purge;
drop table ap_temp_ipfraud_pcn_&&tt purge;
drop table ap_temp_ipfraud_&&tt purge;

quit;



