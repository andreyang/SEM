/**
have a lower ceiling than yahoo .75 vs .88
have a lower margin target than yahoo
always bid lt least 1 cent lower than yahoo
and always bid least 1 cent lower than yahoo cpc
**/
spool /home/dw/ayang/Log/bids_yahoo_md.log

drop table ay_temp_md_kwid purge
;

create table ay_temp_md_kwid tablespace stage_temp_data nologging as
select distinct
        adid,
        mexpcategoryid,
        prontoadgroupid,
        adgroup,
        adgroupid,
        campaign,
        campaignid,
        keywordid,
        lower(replace(account, ' ', '')) accountname,
	accountid,
        keyword,
	matchtype,
	case when lower(keyword) like '%halloween%' or lower(keyword) like '%costume%' 
	then 'y' else 'n' end seasonal_flag,
--        'n' seasonal_flag,
	cpc,
        averageposition,
        creativeid
--,
--      keyworddestinationurl
from (
select  adid,
        REGEXP_REPLACE(adid,'s[[:digit:]]{1,4}-([[:digit:]]{1,6})-.*','\1') mexpcategoryid,
        REGEXP_REPLACE(adid,'-[[:digit:]]{1,6}_y.*s', '') prontoadgroupid,
        adgroup,
        adgroupid,
        campaign,
        campaignid,
        keywordid,
        account,
	accountid,
        keyword,
	matchtype,
        maximumcpc cpc,
        averageposition,
        creativeid,
--      url keyworddestinationurl,
        RANK() OVER (PARTITION BY keywordid, adgroupid, campaignid, account ORDER BY clickdate desc, adid, network desc, averageposition, creativeid) rk
from stg.md_yahoo_ad_api
where adid is not null
and clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) 
and clickdate <> '08-Mar-2012' and clickdate <> '12-Mar-2012' and clickdate <> '18-Mar-2012'
and clicks > 0
)
where rk = 1
;
commit;

drop table ay_temp_hv_md_cost1 purge;

create table ay_temp_hv_md_cost1 tablespace stage_temp_data nologging as
select  adid, sum(cost) cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.md_yahoo_ad_api
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) 
and clickdate <> '08-Mar-2012' and clickdate <> '12-Mar-2012' and clickdate <> '18-Mar-2012'
and adid is not null
group by adid
having sum(clicks) >= 25
;
commit;

drop table ay_temp_hv_md_rev1 purge
;

create table ay_temp_hv_md_rev1 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, 1.0*rev1 rev, ml1 ml, 0 ad_lead
from ay_temp_hv_md_cost1 t, dw.merchant_lead_bid_md ml
where t.adid = ml.adid
union all
select t.adid, 1.1*rev1, 0, ad_lead1 ad_lead
from ay_temp_hv_md_cost1 t, dw.adword_adid_bid_md ad
where t.adid = ad.adid
)
group by adid
;
commit;

drop table ay_temp_md_bids1 purge;

create table ay_temp_md_bids1 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.accountid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
        t.adid,
        trunc(least(45, (case when t.averageposition >= 5 then 1.0 else decode(t4.adid, null, 1.000, t4.margin_target) end)*nvl(t2.revenue,0)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
	t.matchtype, 
	t.cpc,
	t.seasonal_flag
from ay_temp_md_kwid t, ay_temp_hv_md_cost1 t1, ay_temp_hv_md_rev1 t2, stg.seasonal_campaign t3, stg.break_even_pool t4
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t1.adid = t4.adid(+)
and   t.campaignid = t3.campaignid(+)
and   (t1.clicks >= 50 or (nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) <= 0.2))
--and not exists (select * from ay_temp_y_opt_bid where adid = t1.adid)
;
commit;

-- 4 weeks

drop table ay_temp_hv_md_cost4 purge;

create table ay_temp_hv_md_cost4 tablespace stage_temp_data nologging as
select  adid, sum(cost) cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.md_yahoo_ad_api
where clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate) 
and clickdate <> '08-Mar-2012' and clickdate <> '12-Mar-2012' and clickdate <> '18-Mar-2012'
and adid is not null
--and url not like '%adid=%adid=%'
group by adid
having sum(clicks) >= 10
;
commit;

drop table ay_temp_hv_md_rev4 purge
;

create table ay_temp_hv_md_rev4 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, 1.0*rev4 rev, ml4 ml, 0 ad_lead
from ay_temp_hv_md_cost4 t, dw.merchant_lead_bid_md ml
where t.adid = ml.adid
union all
select t.adid, 1.1*rev4, 0, ad_lead4 ad_lead
from ay_temp_hv_md_cost4 t, dw.adword_adid_bid_md ad
where t.adid = ad.adid
)
group by adid
;
commit;

drop table ay_temp_md_bids4 purge;

create table ay_temp_md_bids4 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.accountid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
        t.adid,
        trunc(least(45, (case when t.averageposition >= 5 then 1.0 else decode(t4.adid, null, 1.000, t4.margin_target) end)*nvl(t2.revenue,0)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.matchtype,
        t.cpc,
	t.seasonal_flag
from ay_temp_md_kwid t, ay_temp_hv_md_cost4 t1, ay_temp_hv_md_rev4 t2, stg.seasonal_campaign t3, stg.break_even_pool t4
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t1.adid = t4.adid(+)
and   t.campaignid = t3.campaignid(+)
--and not exists (select * from ay_temp_y_opt_bid where adid = t1.adid)
;
commit;

drop table ay_temp_hv_md_cost8 purge;

create table ay_temp_hv_md_cost8 tablespace stage_temp_data nologging as
select 	adid, sum(cost) cost, sum(clicks) clicks, 
	sum(impressions) impressions
from stg.md_yahoo_ad_api
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate)  
and clickdate <> '08-Mar-2012' and clickdate <> '12-Mar-2012' and clickdate <> '18-Mar-2012'
and adid is not null
--and url not like '%adid=%adid=%'
group by adid
having sum(clicks) >= 10
;
commit;

/**
drop table ay_temp_hv_grp_md_cost8 purge;
create table ay_temp_hv_grp_md_cost8 tablespace stage_temp_data nologging as
select  adid, adgroupid, campaignid, lower(account) accountname, sum(cost) cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.md_yahoo_ad_api
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) 
and clickdate <> '08-Mar-2012' and clickdate <> '12-Mar-2012' and clickdate <> '18-Mar-2012'
and adid is not null
--and url not like '%adid=%adid=%'
and (adgroupid, campaignid, account) IN
        (select adgroupid, campaignid, account from stg.md_yahoo_ad_api
        where clickdate >= trunc(sysdate) - 56
        and clickdate < trunc(sysdate) 
	and clickdate <> '08-Mar-2012' and clickdate <> '12-Mar-2012' and clickdate <> '18-Mar-2012'
	and adid is not null
	--and url not like '%adid=%adid=%'
        group by adgroupid, campaignid, account
        having sum(clicks) >= 25
        )
group by adid, adgroupid, campaignid, lower(account);
**/

drop table ay_temp_hv_md_rev8 purge
;

create table ay_temp_hv_md_rev8 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from 
(
select t.adid, 1.0*rev8 rev, ml8 ml, 0 ad_lead
from ay_temp_hv_md_cost8 t, dw.merchant_lead_bid_md ml
where t.adid = ml.adid
union all
select t.adid, 1.15*rev8, 0, ad_lead8 ad_lead
from ay_temp_hv_md_cost8 t, dw.adword_adid_bid_md ad
where t.adid = ad.adid
)
group by adid
;
commit;

/**
drop table ay_temp_hv_grp_md_rev8 purge;
create table ay_temp_hv_grp_md_rev8 tablespace stage_temp_data nologging as
select adgroupid, campaignid, accountname, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from 
(
select t.adgroupid, t.campaignid, t.accountname, sum(rev8/t1.ct) rev, sum(ml8/t1.ct) ml, 0 ad_lead
from ay_temp_hv_grp_md_cost8 t, (select adid, count(*) ct from ay_temp_hv_grp_md_cost8 group by adid) t1, dw.merchant_lead_bid_md ml
where t.adid = ml.adid
and t.adid = t1.adid
group by t.adgroupid, t.campaignid, t.accountname
union all
select t.adgroupid, t.campaignid, t.accountname, sum(1.15*rev8/t1.ct), 0 ml, sum(ad_lead8/t1.ct) ad_lead
from ay_temp_hv_grp_md_cost8 t, (select adid, count(*) ct from ay_temp_hv_grp_md_cost8 group by adid) t1, dw.adword_adid_bid_md ad
where t.adid = ad.adid
and t.adid = t1.adid
group by t.adgroupid, t.campaignid, t.accountname
)
group by adgroupid, campaignid, accountname;
**/

drop table ay_temp_md_bids8 purge;

create table ay_temp_md_bids8 tablespace stage_temp_data nologging as
select distinct
	t.accountname,
	t.accountid,
	t.campaign,
	t.campaignid,
	t.adgroup,
	t.prontoadgroupid,
	t.adgroupid,
	t.keywordid,
	t.adid,
	trunc(least(45, (case when t.averageposition >= 5 then 1.0 else decode(t4.adid, null, 1.000, t4.margin_target) end)*nvl(t2.revenue,0)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
	nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
	t.averageposition,
	t.keyword,
        t.matchtype,
        t.cpc,
	t.seasonal_flag
from ay_temp_md_kwid t, ay_temp_hv_md_cost8 t1, ay_temp_hv_md_rev8 t2, stg.seasonal_campaign t3, stg.break_even_pool t4
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t1.adid = t4.adid(+)
and   t.campaignid = t3.campaignid(+)
--and not exists (select * from ay_temp_y_opt_bid where adid = t1.adid)
;
commit;

/**
drop table ay_temp_grp_md_bids8 purge;

create table ay_temp_grp_md_bids8 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.accountid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
        t.adid,
        trunc(least(45, (case when t.averageposition >= 10 then 1.0 else 1.000 end)*nvl(t2.revenue,0)/t1.clicks), 2) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.matchtype,
        t.cpc
from ay_temp_md_kwid t, (select adgroupid, campaignid, accountname, sum(cost) cost, sum(clicks) clicks from ay_temp_hv_grp_md_cost8 group by adgroupid, campaignid, accountname) t1, ay_temp_hv_grp_md_rev8 t2
where t1.adgroupid = t.adgroupid
and   t1.campaignid = t.campaignid
and   t1.accountname = t.accountname
and   t1.adgroupid = t2.adgroupid(+)
and   t1.campaignid = t2.campaignid(+)
and   t1.accountname = t2.accountname(+)
--and not exists (select * from ay_temp_y_opt_bid where adid = t.adid)
;
**/

drop table ay_temp_md_bids_final purge;

create table ay_temp_md_bids_final tablespace stage_temp_data nologging as 
select distinct
	accountname,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        rpc,
        roi,
        averageposition,
        keyword,
        matchtype,
	cpc,
        'HV - 1 wk 25' type,
	least(t.rpc, nvl(1.30*cpc, t.rpc)) rpc_final,
	seasonal_flag
from ay_temp_md_bids1 t
where (roi < 1/1.000 or rpc < cpc or averageposition > 3)
--and rpc >= 0.07
/**
and not exists (select * from stg.yahoo_md_bid_history
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        and type like 'deleted%'
        )
**/
union all
select distinct
	accountname,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        rpc,
        roi,
        averageposition,
        keyword,
        matchtype,
	cpc,
        'HV - 4 wk 10' type,
	least(t.rpc, nvl(1.30*cpc, t.rpc)) rpc_final,
	seasonal_flag
from ay_temp_md_bids4 t
where (roi < 1/1.000 or rpc < cpc or averageposition > 3)
--and rpc >= 0.07
/**
and not exists (select * from stg.yahoo_md_bid_history
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        and type like 'deleted%'
        )
**/
and not exists (select * from ay_temp_md_bids1
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountid = t.accountid
        )
union all
select distinct
	accountname,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
	rpc,
        roi,
        averageposition,
        keyword,
        matchtype,
	cpc,
        'HV - 8 wk 10' type,
	least(t.rpc, nvl(1.30*cpc, t.rpc)) rpc_final,
	seasonal_flag
from ay_temp_md_bids8 t
where (roi < 1/1.000 or rpc < cpc or averageposition > 3)
--and rpc >= 0.07
/**
and not exists (select * from stg.yahoo_md_bid_history
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        and type like 'deleted%'
        )
**/
and not exists (select * from ay_temp_md_bids1
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountid = t.accountid
        )
and not exists (select * from ay_temp_md_bids4
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountid = t.accountid
        )
;

commit;

spool off

set heading off
set trimspool on
set linesize 300

spool &1
--/home/dw/ayang/Log/bids_yahoo_md.txt

select 	distinct
	--t.accountname||'|'||
	to_char(t.accountid)||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
        greatest(1, trunc(t.rpc_final*decode(trim(to_char(sysdate, 'DAY')), 'FRIDAY', 1.025, 'SATURDAY', 1.025, 'SUNDAY', 1.025, 1.0)))||'|'||
        lower(substr(t.matchtype, 1, 1))||'|'||
	--'p'||'|'||
        t.adid||'|'||
        to_char(t.campaignid)
from ay_temp_md_bids_final t
where exists (select avg(rpc) from ay_temp_md_bids_final having avg(rpc) < 25)
--where seasonal_flag = 'y'
;

spool off

insert into stg.yahoo_md_bid_history
(
        accountname,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        rpc,
        roi,
        averageposition,
        keyword,
	cpc,
        type
)
select distinct
        accountname,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
	greatest(1, trunc(t.rpc_final*decode(trim(to_char(sysdate, 'DAY')), 'FRIDAY', 1.025, 'SATURDAY', 1.025, 'SUNDAY', 1.025, 1.0))),
	roi,
        averageposition,
        keyword,
	cpc,
	type
from ay_temp_md_bids_final t
where exists (select avg(rpc) from ay_temp_md_bids_final having avg(rpc) < 25)
;

commit;

drop table ay_temp_md_kwid purge;
drop table ay_temp_hv_md_cost1 purge;
drop table ay_temp_hv_md_rev1 purge;
drop table ay_temp_md_bids1 purge;
drop table ay_temp_hv_md_cost4 purge;
drop table ay_temp_hv_md_rev4 purge;
drop table ay_temp_md_bids4 purge;
drop table ay_temp_hv_md_cost8 purge;
--drop table ay_temp_hv_grp_md_cost8 purge;
drop table ay_temp_hv_md_rev8 purge;
--drop table ay_temp_hv_grp_md_rev8 purge;
drop table ay_temp_md_bids8 purge;
--drop table ay_temp_grp_md_bids8 purge;
--drop table ay_temp_md_bids_final purge;

quit;
