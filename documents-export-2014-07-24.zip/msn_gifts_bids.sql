spool /home/dw/ayang/Log/bids_msn_gifts.log

drop table ay_temp_msn_gft_kwid purge;

create table ay_temp_msn_gft_kwid tablespace stage_temp_data nologging as
select distinct
	adid, 
	mexpcategoryid,
	prontoadgroupid,
	adgroup, 
	adgroupid, 
	campaign,
	campaignid,
	keywordid,
   	accountname,
   	keyword,
	case when lower(keyword) like '%halloween%' or lower(keyword) like '%costume%' 
	or lower(keyword) like '%pumpkin carv%' then 'y' else 'n' end seasonal_flag,
	--'n' seasonal_flag,
	--case when clickdate >= trunc(sysdate) - 2 then maximumcpc else null end maximumcpc,
	maximumcpc,
	averageposition,
	creativeid,
--	keyworddestinationurl,
   	keywordtype,
	clickdate
from (
select 	adid, 
	REGEXP_REPLACE(adid,'s[[:digit:]]{1,4}-([[:digit:]]{1,6})-.*','\1') mexpcategoryid,
	REGEXP_REPLACE(adid,'-[[:digit:]]{1,6}_m.*s', '') prontoadgroupid,
	ordername adgroup, 
	orderid adgroupid, 
	campaign,
   	campaignid,
   	orderitemid keywordid,
   	account accountname,
   	keyword,
   	currentmaximumcpc maximumcpc,
   	avgpos averageposition,
   	msnadid creativeid,
--  	destinationurl keyworddestinationurl,
   	lower(substr(deliveredmatchtype, 1, 1)) keywordtype,
	clickdate,
   	RANK() OVER (PARTITION BY orderitemid, orderid, deliveredmatchtype, campaignid, account ORDER BY clickdate desc, adid, avgpos, msnadid, distchannel) rk
from stg.msn_gifts_ad_api 
where --if there was no activity in the past 7 days, why do we need to make bid change as there is no new info?
clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
--MT migration finished on 8/25/2012
and clickdate >= '27-Aug-2012'
and adid is not null
and clicks > 0
) 
where rk = 1
;
commit;

drop table ay_temp_hv_msn_gft_cost1 purge;

create table ay_temp_hv_msn_gft_cost1 tablespace stage_temp_data nologging as
select 	adid, sum(totalcost) cost, sum(clicks) clicks, 
	sum(Imp) impressions
from stg.msn_gifts_ad_api
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
and adid is not null
group by adid
having sum(clicks) >= 25
;
commit;

drop table ay_temp_hv_msn_gft_rev1 purge;

create table ay_temp_hv_msn_gft_rev1 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev1 rev, ml1 ml, 0 ad_lead
from ay_temp_hv_msn_gft_cost1 t, dw.merchant_lead_bid_gf ml
where t.adid = ml.adid
union all
select t.adid, .53*rev1, 0, ad_lead1
from ay_temp_hv_msn_gft_cost1 t, dw.adword_adid_bid_gf ad
where t.adid = ad.adid
)
group by adid
;
commit;

drop table ay_temp_msn_gft_bids1 purge;

--SEASONAL KEYWORD'S BIDS ARE CONTROLLED BY THE NUMBER AFTER y.
create table ay_temp_msn_gft_bids1 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t.averageposition >= 10 then .95 else .850 end)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.keywordtype,
	t1.clicks
from ay_temp_msn_gft_kwid t, ay_temp_hv_msn_gft_cost1 t1, ay_temp_hv_msn_gft_rev1 t2, stg.seasonal_campaign t3
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t.campaignid = t3.campaignid(+)
and   (t1.clicks >= 50 or (nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) <= 0.2))
;
commit;

drop table ay_temp_hv_msn_gft_cost4 purge;

create table ay_temp_hv_msn_gft_cost4 tablespace stage_temp_data nologging as
select  adid, sum(totalcost) cost, sum(clicks) clicks,
        sum(Imp) impressions
from stg.msn_gifts_ad_api
where clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013' 
and adid is not null
group by adid
having sum(clicks) >= 10
;
commit;

drop table ay_temp_hv_msn_gft_rev4 purge;

create table ay_temp_hv_msn_gft_rev4 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev4 rev, ml4 ml, 0 ad_lead
from ay_temp_hv_msn_gft_cost4 t, dw.merchant_lead_bid_gf ml
where t.adid = ml.adid
union all
select t.adid, .53*rev4, 0, ad_lead4 
from ay_temp_hv_msn_gft_cost4 t, dw.adword_adid_bid_gf ad
where t.adid = ad.adid
)
group by adid
;
commit;

drop table ay_temp_msn_gft_bids4 purge;

create table ay_temp_msn_gft_bids4 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t.averageposition >= 10 then .95 else .850 end)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.keywordtype,
	t1.clicks
from ay_temp_msn_gft_kwid t, ay_temp_hv_msn_gft_cost4 t1, ay_temp_hv_msn_gft_rev4 t2, stg.seasonal_campaign t3
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t.campaignid = t3.campaignid(+)
;
commit;

drop table ay_temp_hv_msn_gft_cost8 purge;

create table ay_temp_hv_msn_gft_cost8 tablespace stage_temp_data nologging as
select  adid, sum(totalcost) cost, sum(clicks) clicks,
        sum(Imp) impressions
from stg.msn_gifts_ad_api
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013' 
and adid is not null
group by adid
having sum(clicks) >= 10
;
commit;

drop table ay_temp_hv_msn_gft_rev8 purge;

create table ay_temp_hv_msn_gft_rev8 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev8 rev, ml8 ml, 0 ad_lead
from ay_temp_hv_msn_gft_cost8 t, dw.merchant_lead_bid_gf ml
where t.adid = ml.adid
union all
select t.adid, .53*rev8, 0, ad_lead8
from ay_temp_hv_msn_gft_cost8 t, dw.adword_adid_bid_gf ad
where t.adid = ad.adid
)
group by adid
;
commit;

drop table ay_temp_msn_gft_bids8 purge;

create table ay_temp_msn_gft_bids8 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t.averageposition >= 10 then .95 else .850 end)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.keywordtype,
	t1.clicks
from ay_temp_msn_gft_kwid t, ay_temp_hv_msn_gft_cost8 t1, ay_temp_hv_msn_gft_rev8 t2, stg.seasonal_campaign t3
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t.campaignid = t3.campaignid(+)
;
commit;

/**
drop table ay_temp_hv_grp_msn_gft_cost8 purge;

create table ay_temp_hv_grp_msn_gft_cost8 tablespace stage_temp_data nologging as
select regexp_replace(adid, '_mes|_mbs|_mps', '') adid_comm,
       sum(totalcost) cost,
       sum(clicks) clicks,
       sum(imp) impressions
from stg.msn_gifts_ad_api
where clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
and adid is not null
group by regexp_replace(adid, '_mes|_mbs|_mps', '')
having sum(clicks) >= 10
;

drop table ay_temp_hv_grp_msn_gft_rev8 purge;

create table ay_temp_hv_grp_msn_gft_rev8 tablespace stage_temp_data nologging as
select adid_comm, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid_comm, sum(rev4) rev, sum(ml4) ml, 0 ad_lead
from ay_temp_hv_grp_msn_gft_cost8 t, dw.merchant_lead_bid_gf ml
where t.adid_comm = regexp_replace(ml.adid, '_mes|_mbs|_mps', '')
group by t.adid_comm
union all
select t.adid_comm, sum(.53*rev4), 0, sum(ad_lead4) ad_lead
from ay_temp_hv_grp_msn_gft_cost8 t, dw.adword_adid_bid_gf ad
where t.adid_comm = regexp_replace(ad.adid, '_mes|_mbs|_mps', '')
group by t.adid_comm
)
group by adid_comm
;

drop table ay_temp_grp_msn_gft_bids8 purge;
create table ay_temp_grp_msn_gft_bids8 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t.averageposition >= 10 then .95 else .850 end)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1)*(case where t.adid like '%_mbs' then .8 where t.adid like '%_mps' then .9 else 1 end) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
	t.keywordtype,
	t1.clicks
from ay_temp_msn_gft_kwid t, ay_temp_hv_grp_msn_gft_cost8 t1, ay_temp_hv_grp_msn_gft_rev8 t2
where t1.adid_comm = regexp_replace(t.adid, '_mes|_mbs|_mps', '')
and   t1.adid_comm = t2.adid_comm(+)
;
**/

drop table ay_temp_msn_gft_bids_final purge;

create table ay_temp_msn_gft_bids_final tablespace stage_temp_data nologging as
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
        keywordtype,
        'HV -  25' type,
	clicks
from ay_temp_msn_gft_bids1 t
where (roi < 1/.850 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
union all
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
        keywordtype,
        'HV - 10 - 4wk' type,
	clicks
from ay_temp_msn_gft_bids4 t
where (roi < 1/.850 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
and not exists (select * from ay_temp_msn_gft_bids1
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
union all
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
        keywordtype,
        'HV - 10 - 8wk' type,
	clicks
from ay_temp_msn_gft_bids8 t
where (roi < 1/.850 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
and not exists (select * from ay_temp_msn_gft_bids1
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_msn_gft_bids4
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
/**
union all
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
        keywordtype,
        'HV -  adgrp15' type,
	clicks
from ay_temp_grp_msn_gft_bids8 t
where (roi < 1/.850 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
and not exists (select * from ay_temp_msn_gft_bids1
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_msn_gft_bids4
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_msn_gft_bids8
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
**/
;

spool off


set heading off
set trimspool on
set linesize 300

spool &1
--/home/dw/ayang/Log/bids_msn_gifts.txt

select distinct
	t.accountname||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
        --trunc(case when t.adid like '%mbs' and t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 1.0) < .03 then 0 else greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 1.0), 0.05) end, 2)||'|'||
	trunc(greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 1.0), 0.05), 2)||'|'||
	t.keywordtype||'|'||
        t.adid||'|'||
        to_char(t.campaignid)
from ay_temp_msn_gft_bids_final t
where exists (select avg(rpc) from ay_temp_msn_gft_bids_final having avg(rpc) < .3)
;

spool off

spool &2
--/home/dw/ayang/Log/bids_msn_gifts_0.txt

/**
select distinct
        t.accountname||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
        0||'|'||
        t.keywordtype||'|'||
        t.adid||'|'||
        to_char(t.campaignid)
from ay_temp_msn_gft_bids_final t
where rpc <= .01
and clicks >= 20
and exists (select avg(rpc) from ay_temp_msn_gft_bids_final having avg(rpc) < .3)
;
**/

select distinct
        t.accountname||'|'||
        t.campaign||'|'||
        to_char(t.campaignid)||'|'||
        t.adgroup||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
        t.adid||'|'||
        t.keyword||'|'||
        t.keywordtype
from ay_temp_msn_gft_bids_final t
where exists (select avg(rpc) from ay_temp_msn_gft_bids_final having avg(rpc) < .4)
and rpc <= .01 
and clicks >= 20
and type <> 'HV -  adgrp15'
and exists (select avg(rpc) from ay_temp_msn_gft_bids_final having avg(rpc) < .3)
;

spool off

insert into stg.msn_gifts_bid_history
(
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        rpc,
        roi,
        averageposition,
        keyword,
	keywordtype,
        type
)
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        trunc(case when t.adid like '%mbs' and t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 1.0) < .03 then 0 else greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 1.0), 0.05) end, 2),
        roi,
        averageposition,
        keyword,
	keywordtype,
        type
from ay_temp_msn_gft_bids_final t
where exists (select avg(rpc) from ay_temp_msn_gft_bids_final having avg(rpc) < .3)
;

commit;

drop table ay_temp_msn_gft_kwid purge;
drop table ay_temp_hv_msn_gft_cost1 purge;
drop table ay_temp_hv_msn_gft_rev1 purge;
drop table ay_temp_msn_gft_bids1 purge;
drop table ay_temp_hv_msn_gft_cost4 purge;
drop table ay_temp_hv_msn_gft_rev4 purge;
drop table ay_temp_msn_gft_bids4 purge;
drop table ay_temp_hv_msn_gft_cost8 purge;
drop table ay_temp_hv_msn_gft_rev8 purge;
drop table ay_temp_msn_gft_bids8 purge;
drop table ay_temp_hv_grp_msn_gft_cost8 purge;
drop table ay_temp_hv_grp_msn_gft_rev8 purge;
drop table ay_temp_grp_msn_gft_bids8 purge;
drop table ay_temp_msn_gft_bids_final purge;

quit;

