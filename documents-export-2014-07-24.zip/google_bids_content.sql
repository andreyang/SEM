spool /home/dw/ayang/Log/bids_google_content.log

/**
drop table ay_temp_hv_google_cost1_cont purge;

create table ay_temp_hv_google_cost1_cont tablespace stage_temp_data nologging as
select  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid, max(adgroupid) adgroupid, max(campaignid) campaignid,
        sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_content
where clickdate >= trunc(sysdate) - 1
and campaign in (select campaignname from titan.campaign@be1 where createddate >= '16-Mar-2012'
	and campaigntype = '2' and businessname = 'pronto.com'
)
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
;

update dw.adword_adid ad
set cpc_actual = 1.25*cpc
where ad.clickdate >= trunc(sysdate) - 1
and ad.channel = 'SEM'
and ad.adid like '%_gc'
and ad.siteid = 1
and not exists (select * from dw.adword_adid_cpc where adid = regexp_replace(ad.adid, '(\d)\D+$', '\1'))
and exists (select * from ay_temp_hv_google_cost1_cont t where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', ''))
;
**/

drop table ay_temp_google_kwid_cont purge;

create table ay_temp_google_kwid_cont tablespace stage_temp_data nologging as
select distinct
        adgroup,
	REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
	case when lower(adgroup) like '%halloween%' or lower(adgroup) like '%costume%' 
	then 'y' else 'n' end seasonal_flag,
        --'n' seasonal_flag,
	adgroupid,
        campaign,
        campaignid,
        accountname,
	customerid,
        maximumcpc,
        minimumcpc,
        averageposition,
        dailybudget
from (
select  
        adgroup,
        adgroupid,
        campaign,
        campaignid,
        accountname,
	customerid,
        maxcontentcpc/1000000 maximumcpc,
        minimumcpc/1000000 minimumcpc,
        averageposition,
        dailybudget/1000000 dailybudget,
        RANK() OVER (PARTITION BY adgroupid, campaignid, accountname ORDER BY clickdate desc, maximumcpc desc, keywordid, averageposition, creativeid) rk
from stg.google_ad_api_content t
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
--and accountname <> 'display1'
--financial terms
/**
and campaign not in ('21147.credit_card_gc',
'21148.commercial_loans_gc',
'21141.online_trading_gc',
'21142.refinance_gc',
'21143.debt_consolidation_gc'
)
**/
--and clicks > 0
--excluding google gadget campaigns
--and customerid <> 5756622725
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
)
where rk = 1
;

drop table ay_temp_hv_google_cost1_cont purge;

create table ay_temp_hv_google_cost1_cont tablespace stage_temp_data nologging as
select  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
	sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_content
where --accountname IN ('g4', 'g29', 'g30', 'g31', 'g32', 'g33', 'g34', 'g35', 'g36', 'g37', 'g39')
--and 
clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
having sum(clicks) >= 25
;


drop table ay_temp_hv_google_rev1_cont purge
;

create table ay_temp_hv_google_rev1_cont tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, sum(rev1) rev, sum(ml1) ml, 0 ad_lead
from ay_temp_hv_google_cost1_cont t, dw.merchant_lead_bid_pronto ml
where t.adid = REGEXP_REPLACE(ml.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
group by t.adid
union all
select t.adid, sum(1.0*rev1), 0, sum(ad_lead1) ad_lead
from ay_temp_hv_google_cost1_cont t, dw.adword_adid_bid_pronto ad
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
group by t.adid
/**
union all
--cap logo campaign's comtribution to 5 cents
select t.adid, least(.02,imps/1000*6/t.clicks)*t.clicks, 0, 0
from ay_temp_hv_google_cost1_cont t, (select adid, sum(imps) imps from dw.logo_campaign where clickdate >= trunc(sysdate) - 7 and clickdate < trunc(sysdate) group by adid) l
where t.adid = REGEXP_REPLACE(l.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
union all
--data not refreshed until 15:00
--cap rpc from cpm at .05
select t.adid, least(sum(revenue), .05*avg(clicks)), 0, 0
from dw.cpm_adid ad, ay_temp_hv_google_cost1_cont t,
--make sure that cpm did not totally disappear
(select REGEXP_REPLACE(adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') adid from dw.cpm_adid where clickdate >= trunc(sysdate) - 3 and adid like '%_gc' and siteid = 1 group by REGEXP_REPLACE(adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') having sum(revenue) > 0) t2
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
and t.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 7 - 1
and ad.clickdate < trunc(sysdate) - 1 and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and ad.adid like '%_gc'
and ad.siteid = 1
group by t.adid
union all
select t.adid, sum(guidestercpc), 0, 0
from dw.guidester_grid ad, ay_temp_hv_google_cost1_cont t,
--make sure that guidester feed did not disappear
(select distinct goldenproductid from stg.guidester_product_feed where clickdate >= trunc(sysdate)) t2
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
and ad.goldenproductid = t2.goldenproductid
and ad.clickdate >= trunc(sysdate) - 7
and ad.clickdate < trunc(sysdate) and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and ad.adid like '%_gc'
and ad.siteid = 1
group by t.adid
**/
)
group by adid
;


drop table ay_temp_google_bids1_cont purge;

--here is where we control the margin
--SEASONAL KEYWORD'S BIDS ARE CONTROLLED BY THE NUMBER AFTER y.
create table ay_temp_google_bids1_cont tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        trunc(least(.4, decode(t.accountname, 'g29', 1.000, 1.000)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
	t.maximumcpc,
	t.seasonal_flag
from ay_temp_google_kwid_cont t, ay_temp_hv_google_cost1_cont t1, ay_temp_hv_google_rev1_cont t2
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   (t1.clicks >= 50 or nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) <= 0.1)
;

drop table ay_temp_hv_google_cost4_cont purge;

create table ay_temp_hv_google_cost4_cont tablespace stage_temp_data nologging as
select  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
        sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_content
where --accountname IN ('g4', 'g29', 'g30', 'g31', 'g32', 'g33', 'g34', 'g35', 'g36', 'g37', 'g39')
--and 
clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate) and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
having sum(clicks) >= 10
;

drop table ay_temp_hv_google_rev4_cont purge;

create table ay_temp_hv_google_rev4_cont tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, sum(rev4) rev, sum(ml4) ml, 0 ad_lead
from ay_temp_hv_google_cost4_cont t, dw.merchant_lead_bid_pronto ml
where t.adid = REGEXP_REPLACE(ml.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
group by t.adid
union all
select t.adid, sum(1.0*rev4), 0, sum(ad_lead4) ad_lead
from ay_temp_hv_google_cost4_cont t, dw.adword_adid_bid_pronto ad
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
group by t.adid
/**
union all
--cap logo campaign's comtribution to 5 cents
select t.adid, least(.02,imps/1000*6/t.clicks)*t.clicks, 0, 0
from ay_temp_hv_google_cost4_cont t, (select adid, sum(imps) imps from dw.logo_campaign where clickdate >= trunc(sysdate) - 28 and clickdate < trunc(sysdate) group by adid) l
where t.adid = REGEXP_REPLACE(l.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
union all
--data not refreshed until 15:00
--cap rpc from cpm at .05
select t.adid, least(sum(revenue), .05*avg(clicks)), 0, 0
from dw.cpm_adid ad, ay_temp_hv_google_cost4_cont t,
--make sure that cpm did not totally disappear
(select REGEXP_REPLACE(adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') adid from dw.cpm_adid where clickdate >= trunc(sysdate) - 3 and adid like '%_gc' and siteid = 1 group by REGEXP_REPLACE(adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') having sum(revenue) > 0) t2
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
and t.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 28 - 1
and ad.clickdate < trunc(sysdate) - 1 and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and ad.adid like '%_gc'
and ad.siteid = 1
group by t.adid
union all
select t.adid, sum(guidestercpc), 0, 0
from dw.guidester_grid ad, ay_temp_hv_google_cost4_cont t,
--make sure that guidester feed did not disappear
(select distinct goldenproductid from stg.guidester_product_feed where clickdate >= trunc(sysdate)) t2
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
and ad.goldenproductid = t2.goldenproductid
and ad.clickdate >= trunc(sysdate) - 28
and ad.clickdate < trunc(sysdate) and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and ad.adid like '%_gc'
and ad.siteid = 1
group by t.adid
**/
)
group by adid
;

drop table ay_temp_google_bids4_cont purge;

--here is where we control the margin
create table ay_temp_google_bids4_cont tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        trunc(least(.4, decode(t.accountname, 'g29', 1.000, 1.000)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.maximumcpc,
	t.seasonal_flag
from ay_temp_google_kwid_cont t, ay_temp_hv_google_cost4_cont t1, ay_temp_hv_google_rev4_cont t2
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
;

drop table ay_temp_hv_google_cost8_cont purge;

create table ay_temp_hv_google_cost8_cont tablespace stage_temp_data nologging as
select  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
        sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_content
where --accountname IN ('g4', 'g29', 'g30', 'g31', 'g32', 'g33', 'g34', 'g35', 'g36', 'g37', 'g39')
--and 
clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
having sum(clicks) >= 15
;

drop table ay_temp_hv_google_rev8_cont purge;

create table ay_temp_hv_google_rev8_cont tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, sum(rev8) rev, sum(ml8) ml, 0 ad_lead
from ay_temp_hv_google_cost8_cont t, dw.merchant_lead_bid_pronto ml
where t.adid = REGEXP_REPLACE(ml.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
group by t.adid
union all
select t.adid, sum(1.0*rev8), 0, sum(ad_lead8) ad_lead
from ay_temp_hv_google_cost8_cont t, dw.adword_adid_bid_pronto ad
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
group by t.adid
/**
union all
--cap logo campaign's comtribution to 5 cents
select t.adid, least(.02,imps/1000*6/t.clicks)*t.clicks, 0, 0
from ay_temp_hv_google_cost8_cont t, (select adid, sum(imps) imps from dw.logo_campaign where clickdate >= trunc(sysdate) - 56 and clickdate < trunc(sysdate) group by adid) l
where t.adid = REGEXP_REPLACE(l.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
union all
--data not refreshed until 15:00
--cap rpc from cpm at .05
select t.adid, least(sum(revenue), .05*avg(clicks)), 0, 0
from dw.cpm_adid ad, ay_temp_hv_google_cost8_cont t,
--make sure that cpm did not totally disappear
(select REGEXP_REPLACE(adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') adid from dw.cpm_adid where clickdate >= trunc(sysdate) - 3 and adid like '%_gc' and siteid = 1 group by REGEXP_REPLACE(adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') having sum(revenue) > 0) t2
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
and t.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 56 - 1
and ad.clickdate < trunc(sysdate) - 1 and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and ad.adid like '%_gc'
and ad.siteid = 1
group by t.adid
union all
select t.adid, sum(guidestercpc), 0, 0
from dw.guidester_grid ad, ay_temp_hv_google_cost8_cont t,
--make sure that guidester feed did not disappear
(select distinct goldenproductid from stg.guidester_product_feed where clickdate >= trunc(sysdate)) t2
where t.adid = REGEXP_REPLACE(ad.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '')
and ad.goldenproductid = t2.goldenproductid
and ad.clickdate >= trunc(sysdate) - 56
and ad.clickdate < trunc(sysdate) and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and ad.adid like '%_gc'
and ad.siteid = 1
group by t.adid
**/
)
group by adid
;

drop table ay_temp_google_bids8_cont purge;

--here is where we control the margin
create table ay_temp_google_bids8_cont tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        trunc(least(.4, decode(t.accountname, 'g29', 1.000, 1.000)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.maximumcpc,
	t.seasonal_flag
from ay_temp_google_kwid_cont t, ay_temp_hv_google_cost8_cont t1, ay_temp_hv_google_rev8_cont t2
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
;

drop table ay_temp_google_bids_f_cont purge;
create table ay_temp_google_bids_f_cont tablespace stage_temp_data nologging as
select distinct t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        t.roi,
        t.averageposition,
        t.maximumcpc,
        t.seasonal_flag,
	'1 wk' type
from ay_temp_google_bids1_cont t
where (roi < 1/1.000 or averageposition > 1 or rpc < nvl(maximumcpc, 0))
union all
select distinct t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        t.roi,
        t.averageposition,
        t.maximumcpc,
        t.seasonal_flag,
	'4 wk' type
from ay_temp_google_bids4_cont t
where (roi < 1/1.000 or averageposition > 1 or rpc < nvl(maximumcpc, 0))
and not exists (select * from ay_temp_google_bids1_cont
        where adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
union all
select distinct t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        t.roi,
        t.averageposition,
        t.maximumcpc,
        t.seasonal_flag,
	'8 wk' type
from ay_temp_google_bids8_cont t
where (roi < 1/1.000 or averageposition > 1 or rpc < nvl(maximumcpc, 0))
and not exists (select * from ay_temp_google_bids1_cont
        where adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_google_bids4_cont
        where adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
;

spool off

set heading off
set trimspool on
set linesize 200

spool &1
--/home/dw/ayang/Log/bids_google_content.txt

select distinct
	--t.accountname||'|'||
	to_char(t.customerid)||'|'||
	to_char(t.adgroupid)||'|'||
	NULL||'|'||
	greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0), 0.01)||'|'||
	'p'||'|'||
	NULL||'|'||
	to_char(t.campaignid)
from ay_temp_google_bids_f_cont t
where exists (select avg(rpc) from ay_temp_google_bids_f_cont having avg(rpc) <= .2)
--where seasonal_flag = 'y'
;

spool off;

insert into stg.google_bid_history_content
(ACCOUNTNAME,    
customerid,
CAMPAIGN    ,   
CAMPAIGNID  ,   
ADGROUP     ,   
ADGROUPID   ,   
ADID        ,   
RPC         ,   
ROI         ,   
AVERAGEPOSITION,
MAXIMUMCPC,     
SEASONAL_FLAG,
TYPE
)
select ACCOUNTNAME,
customerid,
CAMPAIGN    ,
CAMPAIGNID  ,
ADGROUP     , 
ADGROUPID   ,
ADID        ,
rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0),
ROI         ,
AVERAGEPOSITION,
MAXIMUMCPC,
SEASONAL_FLAG,
TYPE
from ay_temp_google_bids_f_cont
where exists (select avg(rpc) from ay_temp_google_bids_f_cont having avg(rpc) <= .2)
--where seasonal_flag = 'y'
;

drop table ay_temp_google_kwid_cont purge;
drop table ay_temp_hv_google_cost1_cont purge;
drop table ay_temp_hv_google_rev1_cont purge;
drop table ay_temp_google_bids1_cont purge;
drop table ay_temp_hv_google_cost4_cont purge;
drop table ay_temp_hv_google_rev4_cont purge;
drop table ay_temp_google_bids4_cont purge;
drop table ay_temp_hv_google_cost8_cont purge;
drop table ay_temp_hv_google_rev8_cont purge;
drop table ay_temp_google_bids8_cont purge;

quit;

