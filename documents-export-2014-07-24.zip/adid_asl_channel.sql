drop table ay_temp_top_terms;
create table ay_temp_top_terms nologging as
select adid, round(rev, 2) rev, round(click) click, rk
from (select adid, sum(nvl(cpc_actual, cpc)*numclick) rev, sum(numclick) click, rank() over (order by sum(nvl(cpc_actual, cpc)*numclick) desc, adid) rk
        from dw.adword_adid t
        where clickdate >= trunc(sysdate) - 1
	and siteid in (1, 21, 62)
        and (adid like '%m_s' /**or adid like '%gc'**/)
--        and not exists (select * from dw.adword_adid_cpc where adid = regexp_replace(t.adid, '(\d)\D+$', '\1'))
        group by adid
)
where rk < 21
;
analyze table ay_temp_top_terms compute statistics;

drop table ay_temp_top_terms_gc;
create table ay_temp_top_terms_gc nologging as
select adid, keyword
from titan.keyword@be1
where adid in (select adid from ay_temp_top_terms where adid like '%_gc')
;

drop table ay_temp_top_terms_ml;
create table ay_temp_top_terms_ml nologging as
select adid, keyword, rk, rev, click, round(avg(averageposition),2) averageposition, round(sum(cost)/sum(clicks), 4) cpc
from (
select ad.adid, keyword, rk, rev, click, averageposition, cost/1000000 cost, clicks
from stg.google_ad_api ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union
select ad.adid, keyword, rk, rev, click, averageposition, cost/1000000 cost, clicks
from stg.google_ad_api_gifts ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union 
select ad.adid, keyword, rk, rev, click, averageposition, cost/1000000 cost, clicks
from stg.google_ad_api_oh ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union
select ad.adid, keyword, rk, rev, click, averageposition, cost/1000000 cost, clicks
from stg.de_google_ad_api ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union
select ad.adid, keyword, rk, rev, click, averageposition, cost/1000000 cost, clicks
from stg.fr_google_ad_api ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union
select ad.adid, keyword, rk, rev, click, averageposition, cost, clicks
from stg.yahoo_ad_api ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union
select ad.adid, keyword, rk, rev, click, averageposition, cost, clicks
from stg.yahoo_ad_api_ohdeal ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union 
select ad.adid, keyword, rk, rev, click, averageposition, cost, clicks
from stg.yahoo_gifts_ad_api ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union
select ad.adid, keyword, rk, rev, click, avgpos, totalcost, clicks
from stg.msn_ad_api ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union
select ad.adid, keyword, rk, rev, click, avgpos, totalcost, clicks
from stg.msn_gifts_ad_api ad, ay_temp_top_terms t
where clickdate >= trunc(sysdate) - 1
and ad.adid = t.adid
union 
select ad.adid, keyword, rk, rev, click, null, null, null
from ay_temp_top_terms_gc ad, ay_temp_top_terms t
where ad.adid = t.adid
)
group by adid, keyword, rk, rev, click
;

select adid||'|'||lower(keyword)||'|'||rk||'|'||rev||'|'||round(rev/click, 4)||'|'||averageposition||'|'||cpc
from ay_temp_top_terms_ml
order by rk;

quit
