
column dd new_val dd;
column dda new_val dda;
column ddd new_val ddd;
column mm new_val mm;
column wk new_val wk;

select
  '&&1' dd,
  '&&1'||'00' dda,
  to_char(to_date('&&1','yyyymmdd')-60,'yyyymmdd') ddd,
  to_char(to_date('&&1','yyyymmdd'),'yyyymm')||'01' mm,
  to_char(next_day(to_date('&&1','yyyymmdd'),'sun')-7,'yyyymmdd') wk
from dual
;

drop table ap_temp_ml_redirect purge;
drop table ap_temp_ml_dup purge;
drop table ap_temp_ml_grid purge;
drop table ap_temp_ml_srch purge;
drop table ap_temp_ml purge;
drop table ap_temp_ml_sz_pronto purge;

set serveroutput on;
set trimspool on;
set heading off;
set linesize 255;
spool /home/dw/apicker/Logs/merchant_lead.pronto.log;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' START merchant_lead' from dual;

create table ap_temp_ml_redirect nologging as
with re as
 (select re.*,
    case
      when re.productsourceid = 14 and re.merchantid = 2014500 then
        instr(re.networkurl,'tag=')+4
      when re.productsourceid in (3,16,17,18) then
        instr(re.networkurl,'tag=')+4
      when re.productsourceid in (13) then
        instr(re.networkurl,'lnkId=')+6
      when re.productsourceid = 28 then
        instr(re.networkurl,'af_placement_id=')+16
      when re.productsourceid = 20 then
        instr(re.networkurl,'cat_id=')+7
      else null
    end s,
    case
      when re.productsourceid = 14 and re.merchantid = 2014500 then
        instr(re.networkurl||'&','&',instr(re.networkurl,'tag=')+4)
      when re.productsourceid in (3,16,17,18) then
        instr(re.networkurl||'&','&',instr(re.networkurl,'tag=')+4)
      when re.productsourceid in (13) then
        instr(re.networkurl||'&','&',instr(re.networkurl,'lnkId=')+6)
      when re.productsourceid = 28 then
        instr(re.networkurl||'&','&',instr(re.networkurl,'af_placement_id=')+16)
      when re.productsourceid = 20 then
        instr(re.networkurl||'&','&',instr(re.networkurl,'cat_id=')+7)
      else null
    end e
  from stg.comm_redirect_event partition (part_&&mm) re
  where 1 = 1
  and re.timestamp2 >= to_date('&&dd','yyyymmdd')
  and re.timestamp2  < to_date('&&dd','yyyymmdd')+1)
select
  re.requestid, re.parentid, re.timestamp2,
  re.ipaddress, re.cookieid, re.userid, re.machineid,
  re.papipartnerid, re.papiuserid, re.searchengine,
  re.abtestingid, re.goldencategoryid, re.browseid,    
  re.productsourceid, re.merchantproductid, re.merchantid, re.networkurl,
  re.useragent, re.ispaying, re.cpc, re.feeddate,
  decode(pf.requestid,null,null,pf.apitype) clickoutpagetype,
  decode(pf.requestid,null,re.pagelocation,pf.viewtype) pagelocation, pf.position,
  ar.rootid, ar.micrositeid micrositeout, nvl(ar.countrycode,'XX') countrycode,
  substr(re.networkurl||'&',re.s,re.e-re.s) trackingid,
  pf.versionid, pf.domain, pf.pagemodelid, pf.browser
from re re, stg.comm_all_request partition (part_&&mm) ar, dw.pf_pronto_roots partition (part_&&dd) pf
where re.requestid = ar.requestid
and ar.timestamp2 >= to_date('&&dd','yyyymmdd')
and ar.timestamp2  < to_date('&&dd','yyyymmdd')+1
and re.parentid = pf.requestid(+)
;

create table ap_temp_ml_dup nologging as
select requestid from
 (select
    requestid, merchantproductid, cookieid, to_char(timestamp2,'hh24') hh,
    rank() over(partition by merchantproductid, cookieid, to_char(timestamp2,'hh24') order by timestamp2, requestid) rk
  from ap_temp_ml_redirect re
  where not exists (select /*+ dynamic_sampling (re 3)  dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = re.ipaddress))
where rk > 1
;

create table ap_temp_ml_grid nologging as
select 
  c.requestid, 
  c.position, 
  c.entrytype, 
  c.merchantproductid 
from stg.comm_comparison_grid partition (part_&&wk) c
where 1 = 1
and c.timestamp2 >= to_date('&&dd','yyyymmdd')
and c.timestamp2  < to_date('&&dd','yyyymmdd')+1
;

create index ap_temp_ml_grid$rqidmpid on ap_temp_ml_grid (requestid, merchantproductid) tablespace temp_index;
analyze table ap_temp_ml_grid estimate statistics sample 10 percent;

create table ap_temp_ml_srch nologging as
select 
  s.requestid, 
  s.position, 
  s.rowtype,
  s.merchantproductid  
from stg.comm_search_unique partition (part_&&wk) s
where 1 = 1
and s.timestamp2 >= to_date('&&dd','yyyymmdd')
and s.timestamp2  < to_date('&&dd','yyyymmdd')+1
;

create index ap_temp_ml_srch$rqidmpid on ap_temp_ml_srch (requestid, merchantproductid) tablespace temp_index;
analyze table ap_temp_ml_srch estimate statistics sample 20 percent;


create table ap_temp_ml nologging as
select 
  d.siteid,
  substrb(d.channel,1,100) channel,
  substrb(d.featuremodule,1,200) featuremodule,
  d.goldencategoryid,
  d.mexpcategoryid,
  d.timestamp2,
  d.clickdate,
  d.pagelocation,
  decode(d.status,'v',d.ispaying,'false') ispaying,
  d.merchantproductid,
  d.merchantid,
  d.productsourceid,
  d.goldenproductid,
  d.ipaddress,
  d.cookieid,
  d.machineid,
  d.trackingid,
  d.requestid,
  d.parentid,
  --on march 3, 2009, some sdc products had cpc of 37 dollars
  decode(d.status,'v',round(least(2,nvl(decode(d.ispaying,'true',decode(d.merchantid||'_'||d.productsourceid,'13588_15',.23,coalesce(d.cpc,csc.cpc,0)),0),0)),4),0) cpc,
  d.adid,
  d.position,
  decode(d.status,'v',d.isdup,'y') isdup,
  d.status,
  substrb(d.partner,1,2000) partner,
  d.iscomm,
  d.userid,
  d.creativeid,
  d.ovraw,
  d.ovkey,
  d.ovmtc,
  d.ovkwid,
  d.site,
  d.browseid,
  d.abtestingid,
  d.micrositein,
  d.micrositeout,
  d.countrycode,
  d.clickoutpagetype,
  d.pagenumber,
  d.keyword,
  d.rootid,
  d.istrackable,
  d.padgroupid, d.pcampaignid, d.pfeedid, d.pkeyword, d.pkeywordid,
  d.pmatchtype, d.pmobile, d.pnetwork, d.prandom, d.ptarget, d.ptype,
  d.isalt, d.indexboost,
  d.ispronto,
  d.isfirstvisit,
  d.domain, d.pagemodelid, d.versionid, d.browser
from
  stg.category_source_cpc csc,
 (select /*+ no_use_hash_aggregation */  
    nvl(max(rt.siteid),1) siteid,
    max(case when rt.requestid||re.searchengine||re.pagelocation = 'www.shefinds.compapi' then 'PAPI' else nvl(rt.channel,'Other') end) channel, -- SHEFINDS HACK  max(nvl(rt.channel,'Other')) channel,
    max(case when rt.requestid||re.searchengine||re.pagelocation = 'www.shefinds.compapi' then '20090423-SHEFINDS^search' else nvl(rt.featuremodule,'Other') end) featuremodule, -- SHEFINDS HACK  max(nvl(rt.featuremodule,'Other')) featuremodule,
    max(coalesce(re.goldencategoryid,339)) goldencategoryid,
    max(nvl(gc.mexpcategoryid,0)) mexpcategoryid,
    max(re.timestamp2) timestamp2,
    max(trunc(re.timestamp2)) clickdate,
    max(coalesce(re.pagelocation,s.rowtype,g.entrytype)) pagelocation,
  --treat leads with source 13 always paying
    max(decode(re.productsourceid, 13, 'true', nvl(re.ispaying,'false'))) ispaying,
    max(re.merchantproductid) merchantproductid,
    max(re.merchantid) merchantid,
    max(re.productsourceid) productsourceid,
    max(mp.goldenproductid) goldenproductid,
    max(re.ipaddress) ipaddress,
    max(decode(nvl(rt.siteid,1),301,rt.cookieid,re.cookieid)) cookieid,
    max(re.machineid) machineid,
    substrb(max(re.trackingid),1,25) trackingid,
    re.requestid requestid,
    max(re.parentid) parentid,
    max((case when re.productsourceid = 19 then .96 when re.productsourceid = 13 then 1 else 1 end)*re.cpc) cpc,
    max(rt.adid) adid,
    max(coalesce(re.position,g.position+1,s.position+1,0)) position,
    max(decode(dup.requestid,null,'n','y')) isdup,
    case
      when max(re.countrycode) not in ('US','CA','XX') then 'i'
      when max(bi.ipaddress) is not null then 'b'
      when max(rt.featuremodule) = 'invalid' then 'b'
      when max(dup.requestid) is not null then 'd'
      else 'v'
    end status,
    'true' iscomm,
    max(case when rt.requestid||re.searchengine||re.pagelocation = 'www.shefinds.compapi' then '20090423-SHEFINDS^user00' else rt.partner end) partner, -- SHEFINDS HACK  max(rt.partner) partner,
    max(coalesce(re.userid,p.userid,rt.userid)) userid,
    max(rt.creativeid) creativeid,
    max(rt.ovraw) ovraw,
    max(rt.ovkey) ovkey,
    max(rt.ovmtc) ovmtc,
    max(rt.ovkwid) ovkwid,
    max(rt.site) site,
    max(re.browseid) browseid,
    max(nvl(rt.abtestingid,re.abtestingid)) abtestingid,
    max(nvl(rt.micrositein,'primary_pronto')) micrositein,
    max(nvl(re.micrositeout,'primary_pronto')) micrositeout,
    max(re.countrycode) countrycode,
    max(nvl(re.clickoutpagetype,p.pgtype)) clickoutpagetype,
    max(p.pagenumber) pagenumber,
    substrb(max(p.keyword),1,50) keyword,
    max(re.rootid) rootid,
    min(decode(re.productsourceid,
      1,0, --crawl 
      3,1,16,1,17,1,18,1, --amazon 
      4,1, --cj 
      5,1, --performics 
      6,1, --linkshare 
     13,0, --sdc 
     14,1, --rev share 
     15,nvl(ma.roitrackerinstalled,0), --mexp 
     19,0, --pg 
     20,0, --sz 
     22,1, --pepper jam
     28,1, --become us
      0)) istrackable, --everything else ,
    max(rt.padgroupid) padgroupid,
    max(rt.pcampaignid) pcampaignid, 
    max(rt.pfeedid) pfeedid,
    max(rt.pkeyword) pkeyword, 
    max(rt.pkeywordid) pkeywordid,
    max(rt.pmatchtype) pmatchtype, 
    max(rt.pmobile) pmobile,
    max(rt.pnetwork) pnetwork,
    max(rt.prandom) prandom,
    max(rt.ptarget) ptarget,
    max(rt.ptype) ptype,
    nvl(max(substr(p.altsearch,1,10)),'false') isalt,
    max(decode(p.altsearch,'true',mp.altindexboost,mp.indexboost)) indexboost,
    min(case when re.searchengine like '%pronto%' then 'true' else 'false' end) ispronto,
    nvl(max(rt.isfirstvisit),1) isfirstvisit,
    max(re.domain) domain, max(re.pagemodelid) pagemodelid, max(re.versionid) versionid, max(re.browser) browser
  from
    stg.banned_ip bi,
    ap_temp_ml_root_pgtype p,
    ap_temp_ml_redirect re,
    ap_temp_ml_grid g,
    ap_temp_ml_srch s,
    stg.merchant_product mp,
    ap_temp_ml_dup dup,
    stg.golden_category gc,
    stg.merchant m,
    mexp.merchant_account ma,
    dw.roots partition (part_&&dd) rt
  where
    re.parentid = p.requestid(+)
    and re.rootid = rt.requestid(+)
    and re.merchantproductid = mp.merchantproductid(+)
    and re.parentid = g.requestid(+)
    and re.merchantproductid = g.merchantproductid(+)
    and re.parentid = s.requestid(+)
    and re.merchantproductid = s.merchantproductid(+)
    and re.requestid = dup.requestid(+)
    and nvl(re.goldencategoryid,339) = gc.goldencategoryid(+)
    and re.merchantid = m.merchantid
    and m.merchantacctid = ma.merchantacctid(+)
    and re.ipaddress = bi.ipaddress(+) 
  group by re.requestid) d
where
  d.productsourceid = csc.productsourceid(+)
  and d.goldencategoryid = csc.goldencategoryid(+)
;

merge into ap_temp_ml a
using stg.syndication_rev_share b
on
 (a.productsourceid = b.productsourceid
  and exists (select * from stg.channel_map where channel = a.channel and channelrollup = 'Partner')
  and a.ispronto = 'false')
when matched then update
set a.cpc = (a.cpc/b.defaultrevshare)*b.syndrevshare
;

update ap_temp_ml
set isdup = 'y', status = 'b', cpc = 0
where clickdate = to_date('&&dd','yyyymmdd')
and channel = 'PAPI'
and partner like '%SHEFINDS%'
;

commit;

create table ap_temp_ml_sz_pronto nologging as
select mp.merchantproductid, mp.source, avg(ecpc*.95) ecpc
from stg.merchant_product mp, ap_temp_ml ml
where mp.merchantproductid = ml.merchantproductid
and ml.productsourceid = 20
and mp.source = 20
--and ml.ispaying = 'true'
and ml.cpc > 1
and mp.ecpc < 1
group by mp.merchantproductid, mp.source
;

merge into ap_temp_ml ml
using ap_temp_ml_sz_pronto t
on 
 (ml.merchantproductid = t.merchantproductid 
  and ml.productsourceid = t.source
  and ml.status = 'v')
when matched then
update set cpc = t.ecpc
;

commit;

update ap_temp_ml ml
set cpc = .15
where ml.clickdate = to_date('&&dd','yyyymmdd')
and ml.cpc > 1
and ml.siteid = 1
and ml.productsourceid = 20
and ml.iscomm = 'true'
and ml.status = 'v'
;

commit;

--5/21/12
--All SDC leads to partners Adgenesis and Local.com should not be counted as valid
--5/29/12
--Scratch this, we had mis-mapped IDs.  Traffic is valid
/**
update ap_temp_ml
set 
  status = 'b',
  isdup = 'y',
  cpc = 0
where clickdate = to_date('&&dd','yyyymmdd')
and productsourceid = 13
and status = 'v'
and stg.get_partner_name(channel,partner) in ('Adgenesis','Local.com')
;

commit;
**/

commit;

delete from dw.merchant_lead partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 1
and iscomm = 'true'
;

delete from dw.merchant_lead partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and micrositein = 'pronto'
;

delete from dw.merchant_lead partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 301
;

insert into dw.merchant_lead partition (part_&&mm)
 (channel,featuremodule,goldencategoryid,mexpcategoryid,clickdate,pagelocation,ispaying,
  merchantproductid,merchantid,productsourceid,goldenproductid,ipaddress,cookieid,
  machineid,requestid,parentid,cpc,adid,position,isdup,status,partner,iscomm,userid,creativeid,
  ovraw,ovkey,ovmtc,ovkwid,site,browseid,abtestingid,micrositein,micrositeout,
  countrycode,clickoutpagetype,pagenumber,keyword,rootid,istrackable,siteid,trackingid,
  padgroupid, pcampaignid, pfeedid, pkeyword, pkeywordid,
  pmatchtype, pmobile, pnetwork, prandom, ptarget, ptype,
  isalt, indexboost, isfirstvisit)
select
  channel,featuremodule,goldencategoryid,mexpcategoryid,clickdate,pagelocation,ispaying,
  merchantproductid,merchantid,productsourceid,goldenproductid,ipaddress,cookieid,
  machineid,requestid,parentid,cpc,adid,position,isdup,status,partner,iscomm,userid,creativeid,
  ovraw,ovkey,ovmtc,ovkwid,site,browseid,abtestingid,micrositein,micrositeout,
  countrycode,clickoutpagetype,pagenumber,keyword,rootid,istrackable,siteid,trackingid,
  padgroupid, pcampaignid, pfeedid, pkeyword, pkeywordid,
  pmatchtype, pmobile, pnetwork, prandom, ptarget, ptype,
  isalt, indexboost, isfirstvisit
from ap_temp_ml re
where not exists 
 (select /*+ dynamic_sampling (re 3)  dynamic_sampling (ml 3) */ * 
  from dw.merchant_lead partition (part_&mm) ml where ml.requestid = re.requestid)
;

commit;

delete from dw.app_merchant_lead partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
;

insert into dw.app_merchant_lead partition (part_&&mm)
 (clickdate, siteid,
  uti, versionid, browser, campaignid,
  status, abtestingid,
  domain, pagemodelid,
  apitype, viewtype, position,
  mlcnt, mlrev)
select
  ml.clickdate, ml.siteid,
  ml.cookieid, nvl(ml.versionid,'-'), nvl(ml.browser,'-'), nvl(ml.featuremodule,'0'),
  ml.status, nvl(ml.abtestingid,'0'),
  nvl(ml.domain,'-'), nvl(ml.pagemodelid,0),
  nvl(ml.clickoutpagetype,'-'), nvl(ml.pagelocation,'-'), nvl(ml.position,0),
  count(*) mlcnt, sum(cpc) mlrev
from ap_temp_ml ml
where exists
 (select /*+ dynamic_sampling (ml 3) dynamic_sampling (s 3) */ *
  from flanker.site_name_id s
  where ml.siteid = s.siteid
  and s.businessrollup = 'pronto apps')
group by
  ml.clickdate, ml.siteid,
  ml.cookieid, nvl(ml.versionid,'-'), nvl(ml.browser,'-'), nvl(ml.featuremodule,'0'),
  ml.status, nvl(ml.abtestingid,'0'),
  nvl(ml.domain,'-'), nvl(ml.pagemodelid,0),
  nvl(ml.clickoutpagetype,'-'), nvl(ml.pagelocation,'-'), nvl(ml.position,0)
;

commit;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' END merchant_lead' from dual;

spool off;

alter table dw.merchant_lead_sale
drop partition part_&&ddd
;

alter table dw.merchant_lead_sale
add partition part_&&dd
values (to_date('&&dda','yyyymmddhh24'))
;

spool /home/dw/apicker/Logs/merchant_lead.pronto.log append;

delete from dw.merchant_lead_sale partition (part_&&dd)
where siteid = 1
and iscomm = 'true'
;

delete from dw.merchant_lead_sale partition (part_&&dd)
where micrositeid = 'pronto'
;

delete from dw.merchant_lead_sale partition (part_&&dd)
where siteid = 301
;

insert into dw.merchant_lead_sale partition (part_&&dd)
 (channel,featuremodule,goldencategoryid,mexpcategoryid,clickdate,timestamp2,
  merchantproductid,merchantid,productsourceid,goldenproductid,
  requestid,parentid,adid,partner,userid,
  browseid,abtestingid,
  micrositeid,
  clickoutpagetype,siteid,iscomm,status)
select
  channel,featuremodule,goldencategoryid,mexpcategoryid,clickdate,timestamp2,
  merchantproductid,merchantid,productsourceid,goldenproductid,
  requestid,parentid,adid,partner,userid,
  browseid,abtestingid,
  decode(siteid,1,micrositeout,'pronto'),
  clickoutpagetype, siteid, 'true', status
from ap_temp_ml re
where productsourceid in (4,5,6,15,22,28)
and istrackable = 1
and not exists
 (select /*+ dynamic_sampling (re 3)  dynamic_sampling (ml 3) */ *
  from dw.merchant_lead_sale ml where ml.requestid = re.requestid)
;

commit;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' END merchant_lead_sale' from dual;

delete from dw.merchant_lead_msc partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 1
and iscomm = 'true'
;

delete from dw.merchant_lead_msc partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and micrositeid = 'pronto'
;

delete from dw.merchant_lead_msc partition (part_&&mm)
where clickdate = to_date('&&dd','yyyymmdd')
and siteid = 301
;

insert into dw.merchant_lead_msc partition (part_&&mm)
 (clickdate, merchantid, productsourceid, goldencategoryid, mexpcategoryid, browseid, 
  micrositeid, 
  siteid, iscomm, leads, paidleads, rev)
select
  clickdate, nvl(merchantid,0), nvl(productsourceid,0), nvl(goldencategoryid,0), nvl(mexpcategoryid,0), nvl(browseid,'v1'), 
  decode(siteid,1,nvl(micrositeout,'primary_pronto'),'pronto'), 
  nvl(siteid,1), 'true', count(*) leads, sum(decode(ispaying,'true',1,0)) paidleads, sum(cpc) rev
from ap_temp_ml
where status = 'v'
group by clickdate, nvl(merchantid,0), nvl(productsourceid,0), nvl(goldencategoryid,0), nvl(mexpcategoryid,0), nvl(browseid,'v1'), decode(siteid,1,nvl(micrositeout,'primary_pronto'),'pronto'), nvl(siteid,1)
;

commit;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' END merchant_lead_msc' from dual;

spool off;
drop table dw.merchant_lead_bid_pronto purge;
spool /home/dw/apicker/Logs/merchant_lead.pronto.log append;

create table dw.merchant_lead_bid_pronto nologging 
as
select 
	adid, 
	sum((case when clickdate >= trunc(sysdate) - 7 then 1 else 0 end)*decode(productsourceid, 15, .975, 13, case when clickdate between '01-Nov-2012' and '31-Dec-2012' then .9 else 1.0 end, 3, 1.25, 16, 1.25, 19, case when clickdate between '01-Nov-2012' and '14-Jan-2013' then .9 else .95 end, 20, case when clickdate < '11-Feb-2013' then 1.15 when clickdate <= '15-Feb-2013' then .6 else .95 end, 28, 1.05, 1.0)*decode(merchantid, 2131717, .5, 1)*cpc) rev1, 
	count(distinct case when clickdate >= trunc(sysdate) - 7 then ml.requestid else null end) ml1,
	sum((case when clickdate >= trunc(sysdate) - 28 then 1 else 0 end)*decode(productsourceid, 15, .975, 13, case when clickdate between '01-Nov-2012' and '31-Dec-2012' then .9 else 1.0 end, 3, 1.25, 16, 1.25, 19, case when clickdate between '01-Nov-2012' and '14-Jan-2013' then .9 else .95 end, 20, case when clickdate < '11-Feb-2013' then 1.15 when clickdate <= '15-Feb-2013' then .6 else .95 end, 28, 1.05, 1.0)*decode(merchantid, 2131717, .5, 1)*cpc) rev4, 
	count(distinct case when clickdate >= trunc(sysdate) - 28 then ml.requestid else null end) ml4,
	sum(decode(productsourceid, 15, .975, 13, case when clickdate between '01-Nov-2012' and '31-Dec-2012' then .9 else 1.0 end, 3, 1.25, 16, 1.25, 19, case when clickdate between '01-Nov-2012' and '14-Jan-2013' then .9 else .95 end, 20, case when clickdate < '11-Feb-2013' then 1.15 when clickdate <= '15-Feb-2013' then .6 else .95 end, 28, 1.05, 1.0)*decode(merchantid, 2131717, .5, 1)*cpc) rev8, 
	count(distinct ml.requestid) ml8
from dw.merchant_lead ml
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate)
and clickdate <> '12-Jun-2012' and clickdate <> '30-Jun-2012' and clickdate <> '18-Jul-2012'
and channel = 'SEM'
and status = 'v'
and siteid = 1 
group by adid
;

analyze table dw.merchant_lead_bid_pronto estimate statistics sample 20 percent;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' END merchant_lead_bid' from dual;

/*********
  9/27/2011
  ML PCN is now its own job

delete from dw.merchant_lead_pcn
where clickdate = to_date('&&dd','yyyymmdd')
;

insert into dw.merchant_lead_pcn
 (clickdate, 
  articleid, siteid, 
  categoryid, pagetype,
  src,
  mlcnt, mlrev)
select
  clickdate, 
  nvl(stg.getnumber(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'articleid')),0), 
  2000+nvl(stg.getnumber(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'siteid')),1), 
  nvl(stg.getnumber(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'categoryid')),0), 
  nvl(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'pagetype'),'-'), 
  nvl(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'src'),'-'),
  count(*), sum(cpc)
from ap_temp_ml
where channel = 'PCN'
and status = 'v'
group by 
  clickdate, 
  nvl(stg.getnumber(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'articleid')),0), 
  2000+nvl(stg.getnumber(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'siteid')),1), 
  nvl(stg.getnumber(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'categoryid')),0), 
  nvl(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'pagetype'),'-'), 
  nvl(stg.parse_pcn_tracking(substr(partner,instr(partner,'^')+1),'src'),'-')
;

commit;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' END merchant_lead_pcn' from dual;
*********/

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')||' END merchant_lead summary' from dual;

spool off;


/**
create table ay_temp_pg_ml nologging as
select mp.merchantproductid, mp.productsourceid, avg(ecpc*.96) ecpc
from stg.merchant_product mp, dw.merchant_lead ml
where mp.merchantproductid = ml.merchantproductid
and ml.productsourceid = 19
and ml.clickdate = to_date('&&dd','yyyymmdd')
and ml.cpc = .01
and ml.siteid = 1
and mp.ecpc > 0
group by mp.merchantproductid, mp.productsourceid
;

merge into dw.merchant_lead ml
using ay_temp_pg_ml t
on (ml.merchantproductid = t.merchantproductid and ml.productsourceid = t.productsourceid and ml.clickdate = to_date('&&dd','yyyymmdd'))
when matched then
update set cpc = t.ecpc
;
commit;
**/

commit;
drop table ap_temp_ml_redirect purge;
drop table ap_temp_ml_dup purge;
drop table ap_temp_ml_grid purge;
drop table ap_temp_ml_srch purge;
drop table ap_temp_ml purge;
drop table ap_temp_ml_sz_pronto purge;
quit;


