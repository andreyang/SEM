spool /home/dw/ayang/Log/bids_google_content_gifts.log

drop table ay_temp_goog_kwid_cont_gifts purge;

create table ay_temp_goog_kwid_cont_gifts tablespace stage_temp_data nologging as
select distinct
        adgroup,
	REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
	case when lower(adgroup) like '%halloween%' or lower(adgroup) like '%costume%' 
	or lower(adgroup) like '%pumpkin carv%' then 'y' else 'n' end seasonal_flag,
        --'n' seasonal_flag,
	adgroupid,
        campaign,
        campaignid,
        accountname,
	customerid,
        maximumcpc,
        minimumcpc,
        averageposition,
        dailybudget
from (
select  
        adgroup,
        adgroupid,
        campaign,
        campaignid,
        accountname,
	customerid,
        maxcontentcpc/1000000 maximumcpc,
        minimumcpc/1000000 minimumcpc,
        averageposition,
        dailybudget/1000000 dailybudget,
        RANK() OVER (PARTITION BY adgroupid, campaignid, accountname ORDER BY clickdate desc, maximumcpc desc, keywordid, averageposition, creativeid) rk
from stg.google_ad_api_content_gifts t
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
)
where rk = 1
;
commit;

drop table ay_temp_hv_goog_cost1_c_gifts purge;

create table ay_temp_hv_goog_cost1_c_gifts tablespace stage_temp_data nologging as
select  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
	sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_content_gifts
where --accountname IN ('g4', 'g29', 'g30', 'g31', 'g32', 'g33', 'g34', 'g35', 'g36', 'g37', 'g39')
--and 
clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
having sum(clicks) >= 25
;

commit;

drop table ay_temp_hv_goog_rev1_c_gifts purge;

create table ay_temp_hv_goog_rev1_c_gifts tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev1 rev, ml1 ml, 0 ad_lead
from  ay_temp_hv_goog_cost1_c_gifts t, dw.merchant_lead_bid_gf ml
where t.adid = REGEXP_REPLACE(ml.adid, '-[[:digit:]]+-gf_gc', '')
union all
select t.adid, .53*rev1, 0, ad_lead1
from ay_temp_hv_goog_cost1_c_gifts t, dw.adword_adid_bid_gf ad
where t.adid = REGEXP_REPLACE(ad.adid, '-[[:digit:]]+-gf_gc', '')
)
group by adid
;

commit;

drop table ay_temp_goog_bids1_c_gifts purge;

--here is where we control the margin
--SEASONAL KEYWORD'S BIDS ARE CONTROLLED BY THE NUMBER AFTER y.
create table ay_temp_goog_bids1_c_gifts as
select distinct
        t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        trunc(least(decode(t.accountname, 'g29', 0.4, 0.4), decode(t.accountname, 'g29', 1.150, 1.150)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
	t.maximumcpc,
	t.seasonal_flag
from ay_temp_goog_kwid_cont_gifts t, ay_temp_hv_goog_cost1_c_gifts t1, ay_temp_hv_goog_rev1_c_gifts t2
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   (t1.clicks >= 50 or nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) <= 0.2)
;

commit;

drop table ay_temp_hv_goog_cost4_c_gifts purge;

create table ay_temp_hv_goog_cost4_c_gifts tablespace stage_temp_data nologging as
select  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
        sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_content_gifts
where --accountname IN ('g4', 'g29', 'g30', 'g31', 'g32', 'g33', 'g34', 'g35', 'g36', 'g37', 'g39')
--and 
clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
having sum(clicks) >= 10
;
commit;

drop table ay_temp_hv_goog_rev4_c_gifts purge;

create table  ay_temp_hv_goog_rev4_c_gifts tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev4 rev, ml4 ml, 0 ad_lead
from ay_temp_hv_goog_cost4_c_gifts t, dw.merchant_lead_bid_gf ml
where t.adid = REGEXP_REPLACE(ml.adid, '-[[:digit:]]+-gf_gc', '')
union all
select t.adid, .53*rev4, 0, ad_lead4 ad_lead
from  ay_temp_hv_goog_cost4_c_gifts t, dw.adword_adid_bid_gf ad
where t.adid = REGEXP_REPLACE(ad.adid, '-[[:digit:]]+-gf_gc', '')
)
group by adid
;

commit;

drop table ay_temp_goog_bids4_c_gifts purge;

--here is where we control the margin
create table ay_temp_goog_bids4_c_gifts tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        trunc(least(decode(t.accountname, 'g29', 0.4, 0.4), decode(t.accountname, 'g29', 1.150, 1.150)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.maximumcpc,
	t.seasonal_flag
from ay_temp_goog_kwid_cont_gifts t, ay_temp_hv_goog_cost4_c_gifts t1, ay_temp_hv_goog_rev4_c_gifts t2
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
;

commit;

drop table ay_temp_hv_goog_cost8_c_gifts purge;

create table ay_temp_hv_goog_cost8_c_gifts tablespace stage_temp_data nologging as
select  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adid,
        sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_content_gifts
where --accountname IN ('g4', 'g29', 'g30', 'g31', 'g32', 'g33', 'g34', 'g35', 'g36', 'g37', 'g39')
--and 
clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
and REGEXP_LIKE(adgroup,'^[[:digit:]]{1,3}-[[:digit:]]+-[[:digit:]]+d*-.*')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
having sum(clicks) >= 15
;

commit;

drop table ay_temp_hv_goog_rev8_c_gifts purge;

create table ay_temp_hv_goog_rev8_c_gifts tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev8 rev, ml8 ml, 0 ad_lead
from ay_temp_hv_goog_cost8_c_gifts t, dw.merchant_lead_bid_gf ml
where t.adid = REGEXP_REPLACE(ml.adid, '-[[:digit:]]+-gf_gc', '')
union all
select t.adid, .53*rev8, 0, ad_lead8 ad_lead
from ay_temp_hv_goog_cost8_c_gifts t, dw.adword_adid_bid_gf ad
where t.adid = REGEXP_REPLACE(ad.adid, '-[[:digit:]]+-gf_gc', '')
)
group by adid
;

commit;


drop table ay_temp_goog_bids8_c_gifts purge;

--here is where we control the margin
create table ay_temp_goog_bids8_c_gifts tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        trunc(least(decode(t.accountname, 'g29', 0.4, 0.4), decode(t.accountname, 'g29', 1.150, 1.150)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.maximumcpc,
	t.seasonal_flag
from  ay_temp_goog_kwid_cont_gifts t, ay_temp_hv_goog_cost8_c_gifts t1, ay_temp_hv_goog_rev8_c_gifts t2
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
;

commit;

drop table ay_temp_goog_bids_f_c_gifts purge;
create table  ay_temp_goog_bids_f_c_gifts tablespace stage_temp_data nologging as
select distinct t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        t.roi,
        t.averageposition,
        t.maximumcpc,
        t.seasonal_flag,
	'1 wk' type
from ay_temp_goog_bids1_c_gifts t
where (roi < 1/1.150 or averageposition > 2 or rpc < nvl(maximumcpc, 0))
union all
select distinct t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        t.roi,
        t.averageposition,
        t.maximumcpc,
        t.seasonal_flag,
	'4 wk' type
from ay_temp_goog_bids4_c_gifts t
where (roi < 1/1.150 or averageposition > 2 or rpc < nvl(maximumcpc, 0))
and not exists (select * from ay_temp_goog_bids1_c_gifts
        where adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
union all
select distinct t.accountname,
	t.customerid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.adgroupid,
        t.adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        t.roi,
        t.averageposition,
        t.maximumcpc,
        t.seasonal_flag,
	'8 wk' type
from ay_temp_goog_bids8_c_gifts t
where (roi < 1/1.150 or averageposition > 2 or rpc < nvl(maximumcpc, 0))
and not exists (select * from ay_temp_goog_bids1_c_gifts
        where adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_goog_bids4_c_gifts
        where adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
;
commit;

spool off

set heading off
set trimspool on
set linesize 200

spool &1
--/home/dw/ayang/Log/bids_google_content_gifts.txt

select distinct
	--t.accountname||'|'||
	to_char(t.customerid)||'|'||
	to_char(t.adgroupid)||'|'||
	NULL||'|'||
	greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0), 0.01)||'|'||
	'p'||'|'||
	NULL||'|'||
	to_char(t.campaignid)
from  ay_temp_goog_bids_f_c_gifts t
where exists (select avg(rpc) from ay_temp_goog_bids_f_c_gifts having avg(rpc) <= .15)
--where seasonal_flag = 'y'
;

spool off;

insert into stg.google_bid_history_cont_gifts
(ACCOUNTNAME,    
customerid,
CAMPAIGN    ,   
CAMPAIGNID  ,   
ADGROUP     ,   
ADGROUPID   ,   
ADID        ,   
RPC         ,   
ROI         ,   
AVERAGEPOSITION,
MAXIMUMCPC,     
SEASONAL_FLAG,
TYPE
)
select ACCOUNTNAME,
customerid,
CAMPAIGN    ,
CAMPAIGNID  ,
ADGROUP     , 
ADGROUPID   ,
ADID        ,
RPC*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0),
ROI         ,
AVERAGEPOSITION,
MAXIMUMCPC,
SEASONAL_FLAG,
TYPE
from  ay_temp_goog_bids_f_c_gifts
where exists (select avg(rpc) from ay_temp_goog_bids_f_c_gifts having avg(rpc) <= .15)
--where seasonal_flag = 'y'
;

commit;

drop table ay_temp_goog_kwid_cont_gifts purge;
drop table ay_temp_hv_goog_cost1_c_gifts purge;
drop table ay_temp_hv_goog_rev1_c_gifts purge;
drop table ay_temp_goog_bids1_c_gifts purge;
drop table ay_temp_hv_goog_cost4_c_gifts purge;
drop table ay_temp_hv_goog_rev4_c_gifts purge;
drop table ay_temp_goog_bids4_c_gifts purge;
drop table ay_temp_hv_goog_cost8_c_gifts purge;
drop table ay_temp_hv_goog_rev8_c_gifts purge;
drop table ay_temp_goog_bids8_c_gifts purge;
drop table ay_temp_goog_bids_f_c_gifts purge;

quit;

