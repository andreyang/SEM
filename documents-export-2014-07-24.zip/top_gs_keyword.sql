create table ay_temp_gs_adid_10_clicks nologging as
select adid, max(lower(keyword)) keyword, max(KEYWORDTYPE) matchtype, sum(cost/1000000) cost, sum(clicks) clicks, sum(impressions) imp, round(sum(clicks*averageposition)/sum(clicks),2) pos
from stg.google_ad_api
where clickdate >= '16-Jan-2013'
group by adid
having sum(clicks) >= 5
;

create table ay_temp_gs_adid_10_clicks_ml nologging as
select adid, round(sum(cpc),2) ml_rev, count(*) ml, round(sum(decode(productsourceid, 13, cpc, 0)),2) sdc_rev, sum(decode(productsourceid, 13, 1, 0)) sdc_ml, round(sum(decode(productsourceid, 20, cpc, 0)),2) sz_rev, sum(decode(productsourceid, 20, 1, 0)) sz_ml, round(sum(decode(productsourceid, 19, cpc, 0)),2) pg_rev, sum(decode(productsourceid, 19, 1, 0)) pg_ml, round(sum(decode(productsourceid, 28, cpc, 0)),2) be_rev, sum(decode(productsourceid, 20, 1, 0)) be_ml, round(sum(decode(productsourceid, 3, cpc, 16, cpc, 0)),2) amazon_rev, sum(decode(productsourceid, 3, 1, 16, 1, 0)) amazon_ml, round(sum(decode(productsourceid, 15, cpc, 0)),2) mexp_rev, sum(decode(productsourceid, 15, 1, 0)) mexp_ml
from dw.merchant_lead
where clickdate >= '16-Jan-2013'
and siteid = 1
and isdup = 'n'
and adid like '%gs'
group by adid
;

create table ay_temp_gs_adid_10_clicks_ad nologging as
select adid, round(sum(numclick)) adl, round(sum(nvl(cpc_actual,cpc)*numclick),2) ad_rev
from dw.adword_adid
where clickdate >= '16-Jan-2013'
and siteid = 1
and adid like '%gs'
group by adid
;

set heading off
set linesize 200
set trimspool on
spool ./top_gs_keyword_10.txt

select 'adid|keyword|matchtype|cost|clicks|imp|pos|adl|ad_rev|ml|ml_rev|sdc_ml|sdc_rev|sz_ml|sz_rev|pg_ml|pg_rev|be_ml|be_rev|mexp_ml|mexp_rev|amazon_ml|amazon_rev'
from dual;

select c.adid||'|'||c.keyword||'|'||c.matchtype||'|'||c.cost||'|'||c.clicks||'|'||c.imp||'|'||c.pos||'|'||adl||'|'||ad_rev||'|'||ml||'|'||ml_rev||'|'||sdc_ml||'|'||sdc_rev||'|'||sz_ml||'|'||sz_rev||'|'||pg_ml||'|'||pg_rev||'|'||be_ml||'|'||be_rev||'|'||mexp_ml||'|'||mexp_rev||'|'||amazon_ml||'|'||amazon_rev
from ay_temp_gs_adid_10_clicks c, ay_temp_gs_adid_10_clicks_ml ml, ay_temp_gs_adid_10_clicks_ad ad
where c.adid = ml.adid(+)
and c.adid = ad.adid(+)
and c.clicks >= 10
;

spool off

spool ./top_gs_keyword_5.txt

select 'adid|keyword|matchtype|cost|clicks|imp|pos|adl|ad_rev|ml|ml_rev|sdc_ml|sdc_rev|sz_ml|sz_rev|pg_ml|pg_rev|be_ml|be_rev|mexp_ml|mexp_rev|amazon_ml|amazon_rev'
from dual;

select c.adid||'|'||c.keyword||'|'||c.matchtype||'|'||c.cost||'|'||c.clicks||'|'||c.imp||'|'||c.pos||'|'||adl||'|'||ad_rev||'|'||ml||'|'||ml_rev||'|'||sdc_ml||'|'||sdc_rev||'|'||sz_ml||'|'||sz_rev||'|'||pg_ml||'|'||pg_rev||'|'||be_ml||'|'||be_rev||'|'||mexp_ml||'|'||mexp_rev||'|'||amazon_ml||'|'||amazon_rev
from ay_temp_gs_adid_10_clicks c, ay_temp_gs_adid_10_clicks_ml ml, ay_temp_gs_adid_10_clicks_ad ad
where c.adid = ml.adid(+)
and c.adid = ad.adid(+)
and c.clicks < 10
;

spool off

quit
