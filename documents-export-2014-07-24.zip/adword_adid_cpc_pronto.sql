drop table ay_temp_adid_all purge;
create table ay_temp_adid_all nologging as
select regexp_replace(adid, '(\d)\D+$', '\1') adid_comm, network, sum(click) click, sum(cost) cost, sum(pos*click)/sum(click) pos, sum(cost)/sum(click) cpc, sum(click*qs)/sum(click) qs, sum(maximumcpc*click)/sum(click) maximumcpc, max(keyword) keyword
from 
(select adid, network, sum(clicks) click, sum(cost)/1000000 cost, sum(clicks*averageposition)/sum(clicks) pos, sum(cost)/1000000/sum(clicks) cpc, sum(qualityscore*clicks)/sum(clicks) qs, sum(maximumcpc/1000000*clicks)/sum(clicks) maximumcpc, max(lower(keyword)) keyword
from stg.google_ad_api
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) 
and network <> 'Content'
and keyword not in ('section 8 houses for rent', 'houses for rent by owner', 'section 8 houses')
group by adid, network
having greatest(sum(averageposition*clicks)/sum(clicks), 1) <= 10
union all
select adid, network, sum(clicks) click, sum(cost)/1000000 cost, sum(clicks*averageposition)/sum(clicks) pos, sum(cost)/1000000/sum(clicks) cpc, sum(qualityscore*clicks)/sum(clicks) qs, sum(maximumcpc/1000000*clicks)/sum(clicks) maximumcpc, max(lower(keyword)) keyword
from stg.google_ad_api_oh
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
and network <> 'Content'
and keyword not in ('section 8 houses for rent', 'houses for rent by owner')
group by adid, network
having greatest(sum(averageposition*clicks)/sum(clicks), 1) <= 10
)
group by regexp_replace(adid, '(\d)\D+$', '\1'), network
;

drop table ay_temp_network_upgrade purge;
create table ay_temp_network_upgrade nologging as
select greatest(.8,sum(least(n.cpc,g.cpc)*click)/sum(g.cpc*click)) smartprice --stddev(n.cpc/g.cpc), sum(n.cpc*click)/sum(g.cpc*click), min(n.cpc/g.cpc), avg(n.cpc/g.cpc), max(n.cpc/g.cpc)
from (select adid_comm, cpc, trunc(pos) pos from ay_temp_adid_all where network = 'Google Search') g,
(select adid_comm, click, cpc, trunc(pos) pos from ay_temp_adid_all where network = 'Search Partners') n
where g.adid_comm = n.adid_comm
and g.pos = n.pos
;

drop table ay_temp_adid_all2 purge;
create table ay_temp_adid_all2 nologging as
select * from ay_temp_adid_all
where network = 'Google Search'
and adid_comm is not null
--and click >= 2
;

insert into ay_temp_adid_all2 (adid_comm, network, click, cost, pos, cpc, qs, maximumcpc, keyword)
select adid_comm, network, click, cost, pos, cpc/t.smartprice cpc, qs, maximumcpc, keyword
from ay_temp_adid_all ad, ay_temp_network_upgrade t
where network = 'Search Partners'
and adid_comm is not null
and not exists (select * from ay_temp_adid_all2 where adid_comm = ad.adid_comm)
--and click >= 2
;
commit;

--add 15% for each top 3 positions and 10% for each of the rest of the positions
--cpc capped at 1.0 and floored at 0.05
--change the rule by 1 cent per position
--normalize cpc by quality score with the assumption that 5 is the average.
--No boost for no results page

drop table ay_temp_adword_adid_cpc;
create table ay_temp_adword_adid_cpc nologging as
select 	--t.adid, 
	--round(least(greatest(t.cpc*(1 + nvl(least(greatest(pos-1, 0), 3), 0)*.15 + nvl(greatest(pos-4, 0), 0)*.1), 0.05), .75),4) cpc,
	--round(least(greatest((t.cpc + nvl(greatest(pos-1, 0)*.01, 0))*least(6, t.qs)/(case when t.adid_comm like '%d-_' or t.adid_comm like '%d-__' then least(6, t.qs) else 5 end), 0.075), .75), 4) cpc,
	round(least(greatest((t.cpc + nvl(greatest(pos-1, 0)*.0125, 0))*decode(network, 'Google Search', least(6.5, t.qs)/5, least(6.5, t.qs)/5), 0.085), .85), 4) cpc,
	t.click,
	t.pos,
	t.adid_comm,
	t.keyword
from ay_temp_adid_all2 t
where t.adid_comm is not null
and length(adid_comm) < 60
;

drop table ay_temp_adid_all_msn purge;
create table ay_temp_adid_all_msn nologging as
select distinct regexp_replace(adid, '(\d)\D+$', '\1') adid_comm, lower(keyword) keyword
from stg.msn_ad_api
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
;

insert into ay_temp_adword_adid_cpc (adid_comm, cpc)
select replace(t.adid_comm, 'RLD-', ''), round(avg(t2.cpc),4)
from ay_temp_adid_all_msn t, (select keyword, round(avg(cpc),4) cpc from ay_temp_adword_adid_cpc group by keyword) t2
where t.keyword = t2.keyword
and not exists (select * from ay_temp_adword_adid_cpc where adid_comm = replace(t.adid_comm, 'RLD-', ''))
group by replace(t.adid_comm, 'RLD-', '')
;

--drop table ay_temp_adid_all_msn purge;
--drop table ay_temp_adid_all purge;
--drop table ay_temp_adid_all2 purge;

drop table ay_temp_gs_ds_adid purge;
create table ay_temp_gs_ds_adid nologging as
select adid, max(pagetype) pagetype
from stg.comm_search_header
where timestamp2 >= trunc(sysdate) - 7
and timestamp2 < trunc(sysdate)
and adid like '%gs'
group by adid
having (max(pagetype) = 'ds'
and min(pagetype) = 'ds') or (max(pagetype) = 'as'
and min(pagetype) = 'as')
;

merge into ay_temp_adword_adid_cpc ad
using (select regexp_replace(adid, '(\d)\D+$', '\1') adid, max(pagetype) pagetype from ay_temp_gs_ds_adid group by regexp_replace(adid, '(\d)\D+$', '\1')) t 
on (ad.adid_comm = t.adid)
when matched then
update set cpc = least(.85,decode(pagetype, 'ds', 1.45, 'as', 1.15)*cpc)
;

commit;
--drop table ay_temp_gs_ds_adid purge;

--sanity check
select 	siteid||'|'||case when adid like '%-oh_ys' then 'ys-oh'
	when adid like '%-oh_gc' then 'gc-oh'
	when adid like '%-oh%gs' then 'gs-oh'
	when adid like '%_gs' then 'gs'
	when adid like '%_gc' then 'gc'
	when adid like '%_ys' then 'y'
	when adid like '%_ms' or adid like '%_m_s' then 'm'
	when adid like '%_ls' then 'l'
	when adid like '%_as' then 'a'
	--when adid like '%_ssp' then 's'
	else 'X' end||'|'||sum(round(nvl(greatest(t2.cpc-nvl(position/100, 0), 0.05)*0.85, t.cpc)*decode(trim(to_char(clickdate, 'DAY')), 'FRIDAY', .99, 'SATURDAY', .98, 'SUNDAY', .97, .99), 4))||'|'||round(sum(t.cpc), 2)
from dw.adword_lead t, ay_temp_adword_adid_cpc t2
where regexp_replace(t.adid, '(\d)\D+$', '\1') = t2.adid_comm(+)
and clickdate = trunc(sysdate) - 1
and siteid IN (1, 21)
group by siteid, case when adid like '%-oh_ys' then 'ys-oh'
	when adid like '%-oh_gc' then 'gc-oh'
	when adid like '%-oh%gs' then 'gs-oh'
	when adid like '%_gs' then 'gs'
	when adid like '%_gc' then 'gc'
	when adid like '%_ys' then 'y'
	when adid like '%_ms' or adid like '%_m_s' then 'm'
	when adid like '%_ls' then 'l'
	when adid like '%_as' then 'a'
	--when adid like '%_ssp' then 's'
	else 'X' end
;

merge into dw.adword_adid_cpc t
using ay_temp_adword_adid_cpc t2
on (t.adid = t2.adid_comm)
when not matched then 
insert (adid, cpc)
values (t2.adid_comm, t2.cpc)
;

merge into dw.adword_adid_cpc t
using ay_temp_adword_adid_cpc t2
on (t.adid = t2.adid_comm)
when matched then
update set t.cpc = t2.cpc
;

commit;

analyze table dw.adword_adid_cpc compute statistics;

merge into dw.adword_adid ad
using ay_temp_adword_adid_cpc t
on (regexp_replace(ad.adid, '(\d)\D+$', '\1') = t.adid_comm and clickdate >= trunc(sysdate) - 28 and siteid = 1 and (ad.adid like '%_gs' or ad.adid like '%_m_s' or ad.adid like '%_gc'))
when matched then update set cpc_actual = round((t.cpc-.01)*.85, 4)
;
commit;

--drop table ay_temp_adword_adid_cpc purge;

/**
update dw.adword_adid ad
set cpc_actual = round(ad.cpc*1.15, 4)
where clickdate >= trunc(sysdate) - 28 and siteid = 1 and ad.adid like '%_gs'
and not exists (select * from ay_temp_adword_adid_cpc t where regexp_replace(ad.adid, '(\d)\D+$', '\1') = t.adid_comm)
;
**/

commit;
quit;
