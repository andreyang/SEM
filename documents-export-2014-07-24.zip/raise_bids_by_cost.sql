--/**
drop table ay_temp_yahoo_md_adid_bids2 purge;
create table ay_temp_yahoo_md_adid_bids2 nologging as
select distinct adid
from stg.yahoo_md_bid_history
where createddate >= trunc(sysdate) - 28
;
create index ay_temp_gs_md_adid_bids2$adid on ay_temp_yahoo_md_adid_bids2 (adid);
analyze table ay_temp_yahoo_md_adid_bids2 compute statistics;

drop table ay_temp_yahoo_md_bulk purge;
create table ay_temp_yahoo_md_bulk nologging as
select distinct * from
(select  adid,
        adgroupid,
        campaignid,
        keywordid,
        accountid,
        keyword,
        maximumcpc maximumcpc,
        averageposition pos,
	qualityindex,
        matchtype,
        RANK() OVER (PARTITION BY adid ORDER BY clickdate desc, keyword, keywordid, adgroupid, campaignid, network, creativeid, matchtype) rk
from stg.md_yahoo_ad_api_imp t
where clickdate >= trunc(sysdate) - 14
and clickdate < trunc(sysdate)
) ad
where rk = 1
and not exists (select * from ay_temp_yahoo_md_adid_bids2 where adid = ad.adid)
;

drop table ay_temp_yahoo_md_adid_bids2 purge;

drop table ay_temp_yahoo_md_bulk_poor purge;
create table ay_temp_yahoo_md_bulk_poor nologging as
select c.adid, cost, clicks, rev
from    (select adid, sum(cost) cost, sum(clicks) clicks
		from stg.md_yahoo_ad_api
		where clickdate >= trunc(sysdate) - 14
		and clickdate  < trunc(sysdate)
		group by adid) c,
        (select adid, sum(rev) rev
        from (select ml.adid, sum(foreigncpc) rev
                from dw.merchant_lead ml, ay_temp_yahoo_md_bulk t
                where ml.adid = t.adid
                and clickdate >= trunc(sysdate)  - 14 
                and isdup = 'n'
                group by ml.adid
                union all
                select ml.adid, sum(nvl(cpc_actual, foreigncpc)*numclick) rev
                from dw.adword_adid ml, ay_temp_yahoo_md_bulk t
                where ml.adid = t.adid
                and clickdate >= trunc(sysdate)  - 14 
                group by ml.adid
                )
        group by adid
        ) r
        where c.adid = r.adid(+)
	and nvl(r.rev,0) < c.cost*.75
;
--**/

/**
drop table ay_temp_yahoo_md_with_ml purge;
create table ay_temp_yahoo_md_with_ml nologging as
select distinct adid
from dw.merchant_lead
where clickdate >= trunc(sysdate) - 14
and isdup = 'n'
and siteid = 1
;
**/

set heading off
set linesize 300
set trimspool on

spool /home/dw/ayang/SQL/SEM/Bid/bids.yahoo.md2.bulk.txt

select
        to_char(k.accountid)||'|'||
        to_char(k.adgroupid)||'|'||
        to_char(k.keywordid)||'|'||
        least(50, round((1+least(.25, (pos-2)/20))*k.maximumcpc))||'|'||
        lower(substr(k.matchtype, 0, 1))||'|'||
        k.adid||'|'||
        to_char(k.campaignid)
from ay_temp_yahoo_md_bulk k
where least(50, round((1+least(.25, (pos-2)/20))*k.maximumcpc)) > k.maximumcpc
and pos >= 3
and qualityindex >= 5
and not exists (select * from ay_temp_yahoo_md_bulk_poor where adid = k.adid)
;
spool off

--drop table ay_temp_yahoo_md_bulk purge;
--drop table ay_temp_yahoo_md_bulk_poor purge;
quit
