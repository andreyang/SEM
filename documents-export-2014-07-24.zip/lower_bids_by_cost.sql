drop table ay_temp_yahoo_adid_bids2 purge;
create table ay_temp_yahoo_adid_bids2 nologging as
select distinct adid
from stg.yahoo_md_bid_history
where createddate >= trunc(sysdate) - 28
;

create index ay_temp_yahoo_adid_bids2$adid on ay_temp_yahoo_adid_bids2 (adid);

analyze table ay_temp_yahoo_adid_bids2 compute statistics;

drop table ay_temp_yahoo_bulk purge;
create table ay_temp_yahoo_bulk nologging as
select distinct * from
(select  adid,
	accountid,
        adgroupid,
        campaignid,
        keywordid,
        keyword,
        maximumcpc,
        averageposition pos,
        matchtype keywordtype,
        RANK() OVER (PARTITION BY adid ORDER BY clickdate desc, keyword, keywordid, adgroupid, campaignid, network, matchtype) rk
from stg.md_yahoo_ad_api_imp t
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
) ad
where not exists (select * from ay_temp_yahoo_adid_bids2 where adid = ad.adid)
and rk = 1
;

drop table ay_temp_yahoo_adid_bids2 purge;

drop table ay_temp_yahoo_bulk_good purge;
create table ay_temp_yahoo_bulk_good nologging as
select c.adid, cost, clicks, rev
from    (select adid, sum(cost) cost, sum(clicks) clicks
		from stg.md_yahoo_ad_api
		where clickdate >= trunc(sysdate) - 7
		and clickdate  < trunc(sysdate) 
		group by adid) c,
        (select adid, sum(rev) rev
        from (select ml.adid, sum(foreigncpc) rev
                from dw.merchant_lead ml, ay_temp_yahoo_bulk t
                where ml.adid = t.adid
                and clickdate >= trunc(sysdate)  - 7 
		and clickdate  < trunc(sysdate)
		and clickdate <> '07-Aug-2009'
                and isdup = 'n'
                group by ml.adid
                union all
                select ml.adid, sum(nvl(cpc_actual, foreigncpc)*numclick) rev
                from dw.adword_adid ml, ay_temp_yahoo_bulk t
                where ml.adid = t.adid
                and clickdate >= trunc(sysdate)  - 7 
		and clickdate  < trunc(sysdate)
		and clickdate <> '07-Aug-2009'
                group by ml.adid
                )
        group by adid
        ) r
        where c.adid = c.adid
	and c.adid = r.adid
	and rev > cost*.9
;


set heading off
set linesize 300
set trimspool on

spool /home/dw/ayang/SQL/SEM/Bid/bids.yahoo.lower.txt

select  distinct
        to_char(accountid)||'|'||
        to_char(adgroupid)||'|'||
        to_char(keywordid)||'|'||
        greatest(1, round(maximumcpc*(1-greatest(.1, (6-pos)/30))))||'|'||
	substr(lower(keywordtype), 1,1)||'|'||
        adid||'|'||
        to_char(campaignid)
from ay_temp_yahoo_bulk k
where pos < 6 and pos >= 0
and greatest(1, round(maximumcpc*(1-greatest(.1, (6-pos)/30)))) < maximumcpc
and not exists (select * from ay_temp_yahoo_bulk_good where adid = k.adid)
;
spool off

drop table ay_temp_yahoo_bulk purge;
drop table ay_temp_yahoo_bulk_good purge;
quit
