#!/usr/bin/perl
use Net::FTP;

my $ymd     = @ARGV[0];
my $slsdir  = "/home/oracle/apicker/Sales";
my $datadir = "$slsdir/Data";
#my $slsfile = "Pronto.$ymd.csv";
my $slsfile = "sz.$ymd.csv";
my $slsfile2 = "sz2.$ymd.csv";

print "$datadir/$slsfile\n";
system "touch $slsdir/Logs/sz_actuals.try";

$ftp = Net::FTP->new("ftp.pronto.com", Debug => 0)
  or die "Cannot connect to ftp.pronto.com: $@";    
$ftp->login("warehouse","Gee7eB1k")
  or die "Cannot login ", $ftp->message;    
$ftp->cwd("newcode");
$ftp->get($slsfile, "$datadir/sz_actuals.out")
  or die "get failed ", $ftp->message;    
$ftp->get($slsfile2, "$datadir/sz2_actuals.out")
  or die "get failed ", $ftp->message;
$ftp->quit;


