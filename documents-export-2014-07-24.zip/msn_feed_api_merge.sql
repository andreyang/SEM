drop table msn_ad_api_daily_temp purge
;

spool /home/dw/ayang/Log/MSNFeedAPIMerge.log;

--remove header rows
/**
delete from stg.msn_ad_api_daily t
where to_number(replace(clicks, ',', '')) > (select 0.49*sum(to_number(replace(clicks, ',', '')))
	from stg.google_ad_api_daily
	where account = t.account
	)
;
**/

delete from stg.msn_ad_api where clickdate = to_date('&1', 'yyyy-mm-dd');
delete from stg.msn_ad_api_imp where clickdate = to_date('&1', 'yyyy-mm-dd');
commit;

create table msn_ad_api_daily_temp tablespace TEMP_DATA nologging as
select
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
DestinationURL,
REGEXP_REPLACE(destinationurl,'.*adid=(.*_m{MatchType}s|.*_mbs|.*_mes|.*_mps).*','\1') adid,
Currencycode,
to_number(replace(Imp, ',', '')) Imp,
to_number(replace(Clicks, ',', '')) Clicks,
CTR,
AvgCPC,
to_number(replace(TotalCost, ',', '')) TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
from stg.msn_ad_api_daily
;

truncate table stg.msn_ad_api_daily;

insert into stg.msn_ad_api_imp
(
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
DestinationURL,
adid,
Currencycode,
Imp,
Clicks,
CTR,
AvgCPC,
TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
) 
select 
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
DestinationURL,
substr(replace(adid, '{MatchType}', decode(DeliveredMatchType, 'Broad', 'b', 'Exact', 'e', 'Phrase', 'p')), 1, 50),
Currencycode,
Imp,
Clicks,
CTR,
AvgCPC,
TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
from msn_ad_api_daily_temp
;

commit;

insert into stg.msn_ad_api
(
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
--DestinationURL,
adid,
Currencycode,
Imp,
Clicks,
CTR,
AvgCPC,
TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
)
select
Account,
CampaignID,
OrderID,
OrderItemID,
MSNAdID,
ClickDate,
Product,
Campaign,
Ordername,
Medium,
Keyword,
DeliveredMatchType,
CurrentMaximumCPC,
DistChannel,
--DestinationURL,
substr(replace(adid, '{MatchType}', decode(DeliveredMatchType, 'Broad', 'b', 'Exact', 'e', 'Phrase', 'p')), 1, 50),
Currencycode,
Imp,
Clicks,
CTR,
AvgCPC,
TotalCost,
AvgPos,
KeywordRelevance,
LandingPageRelevance,
LandingPageUserExperience,
QualityScore,
bidmatchtype
from msn_ad_api_daily_temp
where /** clickdate = to_date('&1', 'yyyy-mm-dd')
and **/
(clicks <> 0 or totalcost <> 0)
;

commit;

drop table msn_ad_api_daily_temp purge
;

spool off

quit;

