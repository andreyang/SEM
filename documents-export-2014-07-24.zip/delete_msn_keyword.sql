connect ayang@be1/redcarpet123
/**
create table ay_temp_msn_delete2 nologging as
select *
from ayang.ay_temp_msn_oh_adid@dwh
where accountid <> 944613
/

analyze table ay_temp_ctr_delete compute statistics;
**/
set heading off
set trimspool on
set linesize 300
spool /home/dw/ayang/Log/delete.msn.2.txt

select k.accountid||'|'||
        campaignname||'|'||
        to_char(k.campaignid)||'|'||
        adgroupname||'|'||
        to_char(k.adgroupid)||'|'||
        to_char(k.keywordid)||'|'||
        k.adid||'|'||
        k.keyword||'|'||
        lower(substr(k.matchtype, 0, 1))
from titan.keyword k, titan.adgroup g, titan.campaign c--, ay_temp_pronto_gf t
where k.adgroupid = g.adgroupid
and k.campaignid = g.campaignid
and k.campaignid = c.campaignid
--and k.adid = t.adid
and k.searchengine = '&2'
and k.keyword like '&1%'
--and k.businessname = 'pronto.com'
/**
union
select distinct 
	account||'|'||
        campaign||'|'||
        to_char(campaignid)||'|'||
        ordername||'|'||
        to_char(orderid)||'|'||
        to_char(orderitemid)||'|'||
        adid||'|'||
        lower(keyword)||'|'||
        lower(substr(deliveredmatchtype, 0, 1))
from stg.msn_ad_api@dwh
where clickdate >= trunc(sysdate) - 2
and lower(keyword) like '&1%'
union
select distinct
        account||'|'||
        campaign||'|'||
        to_char(campaignid)||'|'||
        ordername||'|'||
        to_char(orderid)||'|'||
        to_char(orderitemid)||'|'||
        adid||'|'||
        lower(keyword)||'|'||
        lower(substr(deliveredmatchtype, 0, 1))
from stg.msn_gifts_ad_api@dwh
where clickdate >= trunc(sysdate) - 2
and lower(keyword) like '&1%'
**/
union
select distinct
        accountid||'|'||
        campaign||'|'||
        to_char(campaignid)||'|'||
        adgroup||'|'||
        to_char(adgroupid)||'|'||
        to_char(keywordid)||'|'||
        adid||'|'||
        lower(keyword)||'|'||
        lower(substr(keywordtype, 0, 1))
from stg.google_ad_api@dwh
where clickdate >= trunc(sysdate) - 2
and lower(keyword) like '&1%'
union
select distinct
        accountid||'|'||
        campaign||'|'||
        to_char(campaignid)||'|'||
        adgroup||'|'||
        to_char(adgroupid)||'|'||
        to_char(keywordid)||'|'||
        adid||'|'||
        lower(keyword)||'|'||
        lower(substr(keywordtype, 0, 1))
from stg.google_ad_api_gifts@dwh
where clickdate >= trunc(sysdate) - 2
and lower(keyword) like '&1%'
--**/
;

spool off

--after delete job is finished, delete the adids in table ay_temp_msn_delete, reload, then drop the table

quit
