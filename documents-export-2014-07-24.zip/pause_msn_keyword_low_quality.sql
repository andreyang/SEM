/**
create table ay_temp_new_camp_msn nologging as
select campaignid
from titan.campaign@be1
where createddate >= trunc(sysdate) - 7
;
**/

drop table ay_temp_msn_click_lq purge;
create table ay_temp_msn_click_lq nologging as
select distinct * from
(select  adid,
        orderid adgroupid,
        campaignid,
        orderitemid keywordid,
        account accountid,
        lower(keyword) keyword,
        deliveredmatchtype matchtype,
        campaign,
	ordername adgroupname,
	KEYWORDRELEVANCE,
	LANDINGPAGERELEVANCE,
	qualityscore,
	RANK() OVER (PARTITION BY adid ORDER BY clickdate desc, lower(keyword), orderitemid, orderid, campaignid, msnadid, deliveredmatchtype) rk
from stg.msn_ad_api_imp t
where clickdate >= trunc(sysdate) - 7
and clickdate >= '20-Oct-2012'
and clickdate < trunc(sysdate)
and qualityscore > 0
--and adid like 'RLD-%'
--and campaignid not in (select campaignid from ay_temp_new_camp_msn)
) ad
where rk = 1
;

--drop table ay_temp_new_camp_msn purge;

/**
drop table ay_temp_msn_click_lq_r purge;
create table ay_temp_msn_click_lq_r nologging as
select keywordid
from dw.merchant_lead ml, ay_temp_msn_click_lq t
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
and ml.adid = t.adid
and siteid = 1
and ml.adid like '%m_s'
group by keywordid
--having count(*) > 1
;
**/

drop table ay_temp_msn_2_delete purge;
create table ay_temp_msn_2_delete nologging as
select t.* from ay_temp_msn_click_lq t
where qualityscore <= 2 and qualityscore > 0
--and not exists (select * from ay_temp_msn_click_lq t2 where t2.keywordid = t.keywordid and t2.qualityscore >= 5)
--(KEYWORDRELEVANCE <= 1 or LANDINGPAGERELEVANCE <= 1 or qualityscore <= 4)
--and not exists (select * from ay_temp_msn_click_lq_r where keywordid = t.keywordid)
;

set heading off
set trimspool on
set linesize 300
spool /home/dw/ayang/Log/pause.msn.low_qs.txt
select  accountid||'|'||
        campaign||'|'||
        to_char(campaignid)||'|'||
        adgroupname||'|'||
        to_char(adgroupid)||'|'||
        to_char(keywordid)||'|'||
        adid||'|'||
        keyword||'|'||
        lower(substr(matchtype, 0, 1))
from ay_temp_msn_2_delete t
;

spool off

select clickdate||'|'||sum(clicks)||'|'||sum(totalcost)
from stg.msn_ad_api ad, (select distinct keywordid from ay_temp_msn_2_delete) t
where ad.orderitemid = t.keywordid
and clickdate >= trunc(sysdate) - 7
group by clickdate
order by clickdate
;

select clickdate||'|'||sum(clicks)||'|'||sum(totalcost)
from stg.msn_ad_api ad, ay_temp_msn_2_delete t
where ad.adid = t.adid
and clickdate >= trunc(sysdate) - 7
group by clickdate
order by clickdate
;

select clickdate||'|'||sum(cpc*numclick)||'|'||sum(numclick)
from dw.adword_adid ad, ay_temp_msn_2_delete t
where ad.adid = t.adid
and clickdate >= trunc(sysdate) - 7
group by clickdate
order by clickdate
/

select clickdate||'|'||sum(cpc)||'|'||sum(1)
from dw.merchant_lead ad, ay_temp_msn_2_delete t
where ad.adid = t.adid
and clickdate >= trunc(sysdate) - 7
group by clickdate
order by clickdate
/
quit
