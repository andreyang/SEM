

drop table ap_temp_gcsiteperf_rt purge;
drop table ap_temp_gcsiteperf_cost purge;
drop table ap_temp_gcsiteperf_ml purge;
drop table ap_temp_gcsiteperf_asl purge;
drop table ap_temp_gcsiteperf purge;


set serveroutput on;
set heading off;
set trimspool on;
set linesize 600;
set timing on;
spool /home/dw/apicker/Logs/gc_site_performance.log;


create table ap_temp_gcsiteperf_cost nologging as
select
  1 siteid,
  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adgroup,
  max(campaignid) campaignid,
  sum(clicks) clicks,
  sum(cost/1000000) cost
from stg.google_ad_api_content
where clickdate = to_date('&1','mm/dd/yyyy')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
UNION ALL
select
  21 siteid,
  REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1') adgroup,
  max(campaignid) campaignid,
  sum(clicks) clicks,
  sum(cost/1000000) cost
from stg.google_ad_api_content_oh
where clickdate = to_date('&1','mm/dd/yyyy')
group by REGEXP_REPLACE(adgroup,'^[[:digit:]]{1,3}-([[:digit:]]+-[[:digit:]]+d*)-.*','\1')
;


alter table ap_temp_gcsiteperf_cost
add constraint gcsiteperfcost_pk
primary key (adgroup, siteid)
using index tablespace stage_index_san
;


analyze table ap_temp_gcsiteperf_cost compute statistics;


create table ap_temp_gcsiteperf_rt nologging as
select
  1 siteid,
  s.requestid,
  substr(trim(replace(s.site,' ','')),1,200) site,
  REGEXP_REPLACE(s.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') adgroup,
  cst.campaignid
from stg.comm_search_header s, ap_temp_gcsiteperf_cost cst
where not exists (select /*+ dynamic_sampling (s 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = s.ipaddress)
and s.timestamp2 >= to_date('&1','mm/dd/yyyy')
and s.timestamp2  < to_date('&1','mm/dd/yyyy')+1
and s.adid like '%_gc'
and REGEXP_REPLACE(s.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') = cst.adgroup(+)
and 1 = cst.siteid(+)
UNION ALL
select
  s.siteid,
  s.requestid,
  substr(trim(replace(s.site,' ','')),1,200) site,
  REGEXP_REPLACE(replace(s.adid,'-oh'), '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') adgroup,
  cst.campaignid
from flanker.search_header s, ap_temp_gcsiteperf_cost cst
where not exists (select /*+ dynamic_sampling (s 3) dynamic_sampling (b 3) */ * from stg.banned_ip b where ipaddress = s.ipaddress)
and s.timestamp2 >= to_date('&1','mm/dd/yyyy')
and s.timestamp2  < to_date('&1','mm/dd/yyyy')+1
and s.adid like '%_gc'
and REGEXP_REPLACE(replace(s.adid,'-oh'), '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') = cst.adgroup(+)
and s.siteid = cst.siteid(+)
;


create table ap_temp_gcsiteperf_ml nologging as
select
  ml.siteid, ml.site, cst.campaignid,
  count(*) mlcnt, sum(cpc) mlrev
from dw.merchant_lead ml, ap_temp_gcsiteperf_cost cst
where to_date('&1','mm/dd/yyyy') >= '01-JUL-08'
and ml.clickdate = to_date('&1','mm/dd/yyyy')
and ml.status = 'v'
and ml.channel = 'SEM'
and ml.adid like '%_gc'
and REGEXP_REPLACE(ml.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') = cst.adgroup(+)
group by ml.siteid, ml.site, cst.campaignid
;


create table ap_temp_gcsiteperf_asl nologging as
select
  al.siteid, al.site, cst.campaignid,
  count(*) adcnt, sum(cpc) adrev
from dw.adword_lead al, ap_temp_gcsiteperf_cost cst
where to_date('&1','mm/dd/yyyy') >= '01-JUL-08'
and al.clickdate = to_date('&1','mm/dd/yyyy')
and al.channel = 'SEM'
and al.adid like '%_gc'
and REGEXP_REPLACE(al.adid, '_[[:digit:]]+_gc|-[[:digit:]]+_gc', '') = cst.adgroup(+)
group by al.siteid, al.site, cst.campaignid
;


create table ap_temp_gcsiteperf nologging as
select
  to_date('&1','mm/dd/yyyy') clickdate,
  a.siteid, a.site, a.campaignid,
  siteclicks clicks,
  sitecost cost,
  nvl(mlcnt,0) mlcnt, nvl(mlrev,0) mlrev,
  nvl(adcnt,0) aslcnt, nvl(adrev,0) aslrev,
  nvl(totcnt,0) totcnt, nvl(totrev,0) totrev
from
 (select
    rt.siteid, rt.site, rt.campaignid,
    sum(siteclicks) siteclicks,
    sum(adgroupcost*(siteclicks/adgroupclicks)) sitecost
  from
   (select siteid, adgroup, site, max(campaignid) campaignid, count(*) siteclicks
    from ap_temp_gcsiteperf_rt
    group by siteid, adgroup, site) rt,
   (select siteid, adgroup, count(*) adgroupclicks
    from ap_temp_gcsiteperf_rt
    group by siteid, adgroup) aclk,
   (select siteid, adgroup, sum(cost) adgroupcost, sum(clicks) clicks
    from ap_temp_gcsiteperf_cost
    group by siteid, adgroup) acst
  where rt.siteid = acst.siteid
  and rt.adgroup = acst.adgroup
  and rt.siteid = aclk.siteid
  and rt.adgroup = aclk.adgroup
  group by rt.siteid, rt.site, rt.campaignid) a,
 (select 
    siteid, site, campaignid,
    sum(mlcnt) mlcnt, sum(mlrev) mlrev,
    sum(adcnt) adcnt, sum(adrev) adrev,
    sum(totcnt) totcnt, sum(totrev) totrev
  from
   (select 
      siteid, site, campaignid,
      sum(mlcnt) mlcnt, sum(mlrev) mlrev,
      0 adcnt, 0 adrev,
      sum(mlcnt) totcnt, sum(mlrev) totrev
    from ap_temp_gcsiteperf_ml
    group by siteid, site, campaignid
    UNION ALL
    select 
      siteid, site, campaignid,
      0 mlcnt, 0 mlrev,
      sum(adcnt) adcnt, sum(adrev) adrev,
      sum(adcnt) totcnt, sum(adrev) totrev
    from ap_temp_gcsiteperf_asl
    group by siteid, site, campaignid)
  group by siteid, site, campaignid) b
where a.siteid = b.siteid(+)
and a.site = b.site(+)
and a.campaignid = b.campaignid(+)
;


insert into dw.gc_site_performance
 (clickdate, site, campaignid, siteid,
  mlcnt, aslcnt, totcnt,
  mlrev, aslrev, totrev,
  clickins, cost)
select
  clickdate, site, campaignid, siteid,
  mlcnt, aslcnt, totcnt,
  mlrev, aslrev, totrev,
  clicks, cost
from ap_temp_gcsiteperf
where campaignid is not null
and site is not null
and siteid is not null
;


commit;


spool off;

drop table ap_temp_gcsiteperf_rt purge;
drop table ap_temp_gcsiteperf_cost purge;
drop table ap_temp_gcsiteperf_ml purge;
drop table ap_temp_gcsiteperf_asl purge;
drop table ap_temp_gcsiteperf purge;

quit;


