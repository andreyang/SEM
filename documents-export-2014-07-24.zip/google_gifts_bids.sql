spool /home/dw/ayang/Log/bids_google_gifts.log

drop table ay_temp_google_gifts_kwid purge;

create table ay_temp_google_gifts_kwid tablespace stage_temp_data nologging as
select distinct
        adid,
        mexpcategoryid,
        prontoadgroupid,
        adgroup,
        adgroupid,
        campaign,
        campaignid,
        keywordid,
        accountname,
	customerid,
	accountid,
        keyword,
	case when lower(keyword) like '%halloween%' or lower(keyword) like '%costume%' 
	or lower(keyword) like '%pumpkin carv%' then 'y' else 'n' end seasonal_flag,
	--'n' seasonal_flag,
        --case when clickdate >= trunc(sysdate) - 2 then maximumcpc else null end maximumcpc,
        maximumcpc,
	nvl(minimumcpc, .01) minimumcpc,
        averageposition,
        dailybudget,
        creativeid,
        --keyworddestinationurl,
        keywordtype,
	clickdate
from (
select  adid,
        REGEXP_REPLACE(adid,'s[[:digit:]]{1,4}-([[:digit:]]{1,6})-.*','\1') mexpcategoryid,
        REGEXP_REPLACE(adid,'-[[:digit:]]{1,6}_gs', '') prontoadgroupid,
        adgroup,
        adgroupid,
        campaign,
        campaignid,
        keywordid,
        accountname,
	customerid,
	accountid,
        keyword,
        maximumcpc/1000000 maximumcpc,
        minimumcpc/1000000 minimumcpc,
        averageposition,
        dailybudget/1000000 dailybudget,
        creativeid,
        --keyworddestinationurl,
        keywordtype,
	clickdate,
        RANK() OVER (PARTITION BY keywordid, adgroupid, campaignid, accountname ORDER BY clickdate desc, adid, averageposition, creativeid) rk
from stg.google_ad_api_gifts t
where adid is not null
--if there was no activity in the past 7 days, why do we need to make bid change as there is no new info? new campaigns would be exception
and clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013' 
and clicks > 0
/**
and not exists (select * from stg.ay_bids_error where account = t.accountname
			and keywordid = t.keywordid
			and adgroupid = t.adgroupid
		)
**/
)
where rk = 1
;
commit;

drop table ay_temp_hv_google_gifts_cost1 purge;

create table ay_temp_hv_google_gifts_cost1 tablespace stage_temp_data nologging as
select  adid, sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_gifts
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013' 
--and ADWORDSTYPE = 'Search Only'
and adid is not null
group by adid
having sum(clicks) >= 25
;
commit;

drop table ay_temp_hv_google_gifts_rev1 purge;

create table ay_temp_hv_google_gifts_rev1 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev1 rev, ml1 ml, 0 ad_lead
from ay_temp_hv_google_gifts_cost1 t, dw.merchant_lead_bid_gf ml
where t.adid = ml.adid
union all
select t.adid, .48*rev1, 0, ad_lead1 
from ay_temp_hv_google_gifts_cost1 t, dw.adword_adid_bid_gf ad
where t.adid = ad.adid
)
group by adid
;
commit;

drop table ay_temp_google_gifts_bids1 purge;

--here is where we control the margin
create table ay_temp_google_gifts_bids1 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
	t.accountid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
        t.adid,
        trunc(least(decode(t.accountname, 'g6', 0.75, 0.75), (case when t.averageposition >= 10 then 1.0 else case when t.minimumcpc <= t2.revenue/t1.clicks and t.minimumcpc > 1.000*t2.revenue/t1.clicks then t.minimumcpc/(t2.revenue/t1.clicks) else 1.000 end end)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t3.campaignid, null, decode(seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
	t.maximumcpc,
	t.keyword,
        lower(substr(t.keywordtype, 1, 1)) matchtype,
	t.seasonal_flag,
	t1.clicks
from ay_temp_google_gifts_kwid t, ay_temp_hv_google_gifts_cost1 t1, ay_temp_hv_google_gifts_rev1 t2, stg.seasonal_campaign t3
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t.campaignid = t3.campaignid(+)
and   (t1.clicks >= 50 or (nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) <= 0.2))
;
commit;

drop table ay_temp_hv_google_gifts_cost4 purge;

create table ay_temp_hv_google_gifts_cost4 tablespace stage_temp_data nologging as
select  adid, sum(cost)/1000000 cost, sum(clicks) clicks,
        sum(impressions) impressions
from stg.google_ad_api_gifts
where clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
--and ADWORDSTYPE = 'Search Only'
and adid is not null
group by adid
having sum(clicks) >= 10
;
commit;

drop table ay_temp_hv_google_gifts_rev4 purge;

create table ay_temp_hv_google_gifts_rev4 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, rev4 rev, ml4 ml, 0 ad_lead
from ay_temp_hv_google_gifts_cost4 t, dw.merchant_lead_bid_gf ml
where t.adid = ml.adid
union all
select t.adid, .48*rev4, 0, ad_lead4
from ay_temp_hv_google_gifts_cost4 t, dw.adword_adid_bid_gf ad
where t.adid = ad.adid
)
group by adid
;
commit;

drop table ay_temp_google_gifts_bids4 purge;

--here is where we control the margin
create table ay_temp_google_gifts_bids4 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
	t.accountid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
        t.adid,
        trunc(least(decode(t.accountname, 'g6', 0.75, 0.75), (case when t.averageposition >= 10 then 1.0 else case when t.minimumcpc <= t2.revenue/t1.clicks and t.minimumcpc > 1.000*t2.revenue/t1.clicks then t.minimumcpc/(t2.revenue/t1.clicks) else 1.000 end end)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t3.campaignid, null, decode(seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
	t.maximumcpc,
        t.keyword,
        lower(substr(t.keywordtype, 1, 1)) matchtype,
	t.seasonal_flag,
	t1.clicks
from ay_temp_google_gifts_kwid t, ay_temp_hv_google_gifts_cost4 t1, ay_temp_hv_google_gifts_rev4 t2, stg.seasonal_campaign t3
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t.campaignid = t3.campaignid(+)
;
commit;

drop table ay_temp_hv_google_gifts_cost8 purge;

--for daily bid job, we still use 15 clicks as threshold. otherwise it takes a long time to change bids for 100k keywords.
--scratch the above since we only make changes on keywords with activity in the past 7 days
create table ay_temp_hv_google_gifts_cost8 tablespace stage_temp_data nologging as
select 	adid, sum(cost)/1000000 cost, sum(clicks) clicks, 
	sum(impressions) impressions
from stg.google_ad_api_gifts
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013' 
--and ADWORDSTYPE = 'Search Only'
and adid is not null
group by adid
having sum(clicks) >= 10
;
commit;

/**
drop table ay_temp_hv_grp_goo_gifts_cost8 purge;
create table ay_temp_hv_grp_goo_gifts_cost8 tablespace stage_temp_data nologging as
select adid,
       adgroupid,
       campaignid,
       accountname accountname,
       sum(cost/1000000) cost,
       sum(clicks) clicks,
       sum(impressions) impressions
from (select adid,
      adgroupid,
      campaignid,
      accountname,
      clicks,
      cost,
      impressions,
      sum(clicks) over(partition by adgroupid, campaignid, accountname) sum_clicks
      from stg.google_ad_api_gifts
      where clickdate >= trunc(sysdate) - 56
      and clickdate < trunc(sysdate) and clickdate <> '19-Dec-2012' and clickdate <> '01-Feb-2013' and clickdate <> '02-Feb-2013'
)
where sum_clicks >= 20
group by adid, adgroupid, campaignid, accountname
;
**/

drop table ay_temp_hv_google_gifts_rev8 purge;

create table ay_temp_hv_google_gifts_rev8 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from 
(
select t.adid, rev8 rev, ml8 ml, 0 ad_lead
from ay_temp_hv_google_gifts_cost8 t, dw.merchant_lead_bid_gf ml
where t.adid = ml.adid
union all
select t.adid, .48*rev8, 0, ad_lead8 ad_lead
from ay_temp_hv_google_gifts_cost8 t, dw.adword_adid_bid_gf ad
where t.adid = ad.adid
)
group by adid
;
commit;

/**
drop table ay_temp_hv_grp_goo_gifts_rev8 purge;

--when the same adid lives in multiple adgroups, revenue is evenly allocated.
create table ay_temp_hv_grp_goo_gifts_rev8 tablespace stage_temp_data nologging as
select adgroupid, campaignid, accountname, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from 
(
select t.adgroupid, t.campaignid, t.accountname, sum(rev8/t2.ct) rev, sum(ml8/t2.ct) ml, 0 ad_lead
from ay_temp_hv_grp_goo_gifts_cost8 t, (select adid, count(*) ct from ay_temp_hv_grp_goo_gifts_cost8 group by adid) t2, dw.merchant_lead_bid_gf ml
where t.adid = ml.adid
and t.adid = t2.adid
group by t.adgroupid, t.campaignid, t.accountname
union all
select t.adgroupid, t.campaignid, t.accountname, sum(1.0*rev8/t2.ct), 0, sum(ad_lead8/t2.ct) ad_lead
from ay_temp_hv_grp_goo_gifts_cost8 t, (select adid, count(*) ct from ay_temp_hv_grp_goo_gifts_cost8 group by adid) t2, dw.adword_adid_bid_gf ad
where t.adid = ad.adid
and t.adid = t2.adid
group by t.adgroupid, t.campaignid, t.accountname
)
group by adgroupid, campaignid, accountname
;
**/

drop table ay_temp_google_gifts_bids8 purge;

--here is where we control the margin
--SEASONAL KEYWORD'S BIDS ARE CONTROLLED BY THE NUMBER AFTER y.
create table ay_temp_google_gifts_bids8 tablespace stage_temp_data nologging as
select distinct
	t.accountname,
	t.customerid,
	t.accountid,
	t.campaign,
	t.campaignid,
	t.adgroup,
	t.prontoadgroupid,
	t.adgroupid,
	t.keywordid,
	t.adid,
	trunc(least(decode(t.accountname, 'g6', 0.75, 0.75), (case when t.averageposition >= 10 then 1.0 else case when t.minimumcpc <= t2.revenue/t1.clicks and t.minimumcpc > 1.000*t2.revenue/t1.clicks then t.minimumcpc/(t2.revenue/t1.clicks) else 1.000 end end)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2)*decode(t3.campaignid, null, decode(seasonal_flag, 'y', 1, 1), 1) rpc,
	nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
	t.averageposition,
	t.maximumcpc,
	t.keyword,
        lower(substr(t.keywordtype, 1, 1)) matchtype,
	t.seasonal_flag,
	t1.clicks
from ay_temp_google_gifts_kwid t, ay_temp_hv_google_gifts_cost8 t1, ay_temp_hv_google_gifts_rev8 t2, stg.seasonal_campaign t3
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t.campaignid = t3.campaignid(+)
;
commit;

/**
drop table ay_temp_grp_goo_gifts_bids8 purge;

--here is where we control the margin
create table ay_temp_grp_goo_gifts_bids8 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
	t.customerid,
	t.accountid,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
        t.adid,
        trunc(least(decode(t.accountname, 'g6', 0.75, 0.75), (case when t.minimumcpc <= t2.revenue/t1.clicks and t.minimumcpc > 1.000*t2.revenue/t1.clicks then t.minimumcpc/(t2.revenue/t1.clicks) else 1.000 end)*nvl(t2.revenue,0.01*t1.clicks)/t1.clicks), 2) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
	t.maximumcpc,
        t.keyword,
        lower(substr(t.keywordtype, 1, 1)) matchtype,
	t.seasonal_flag,
	t1.clicks
from ay_temp_google_gifts_kwid t, (select adgroupid, campaignid, accountname, sum(cost) cost, sum(clicks) clicks from ay_temp_hv_grp_goo_gifts_cost8 group by adgroupid, campaignid, accountname) t1, ay_temp_hv_grp_goo_gifts_rev8 t2
where t1.adgroupid = t.adgroupid
and   t1.campaignid = t.campaignid
and   t1.accountname = t.accountname
and   t1.adgroupid = t2.adgroupid(+)
and   t1.campaignid = t2.campaignid(+)
and   t1.accountname = t2.accountname(+)
;
**/

drop table ay_temp_goo_gifts_bids_final purge;

--can increase bids by 30% each time
create table ay_temp_goo_gifts_bids_final tablespace stage_temp_data nologging as
select distinct
        accountname,
	customerid,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
	matchtype,
        'HV - 1 wk 25' type, 
	seasonal_flag,
	clicks
from ay_temp_google_gifts_bids1 t
where (roi < 1/1.000 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
/**
and not exists (select * from stg.google_gifts_bid_history
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        and type like 'deleted%'
        )
**/
union all
select distinct
        accountname,
	customerid,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
	matchtype,
        'HV - 4 wk 10',
	seasonal_flag,
	clicks
from ay_temp_google_gifts_bids4 t
where (roi < 1/1.000 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
/**
and not exists (select * from stg.google_gifts_bid_history
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        and type like 'deleted%'
        )
**/
and not exists (select * from ay_temp_google_gifts_bids1
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        )
union all
select distinct
        accountname,
	customerid,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
	matchtype,
        'HV - 8 wk 15',
	seasonal_flag,
	clicks
from ay_temp_google_gifts_bids8 t
where (roi < 1/1.000 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
/**
and not exists (select * from stg.google_gifts_bid_history
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        and type like 'deleted%'
        )
**/
and not exists (select * from ay_temp_google_gifts_bids1
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        )
and not exists (select * from ay_temp_google_gifts_bids4
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        )
/**
union all
select distinct
        accountname,
	customerid,
	accountid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(rpc, nvl(1.3*maximumcpc, rpc)) rpc,
        roi,
        averageposition,
        keyword,
	matchtype,
        'HV - 8 wk adgrp15',
        seasonal_flag,
	clicks
from ay_temp_grp_goo_gifts_bids8 t
where (roi < 1/1.000 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
and not exists (select * from ay_temp_google_gifts_bids1
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        )
and not exists (select * from ay_temp_google_gifts_bids4
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        )
and not exists (select * from ay_temp_google_gifts_bids8
        where keywordid = t.keywordid
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
        )
**/
;

spool off

set heading off
set trimspool on
set linesize 250

spool &1
--/home/dw/ayang/Log/bids_google_gifts.txt

select distinct
	--t.accountname||'|'||
	to_char(t.customerid)||'|'||
	to_char(t.adgroupid)||'|'||
	to_char(t.keywordid)||'|'||
	greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'MONDAY', 1.1, 'SUNDAY', 1.05, 1.0), 0.01)||'|'||
	t.matchtype||'|'||
	t.adid||'|'||
	to_char(t.campaignid)||'|'||
	keyword
from ay_temp_goo_gifts_bids_final t
where exists (select avg(rpc) from ay_temp_goo_gifts_bids_final having avg(rpc) <= .2)
--where type like '%1 wk%'
--where mod(t.keywordid,3) = 0
--where seasonal_flag = 'y'
;

spool off;

spool &2

select distinct
        t.accountid||'|'||
        t.campaign||'|'||
        t.campaignid||'|'||
        t.adgroup||'|'||
        t.adgroupid||'|'||
        t.keywordid||'|'||
        t.adid||'|'||
        t.keyword||'|'||
        t.matchtype
from ay_temp_goo_gifts_bids_final t
where exists (select avg(rpc) from ay_temp_goo_gifts_bids_final having avg(rpc) < .2)
and clicks >= 100
and rpc <= .01
and type <> 'HV - 8 wk adgrp15'
;

spool off

insert into stg.google_gifts_bid_history
(
        accountname,
	customerid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        rpc,
        roi,
        averageposition,
        keyword,
        type
)
select distinct
        accountname,
	customerid,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        rpc*decode(trim(to_char(sysdate, 'DAY')), 'MONDAY', 1.1, 'SUNDAY', 1.05, 1.0),
        roi,
        averageposition,
        keyword,
	type
from ay_temp_goo_gifts_bids_final
where exists (select avg(rpc) from ay_temp_goo_gifts_bids_final having avg(rpc) <= .2)
;

commit;

drop table ay_temp_google_gifts_kwid purge;
drop table ay_temp_hv_google_gifts_cost1 purge;
drop table ay_temp_hv_google_gifts_rev1 purge;
drop table ay_temp_google_gifts_bids1 purge;
drop table ay_temp_hv_google_gifts_cost4 purge;
drop table ay_temp_hv_google_gifts_rev4 purge;
drop table ay_temp_google_gifts_bids4 purge;
drop table ay_temp_hv_google_gifts_cost8 purge;
drop table ay_temp_hv_grp_goo_gifts_cost8 purge;
drop table ay_temp_hv_google_gifts_rev8 purge;
drop table ay_temp_hv_grp_goo_gifts_rev8 purge;
drop table ay_temp_google_gifts_bids8 purge;
drop table ay_temp_grp_goo_gifts_bids8 purge;
drop table ay_temp_goo_gifts_bids_final purge;

quit;

