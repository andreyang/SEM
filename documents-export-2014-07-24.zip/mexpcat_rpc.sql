drop table ay_temp_gs_ads purge;

create table ay_temp_gs_ads nologging as
select adid, mexpcategoryid, sum(ct) ct
from 
(
select adid, mexpcategoryid, count(*) ct
from stg.comm_search_unique sc, stg.golden_category gc
where sc.goldenCATEGORYID = gc.goldencategoryid
and sc.timestamp2 >= trunc(sysdate) - 7 
and sc.timestamp2 < trunc(sysdate) 
and pagenumber = 1
and (adid like '%_gs' or adid like '%m_s')
and not exists (select * from stg.banned_ip
        		where ipaddress = sc.ipaddress)
group by adid, mexpcategoryid
union all
select adid, mexpcategoryid, count(*) ct
from stg.comm_search_golden sc, stg.golden_category gc
where sc.goldenCATEGORYID = gc.goldencategoryid
and sc.timestamp2 >= trunc(sysdate) - 7
and sc.timestamp2 < trunc(sysdate) 
and pagenumber = 1
and (adid like '%_gs' or adid like '%m_s')
and not exists (select * from stg.banned_ip
        		where ipaddress = sc.ipaddress)
group by adid, mexpcategoryid
)
group by adid, mexpcategoryid
;

commit;

analyze table ay_temp_gs_ads compute statistics;

drop table ay_temp_gs_ads2 purge;

create table ay_temp_gs_ads2 nologging as
select adid, sum(ct) ct
from ay_temp_gs_ads
group by adid
;

commit;

analyze table ay_temp_gs_ads2 compute statistics;

set heading off
set trimspool on
set linesize 200
spool /home/dw/ayang/Log/rpc_by_mexpcat.txt

select mc.mexpcategoryid ||'|'|| trunc(nvl(rev/decode(clicks, 0, null, clicks), 0), 4)||'|'||minimumbid||'|'||round(clicks)
from stg.mexp_category mc,
(select mexpcategoryid, sum(clicks) clicks
from (select t.mexpcategoryid, sum(clicks*t.ct/t2.ct) clicks
from stg.google_ad_api ad, ay_temp_gs_ads t, ay_temp_gs_ads2 t2
where ad.adid = t.adid
and ad.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 7 
and ad.clickdate < trunc(sysdate) 
group by t.mexpcategoryid
union all
select t.mexpcategoryid, sum(clicks*t.ct/t2.ct) clicks
from stg.msn_ad_api ad, ay_temp_gs_ads t, ay_temp_gs_ads2 t2
where ad.adid = t.adid
and ad.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 7
and ad.clickdate < trunc(sysdate)
group by t.mexpcategoryid
) 
group by mexpcategoryid
) md1,
(
select mexpcategoryid, sum(rev) rev
from (
select gc.mexpcategoryid, sum(cpc) rev
from dw.merchant_lead ad, ay_temp_gs_ads2 t, stg.golden_category gc
where ad.adid = t.adid
and ad.goldencategoryid = gc.goldencategoryid
and ad.clickdate >= trunc(sysdate) - 7
and ad.clickdate < trunc(sysdate) 
and ad.isdup = 'n'
and siteid = 1
group by gc.mexpcategoryid
union all
select ad.mexpcategoryid, sum(nvl(cpc_actual, cpc)*numclick) rev
from dw.adword ad, ay_temp_gs_ads2 t
where ad.adid = t.adid
and ad.clickdate >= trunc(sysdate) - 7 
and ad.clickdate < trunc(sysdate) 
and siteid = 1
group by ad.mexpcategoryid
) 
group by mexpcategoryid ) md2
where mc.mexpcategoryid = md1.mexpcategoryid(+)
and mc.mexpcategoryid = md2.mexpcategoryid(+)
;

spool off

drop table ay_temp_gs_ads2 purge;
drop table ay_temp_gs_ads purge;
quit

