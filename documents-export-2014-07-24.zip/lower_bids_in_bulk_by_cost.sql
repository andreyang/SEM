drop table ay_temp_google_adid_bids2 purge;
create table ay_temp_google_adid_bids2 nologging as
select distinct adid
from stg.google_bid_history
where createddate >= trunc(sysdate) - 28
;

create index ay_temp_google_adid_bids2$adid on ay_temp_google_adid_bids2 (adid);

analyze table ay_temp_google_adid_bids2 compute statistics;

drop table ay_temp_google_bulk purge;
create table ay_temp_google_bulk nologging as
select distinct * from
(select  adid,
        adgroupid,
        campaignid,
        keywordid,
        customerid,
        keyword,
        maximumcpc/1000000 maximumcpc,
        minimumcpc/1000000 minimumcpc,
        averageposition pos,
        keywordtype,
        RANK() OVER (PARTITION BY adid ORDER BY clickdate desc, keyword, keywordid, adgroupid, campaignid, network, creativeid, keywordtype) rk
from stg.google_ad_api t
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
--and adid not like '%bmx%'
) ad
where not exists (select * from ay_temp_google_adid_bids2 where adid = ad.adid)
and rk = 1
;

drop table ay_temp_google_adid_bids2 purge;

drop table ay_temp_google_bulk_good purge;
create table ay_temp_google_bulk_good nologging as
select c.adid, cost, clicks, rev
from    (select adid, sum(cost/1000000) cost, sum(clicks) clicks
		from stg.google_ad_api
		where clickdate >= trunc(sysdate) - 7
		and clickdate  < trunc(sysdate) 
		group by adid) c,
        (select adid, sum(rev) rev
        from (select ml.adid, sum(cpc) rev
                from dw.merchant_lead ml, ay_temp_google_bulk t
                where ml.adid = t.adid
                and clickdate >= trunc(sysdate)  - 7 and clickdate <> '07-Aug-2009'
                and isdup = 'n'
                group by ml.adid
                union all
                select ml.adid, sum(nvl(cpc_actual, cpc)*numclick) rev
                from dw.adword_adid ml, ay_temp_google_bulk t
                where ml.adid = t.adid
                and clickdate >= trunc(sysdate)  - 7 and clickdate <> '07-Aug-2009'
                group by ml.adid
                )
        group by adid
        ) r
        where c.adid = c.adid
	and c.adid = r.adid
	and rev >= cost*.9
;


/**
drop table ay_temp_google_with_ml purge;
create table ay_temp_google_with_ml nologging as
select distinct adid
from dw.merchant_lead
where clickdate >= trunc(sysdate) - 7
and isdup = 'n'
and siteid = 1
;
**/

set heading off
set linesize 300
set trimspool on

spool /home/dw/ayang/SQL/SEM/Bid/bids.google2.bulk.txt

select
        to_char(k.customerid)||'|'||
        to_char(k.adgroupid)||'|'||
        to_char(k.keywordid)||'|'||
        round(maximumcpc*.9, 2)||'|'||
	--greatest(k.minimumcpc, round(maximumcpc*.9, 2))||'|'||
        lower(substr(k.keywordtype, 0, 1))||'|'||
        k.adid||'|'||
        to_char(k.campaignid)||'|'||
	k.keyword
from ay_temp_google_bulk k
where pos <= 5
and round(maximumcpc*.9, 2) /**greatest(k.minimumcpc, round(maximumcpc*.9, 2))**/ < maximumcpc
and not exists (select * from ay_temp_google_bulk_good where adid = k.adid)
;
spool off

drop table ay_temp_google_bulk purge;
drop table ay_temp_google_bulk_good purge;
quit
