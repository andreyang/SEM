#!/usr/bin/perl
use strict;
use Shell qw(cp gunzip mv);
use Switch;


if (@ARGV != 6) {
  print "invalid number of arguments ... exiting\n";
  exit 1;
}


#####
## input 
my $year=$ARGV[0];
my $mon=$ARGV[1];
my $mday=$ARGV[2];
my $hour=$ARGV[3];
my $serverlist=$ARGV[4];
my $istest=$ARGV[5];


#####
## sub declaration
sub get_imp_files;
sub user_imp;
sub crawl_imp;


#####
## sub variables
my $ImpRow;
my $Imp;
my $WholeImp;
my $ImpType;
my $Server;
my $useragent;
my $record;
my @bot;
my @col;
my @likeitem;
my @imp_request2;


#####
## file declaration
my $loaddir;
if ($istest == 0) {
  $loaddir="/home/oracle/apicker/Load";
} else {
  $loaddir="/home/oracle/apicker/TestLoad";
}
my $botfile =       "$loaddir/bot.txt";
my $datadir =       "$loaddir/Data/pronto";
my $infile =        "$datadir/impressions.log";
my $logdir =        "$loaddir/Logs/pronto";
my $logdir_crawl =  "$loaddir/Logs/pronto/Crawl";
my $filecheck =     "$logdir/hourly_imp_files.log";
my $filecheck_all = "$logdir/History/hourly_imp_files_all.log";
my $NoHome        = "$logdir/NoHome.log";
my $NoFile        = "$logdir/NoFile.log";


#####
## out files
my $AddToList = "$logdir/AddToList.out";
open(AddToList, "> $AddToList") or die "Couldn't open $AddToList for writing: $!\n";
my $Adword = "$logdir/Adword.out";
open(Adword, "> $Adword") or die "Couldn't open $Adword for writing: $!\n";
my $AdwordClick = "$logdir/AdwordClick.out";
open(AdwordClick, "> $AdwordClick") or die "Couldn't open $AdwordClick for writing: $!\n";
my $Affiliate = "$logdir/Affiliate.out";
open(Affiliate, "> $Affiliate") or die "Couldn't open $Affiliate for writing: $!\n";
my $AllRequest = "$logdir/AllRequest.out";
open(AllRequest, "> $AllRequest") or die "Couldn't open $AllRequest for writing: $!\n";
my $AllRequestMBL = "$logdir/AllRequestMBL.out";
open(AllRequestMBL, "> $AllRequestMBL") or die "Couldn't open $AllRequestMBL for writing: $!\n";
my $BrandHeader = "$logdir/BrandHeader.out";
open(BrandHeader, "> $BrandHeader") or die "Couldn't open $BrandHeader for writing: $!\n";
my $BrandTab = "$logdir/BrandTab.out";
open(BrandTab, "> $BrandTab") or die "Couldn't open $BrandTab for writing: $!\n";
my $BrowseHeader = "$logdir/BrowseHeader.out";
open(BrowseHeader, "> $BrowseHeader") or die "Couldn't open $BrowseHeader for writing: $!\n";
my $BrowseLocal = "$logdir/BrowseLocal.out";
open(BrowseLocal, "> $BrowseLocal") or die "Couldn't open $BrowseLocal for writing: $!\n";
my $BuyingGuide = "$logdir/BuyingGuide.out";
open(BuyingGuide, "> $BuyingGuide") or die "Couldn't open $BuyingGuide for writing: $!\n";
my $CommURL = "$logdir/CommURL.out";
open(CommURL, "> $CommURL") or die "Couldn't open $CommURL for writing: $!\n";
my $EmailSettings = "$logdir/EmailSettings.out";
open(EmailSettings, "> $EmailSettings") or die "Couldn't open $EmailSettings for writing: $!\n";
my $FriendAccept = "$logdir/FriendAccept.out";
open(FriendAccept, "> $FriendAccept") or die "Couldn't open $FriendAccept for writing: $!\n";
my $FriendDialog = "$logdir/FriendDialog.out";
open(FriendDialog, "> $FriendDialog") or die "Couldn't open $FriendDialog for writing: $!\n";
my $FriendResponse = "$logdir/FriendResponse.out";
open(FriendResponse, "> $FriendResponse") or die "Couldn't open $FriendResponse for writing: $!\n";
my $FriendSent = "$logdir/FriendSent.out";
open(FriendSent, "> $FriendSent") or die "Couldn't open $FriendSent for writing: $!\n";
my $FullReferrer = "$logdir/FullReferrer.out";
open(FullReferrer, "> $FullReferrer") or die "Couldn't open $FullReferrer for writing: $!\n";
my $GenericRedirect = "$logdir/GenericRedirect.out";
open(GenericRedirect, "> $GenericRedirect") or die "Couldn't open $GenericRedirect for writing: $!\n";
my $GridAccMod = "$logdir/GridAccMod.out";
open(GridAccMod, "> $GridAccMod") or die "Couldn't open $GridAccMod for writing: $!\n";
my $GridHeader = "$logdir/GridHeader.out";
open(GridHeader, "> $GridHeader") or die "Couldn't open $GridHeader for writing: $!\n";
my $GridProduct = "$logdir/GridProduct.out";
open(GridProduct, "> $GridProduct") or die "Couldn't open $GridProduct for writing: $!\n";
my $GridReviews = "$logdir/GridReviews.out";
open(GridReviews, "> $GridReviews") or die "Couldn't open $GridReviews for writing: $!\n";
my $GridRelated = "$logdir/GridRelated.out";
open(GridRelated, "> $GridRelated") or die "Couldn't open $GridRelated for writing: $!\n";
my $HomepageHeader = "$logdir/HomepageHeader.out";
open(HomepageHeader, "> $HomepageHeader") or die "Couldn't open $HomepageHeader for writing: $!\n";
my $ItemReview = "$logdir/ItemReview.out";
open(ItemReview, "> $ItemReview") or die "Couldn't open $ItemReview for writing: $!\n";
my $LandingPage = "$logdir/LandingPage.out";
open(LandingPage, "> $LandingPage") or die "Couldn't open $LandingPage for writing: $!\n";
my $LightboxRefresh = "$logdir/LightboxRefresh.out";
open(LightboxRefresh, "> $LightboxRefresh") or die "Couldn't open $LightboxRefresh for writing: $!\n";
my $ListEvent = "$logdir/ListEvent.out";
open(ListEvent, "> $ListEvent") or die "Couldn't open $ListEvent for writing: $!\n";
my $ListSearch = "$logdir/ListSearch.out";
open(ListSearch, "> $ListSearch") or die "Couldn't open $ListSearch for writing: $!\n";
my $ListSend = "$logdir/ListSend.out";
open(ListSend, "> $ListSend") or die "Couldn't open $ListSend for writing: $!\n";
my $LocalMerchant = "$logdir/LocalMerchant.out";
open(LocalMerchant, "> $LocalMerchant") or die "Couldn't open $LocalMerchant for writing: $!\n";
my $LocalMerchantDetail = "$logdir/LocalMerchantDetail.out";
open(LocalMerchantDetail, "> $LocalMerchantDetail") or die "Couldn't open $LocalMerchantDetail for writing: $!\n";
my $LocalProd = "$logdir/LocalProd.out";
open(LocalProd, "> $LocalProd") or die "Couldn't open $LocalProd for writing: $!\n";
my $Login = "$logdir/Login.out";
open(Login, "> $Login") or die "Couldn't open $Login for writing: $!\n";
my $LogoCampClick = "$logdir/LogoCampClick.out";
open(LogoCampClick, "> $LogoCampClick") or die "Couldn't open $LogoCampClick for writing: $!\n";
my $MerchantSearchHeader = "$logdir/MerchantSearchHeader.out";
open(MerchantSearchHeader, "> $MerchantSearchHeader") or die "Couldn't open $MerchantSearchHeader for writing: $!\n";
my $MerchantTab = "$logdir/MerchantTab.out";
open(MerchantTab, "> $MerchantTab") or die "Couldn't open $MerchantTab for writing: $!\n";
my $MicrositeDirectory = "$logdir/MicrositeDirectory.out";
open(MicrositeDirectory, "> $MicrositeDirectory") or die "Couldn't open $MicrositeDirectory for writing: $!\n";
my $MsgDialog = "$logdir/MsgDialog.out";
open(MsgDialog, "> $MsgDialog") or die "Couldn't open $MsgDialog for writing: $!\n";
my $MsgSent = "$logdir/MsgSent.out";
open(MsgSent, "> $MsgSent") or die "Couldn't open $MsgSent for writing: $!\n";
my $NewReg = "$logdir/NewReg.out";
open(NewReg, "> $NewReg") or die "Couldn't open $NewReg for writing: $!\n";
my $NPS = "$logdir/NPS.out";
open(NPS, "> $NPS") or die "Couldn't open $NPS for writing: $!\n";
my $PixelTracking = "$logdir/PixelTracking.out";
open(PixelTracking, "> $PixelTracking") or die "Couldn't open $PixelTracking for writing: $!\n";
my $ProdEmail = "$logdir/ProdEmail.out";
open(ProdEmail, "> $ProdEmail") or die "Couldn't open $ProdEmail for writing: $!\n";
my $ProdErr = "$logdir/ProdErr.out";
open(ProdErr, "> $ProdErr") or die "Couldn't open $ProdErr for writing: $!\n";
my $ProdTab = "$logdir/ProdTab.out";
open(ProdTab, "> $ProdTab") or die "Couldn't open $ProdTab for writing: $!\n";
my $ProductRedirect = "$logdir/ProductRedirect.out";
open(ProductRedirect, "> $ProductRedirect") or die "Couldn't open $ProductRedirect for writing: $!\n";
my $ProductRedirectMBL = "$logdir/ProductRedirectMBL.out";
open(ProductRedirectMBL, "> $ProductRedirectMBL") or die "Couldn't open $ProductRedirectMBL for writing: $!\n";
my $ProdSense = "$logdir/ProdSense.out";
open(ProdSense, "> $ProdSense") or die "Couldn't open $ProdSense for writing: $!\n";
my $Profile = "$logdir/Profile.out";
open(Profile, "> $Profile") or die "Couldn't open $Profile for writing: $!\n";
my $RFSel = "$logdir/RFSel.out";
open(RFSel, "> $RFSel") or die "Couldn't open $RFSel for writing: $!\n";
my $RegForm = "$logdir/RegForm.out";
open(RegForm, "> $RegForm") or die "Couldn't open $RegForm for writing: $!\n";
my $RemoveFromList = "$logdir/RemoveFromList.out";
open(RemoveFromList, "> $RemoveFromList") or die "Couldn't open $RemoveFromList for writing: $!\n";
my $SearchAccMod = "$logdir/SearchAccMod.out";
open(SearchAccMod, "> $SearchAccMod") or die "Couldn't open $SearchAccMod for writing: $!\n";
my $SearchFilter = "$logdir/SearchFilter.out";
open(SearchFilter, "> $SearchFilter") or die "Couldn't open $SearchFilter for writing: $!\n";
my $SearchForcedNR = "$logdir/SearchForcedNR.out";
open(SearchForcedNR, "> $SearchForcedNR") or die "Couldn't open $SearchForcedNR for writing: $!\n";
my $SearchGolden = "$logdir/SearchGolden.out";
open(SearchGolden, "> $SearchGolden") or die "Couldn't open $SearchGolden for writing: $!\n";
my $SearchHeader = "$logdir/SearchHeader.out";
open(SearchHeader, "> $SearchHeader") or die "Couldn't open $SearchHeader for writing: $!\n";
my $SearchRelated = "$logdir/SearchRelated.out";
open(SearchRelated, "> $SearchRelated") or die "Couldn't open $SearchRelated for writing: $!\n";
my $SearchRelatedLink = "$logdir/SearchRelatedLink.out";
open(SearchRelatedLink, "> $SearchRelatedLink") or die "Couldn't open $SearchRelatedLink for writing: $!\n";
my $SearchRelGolden = "$logdir/SearchRelGolden.out";
open(SearchRelGolden, "> $SearchRelGolden") or die "Couldn't open $SearchRelGolden for writing: $!\n";
my $SearchRelUnique = "$logdir/SearchRelUnique.out";
open(SearchRelUnique, "> $SearchRelUnique") or die "Couldn't open $SearchRelUnique for writing: $!\n"; 
my $SearchUnique = "$logdir/SearchUnique.out";
open(SearchUnique, "> $SearchUnique") or die "Couldn't open $SearchUnique for writing: $!\n";
my $SeasonalGolden = "$logdir/SeasonalGolden.out";
open(SeasonalGolden, "> $SeasonalGolden") or die "Couldn't open $SeasonalGolden for writing: $!\n";
my $SeasonalHeader = "$logdir/SeasonalHeader.out";
open(SeasonalHeader, "> $SeasonalHeader") or die "Couldn't open $SeasonalHeader for writing: $!\n";
my $SeasonalQuery = "$logdir/SeasonalQuery.out";
open(SeasonalQuery, "> $SeasonalQuery") or die "Couldn't open $SeasonalQuery for writing: $!\n";
my $SeasonalUnique = "$logdir/SeasonalUnique.out";
open(SeasonalUnique, "> $SeasonalUnique") or die "Couldn't open $SeasonalUnique for writing: $!\n";
my $SeeMore = "$logdir/SeeMore.out";
open(SeeMore, "> $SeeMore") or die "Couldn't open $SeeMore for writing: $!\n";
my $SEORedirect = "$logdir/SEORedirect.out";
open(SEORedirect, "> $SEORedirect") or die "Couldn't open $SEORedirect for writing: $!\n";
my $Sharing = "$logdir/Sharing.out";
open(Sharing, "> $Sharing") or die "Couldn't open $Sharing for writing: $!\n";
my $Steals = "$logdir/Steals.out";
open(Steals, "> $Steals") or die "Couldn't open $Steals for writing: $!\n";
my $QuickDetails = "$logdir/QuickDetails.out";
open(QuickDetails, "> $QuickDetails") or die "Couldn't open $QuickDetails for writing: $!\n";


#####
## out files (crawl)
my $AllRequest_crawl = "$logdir_crawl/AllRequest.out";
open(AllRequest_crawl, "> $AllRequest_crawl") or die "Couldn't open $AllRequest_crawl for writing: $!\n";
my $BrowseHeader_crawl = "$logdir_crawl/BrowseHeader.out";
open(BrowseHeader_crawl, "> $BrowseHeader_crawl") or die "Couldn't open $BrowseHeader_crawl for writing: $!\n";
my $CommURL_crawl = "$logdir_crawl/CommURL.out";
open(CommURL_crawl, "> $CommURL_crawl") or die "Couldn't open $CommURL_crawl for writing: $!\n";
my $GridHeader_crawl = "$logdir_crawl/GridHeader.out";
open(GridHeader_crawl, "> $GridHeader_crawl") or die "Couldn't open $GridHeader_crawl for writing: $!\n";
my $ProductRedirect_crawl = "$logdir_crawl/ProductRedirect.out";
open(ProductRedirect_crawl, "> $ProductRedirect_crawl") or die "Couldn't open $ProductRedirect_crawl for writing: $!\n";
my $SearchHeader_crawl = "$logdir_crawl/SearchHeader.out";
open(SearchHeader_crawl, "> $SearchHeader_crawl") or die "Couldn't open $SearchHeader_crawl for writing: $!\n";
my $SearchFilter_crawl = "$logdir_crawl/SearchFilter.out";
open(SearchFilter_crawl, "> $SearchFilter_crawl") or die "Couldn't open $SearchFilter_crawl for writing: $!\n";
my $SearchRelatedLink_crawl = "$logdir_crawl/SearchRelatedLink.out";
open(SearchRelatedLink_crawl, "> $SearchRelatedLink_crawl") or die "Couldn't open $SearchRelatedLink_crawl for writing: $!\n";
my $SEORedirect_crawl = "$logdir_crawl/SEORedirect.out";
open(SEORedirect_crawl, "> $SEORedirect_crawl") or die "Couldn't open $SEORedirect_crawl for writing: $!\n";


########################################################################################################################
########################################################################################################################
########################################################################################################################


#####
## load bot file into array
my $ind = 0;
open(botfile, "< $botfile") or die "Couldn't open $botfile for reading: $!\n";
while ($record = <botfile>) {
  chomp($record);  # remove new line character
  @bot[$ind] = $record;
  $ind++;
}
close($botfile);


#####
## get impressions files
get_imp_files();


open(infile, "< $infile") or die "Couldn't open $infile for reading: $!\n";
open(NoHome, "> $NoHome") or die "Couldn't open $NoHome for writing: $!\n";


#####
## loop thru imp file
while ($record = <infile>) {	
  chomp($record);  # remove new line character 
  @imp_request2 = split(/\|/, $record);

  if (@imp_request2[1] eq 'headerRow') {
    $useragent = lc(@imp_request2[8]);
  } else {
    $useragent = lc(@imp_request2[7]);
  }

  if (length($useragent) < 15) {
    ##crawl_imp($record);
  }
  elsif (bot_testing($useragent) == 1) {
    ##crawl_imp($record);
  }
  else {
    user_imp($record);
  }
}

########################################################################################################################
########################################################################################################################
########################################################################################################################


#####
## close out files
close(AddToList);
close(Adword);
close(AdwordClick);
close(Affiliate);
close(AllRequest);
close(AllRequestMBL);
close(BrandHeader);
close(BrandTab);
close(BrowseHeader);
close(BrowseLocal);
close(BuyingGuide);
close(CommURL);
close(EmailSettings);
close(FriendAccept);
close(FriendDialog);
close(FriendResponse);
close(FriendSent);
close(FullReferrer);
close(GenericRedirect);
close(GridAccMod);
close(GridHeader);
close(GridProduct);
close(GridReviews);
close(GridRelated);
close(HomepageHeader);
close(ItemReview);
close(LandingPage);
close(LightboxRefresh);
close(ListEvent);
close(ListSearch);
close(ListSend);
close(LocalMerchant);
close(LocalMerchantDetail);
close(LocalProd);
close(Login);
close(LogoCampClick);
close(MerchantSearchHeader);
close(MerchantTab);
close(MicrositeDirectory);
close(MsgDialog);
close(MsgSent);
close(NewReg);
close(NPS);
close(PixelTracking);
close(ProdEmail);
close(ProdErr);
close(ProdTab);
close(ProductRedirect);
close(ProductRedirectMBL);
close(ProdSense);
close(Profile);
close(RFSel);
close(RegForm);
close(RemoveFromList);
close(SearchAccMod);
close(SearchFilter);
close(SearchForcedNR);
close(SearchGolden);
close(SearchHeader);
close(SearchRelated);
close(SearchRelatedLink);
close(SearchRelGolden);
close(SearchRelUnique);
close(SearchUnique);
close(SeasonalGolden);
close(SeasonalHeader);
close(SeasonalUnique);
close(SeasonalQuery);
close(SeeMore);
close(SEORedirect);
close(Sharing);
close(Steals);
close(QuickDetails);


#####
## close out files (crawl)
close(AllRequest_crawl);
close(BrowseHeader_crawl);
close(CommURL_crawl);
close(GridHeader_crawl);
close(ProductRedirect_crawl);
close(SearchHeader_crawl);
close(SearchFilter_crawl);
close(SearchRelatedLink_crawl);
close(SEORedirect_crawl);

exit 0;

############################################################################################################
############################################################################################################
############################################################################################################

sub crawl_imp {

  $ImpRow=@_[0];
  ($Server, $ImpType, $Imp) = split(/\|/, $ImpRow, 3);
  $WholeImp = "$ImpType|$Imp";
  @col = split(/\|/, $Imp);
  
  switch ($ImpType) {
    case "headerRow" {
      print AllRequest_crawl "$ImpRow\n";
      if (@col[31]) {
        print CommURL_crawl "@col[0]|@col[1]|@col[3]|@col[11]|@col[31]|@col[7]|@col[28]|@col[15]|@col[6]\n";
      }
    }
    case "search.SearchResponse" {
      if (@col[31] eq 'HEADER') {
        print SearchHeader_crawl "$WholeImp\n";
      }
      elsif (@col[31] eq 'SELECTED_FILTER') {
        print SearchFilter_crawl "$WholeImp\n";
      }
      elsif (@col[31] eq 'relatedSearchLink') {
        print SearchRelatedLink_crawl "$Imp\n";
      }
    }
    case "ComparisonGrid2Response" {
      if (@col[25] eq 'HEADER') {
        print GridHeader_crawl "$Imp\n";
      }
    }
    case ["microsite.MicrositeBrowsePageResponse","microsite.BrowsePageResponse","browse.BrowsePageResponse"] {
      if (@col[15] eq 'HEADER') {
        print BrowseHeader_crawl "$WholeImp"."false|0|0|0|0|0\n";
      }
    }
    case "community.browse.BrowsePageResponse" {
      if (@col[15] eq 'HEADER') {
        print BrowseHeader_crawl "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|||@col[22]|@col[16]|@col[17]|@col[18]|@col[19]|@col[20]|@col[21]\n";
      }
    }
    case "ProductRedirectionResponse" {
      print ProductRedirect_crawl "$Imp\n";
    }
    case "CustomSEORedirectResponse" {
      print SEORedirect_crawl "$WholeImp\n";
    }
  } ## END switch($ImpType)
}

############################################################################################################
############################################################################################################
############################################################################################################

sub user_imp {

  $ImpRow=@_[0];
  ($Server, $ImpType, $Imp) = split(/\|/, $ImpRow, 3);
  $WholeImp = "$ImpType|$Imp";
  @col = split(/\|/, $Imp);
  
  switch ($ImpType) {
    case "headerRow" {
      print AllRequest "$ImpRow\n";
      if (@col[30]) {
        print FullReferrer "@col[0]|@col[1]|@col[3]|@col[5]|@col[6]|@col[7]|@col[11]|@col[12]|@col[13]|@col[15]|@col[28]|@col[29]|@col[30]\n";
      }
      if (@col[31]) {
        print CommURL "@col[0]|@col[1]|@col[3]|@col[11]|@col[31]|@col[7]|@col[28]|@col[15]|@col[22]|@col[13]\n";
      }
    }
    case "search.SearchResponse" {      
      if (@col[31] eq 'HEADER') {
        print SearchHeader "$WholeImp\n";
      }
      elsif (@col[31] eq 'steal') {
        print Steals "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[32]|@col[34]|@col[37]|@col[39]|@col[40]|@col[24]|@col[43]\n";
      }
      elsif (@col[31] =~ /relatedSearchProducts/) {
        if (@col[33] eq 'SoloProduct') {
          print SearchRelUnique "$WholeImp\n";
        }
        elsif (@col[33] eq 'GoldenProduct') {
          print SearchRelGolden "$WholeImp\n";
        }
      }
      elsif (@col[31] eq 'relatedSearchLink') {
        print SearchRelatedLink "$Imp\n";
      }
      elsif (@col[33] eq 'SoloProduct') {
#        if (@col[31] eq 'productList') {
#          print SearchUnique "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|@col[18]|@col[19]|@col[20]|@col[21]|@col[22]|@col[23]|@col[24]|@col[25]|@col[26]|@col[27]|@col[28]|@col[29]|@col[30]|@col[31]|@col[32]|@col[33]|@col[34]|@col[35]|@col[36]|@col[37]|@col[38]|@col[39]|@col[40]|@col[42]|@col[43]\n";
#        } else {
          print SearchUnique "$WholeImp\n";
#        }
      }
      elsif (@col[33] eq 'GoldenProduct') {
#        if (@col[31] eq 'productList') {
#          print SearchGolden "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|@col[18]|@col[19]|@col[20]|@col[21]|@col[22]|@col[23]|@col[24]|@col[25]|@col[26]|@col[27]|@col[28]|@col[29]|@col[30]|@col[31]|@col[32]|@col[33]|@col[34]|@col[35]|@col[36]|@col[37]|@col[38]|@col[39]|@col[41]|@col[42]|@col[43]\n";
#        } else {
          print SearchGolden "$WholeImp\n";
#        }
      }
      elsif (@col[31] eq 'adword') {
        #print Adword "@col[2]|$ImpType|@col[15]|@col[32]|@col[1]|@col[0]\n";
        print Adword "@col[2]|@col[50]|@col[15]|@col[32]|@col[1]|@col[0]\n";
      }
      elsif (@col[31] eq 'adwordtop') {
        #print Adword "@col[2]|$ImpType|@col[15]|@col[32]|@col[1]|@col[0]|top\n";
        print Adword "@col[2]|@col[50]|@col[15]|@col[32]|@col[1]|@col[0]|top\n";
      }
      elsif (@col[31] eq 'adwordbottom') {
        #print Adword "@col[2]|$ImpType|@col[15]|@col[32]|@col[1]|@col[0]|bottom\n";
        print Adword "@col[2]|@col[50]|@col[15]|@col[32]|@col[1]|@col[0]|bottom\n";
      }
      elsif (@col[31] eq 'SELECTED_FILTER') {
        print SearchFilter "$WholeImp\n";
      }
      elsif (@col[31] eq 'RELATED_SEARCH') {
        print SearchRelated "$WholeImp\n";
      }
      elsif (@col[31] eq 'AccessoryModule_Listing') {
        print SearchAccMod "$WholeImp\n";
      }
      elsif (@col[31] eq 'ALTERNATIVE_QUERY')
      {}
      elsif (@col[31] eq 'OwnerIQ_Pixel') {
        print PixelTracking "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[31]|0|@col[32]||@col[33]|\n";
      }
      else {
        print NoHome "$Server|$ImpType|@col[31]|@col[33]\n";
      }
    }
    case "ComparisonGrid2Response" {      
      if (@col[25] eq 'HEADER') {
        print GridHeader "$Imp\n";
      }
      elsif (@col[27] eq 'SoloProduct') {
        print GridProduct "$Imp\n";
      }
      elsif (@col[25] eq 'adword') {
        print Adword "@col[2]|$ImpType|@col[15]|@col[26]|@col[1]|@col[0]\n";
      }
      elsif(@col[25] eq 'relatedProducts') {
        print GridRelated "$Imp\n";
      }
      elsif (@col[25] eq 'OwnerIQ_Pixel') {
        print PixelTracking "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[25]|0|@col[26]||@col[27]|\n";
      }
      elsif (@col[25] eq 'steal') {
        print Steals "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[26]|@col[30]|@col[31]|@col[33]|@col[27]|@col[28]|cg\n";
      }
      elsif(@col[25] eq 'AccessoryModule_Listing') {
        print GridAccMod "$Imp\n";
      }
      else {
        print NoHome "$Server|$ImpType|@col[25]|@col[27]\n";
      }
    }
    case "SeasonalPageResponse" {
      if (@col[15] eq 'HEADER') {
        print SeasonalHeader "$Imp\n";
      }
      elsif (@col[15] eq 'SEASONAL_QUERY') {
        print SeasonalQuery "$Imp\n";
      }
      elsif (@col[17] eq 'SoloProduct') {
        print SeasonalUnique "$Imp".substr(@col[15],16)."\n";
      }
      elsif (@col[17] eq 'GoldenProduct') {
        print SeasonalGolden "$Imp".substr(@col[15],16)."\n";
      }
    }
    case "ProductSenseResponse" {
      print ProdSense "$Imp\n";
    }
    case "community.ProductProfileReviewsResponse" {
      print GridReviews "$WholeImp\n";
    }
    case "LandingPageResponse" {
      print LandingPage "$WholeImp\n";
    }
    case "community.MyProntoLoggedOutHomePageResponse" {
      print HomepageHeader "$WholeImp"."|0|||false|0|0|0|0\n";
    }
    case "microsite.MicrositeLoggedOutHomePageResponse" {
      if (@col[15] eq 'HEADER') {
        print HomepageHeader "$WholeImp"."false|0|0|0|0\n";
      }
    }
    case ["community.browse.LoggedOutHomePageResponse","community.browse.LoggedInHomePageResponse"] {
      if (@col[15] eq 'HEADER') {
        print HomepageHeader "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]||||@col[16]|@col[17]|@col[18]|@col[19]|@col[20]\n";
      }
    }
    case "microsite.MicrositeLoggedOutHomePage2Response" {
      if (@col[15] eq 'HEADER') {
        print HomepageHeader "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]||@col[16]||false|\n";
      }
    }
    case "microsite.LoggedOutHomePageResponse" {
      if (@col[15] eq 'HEADER') {
        print HomepageHeader "$WholeImp|||false||||\n";
      }
    }
    case "homepage.LoggedOutHomePage2Response" {
      print HomepageHeader "$WholeImp||||false|||\n";
    }
    case "microsite.MicrositeLoggedOutHomePage3Response" {
      print HomepageHeader "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||@col[15]\n";
    }
    case ["microsite.MicrositeBrowsePageResponse","microsite.BrowsePageResponse","browse.BrowsePageResponse"] {
      if (@col[15] eq 'HEADER') {
        print BrowseHeader "$WholeImp"."false|0|0|0|0|0\n";
      }
      elsif (@col[15] eq 'OwnerIQ_Pixel') {
        print PixelTracking "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|0|@col[16]||br|\n";
      }
    }
    case "ProductRedirectionNotFoundResponse" {
      print ProdErr "$WholeImp\n";
    }
    case "community.browse.BrowsePageResponse" {
      if (@col[15] eq 'HEADER') {
        print BrowseHeader "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|||@col[22]|@col[16]|@col[17]|@col[18]|@col[19]|@col[20]|@col[21]\n";
      }
    }    
    case "community.MerchantSearchResponse" {
      if (@col[28] eq 'HEADER') {
        print MerchantSearchHeader "$WholeImp\n";
      }
    }
    case ["microsite.onsale.OnSaleDirectoryResponse","microsite.directory.MerchantDirectoryResponse","microsite.directory.BrandDirectoryResponse"] {
      print MicrositeDirectory "$WholeImp\n";
    }   
    case "community.account.RegisterFormResponse" {
      print RegForm "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[15]|@col[16]|@col[17]|@col[18]\n";
    }
    case "community.account.InPageRegistrationFormResponse" {
      print RegForm "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|@col[18]|@col[19]|@col[20]\n";
    } 
    case "community.account.CompatibilitySurveyStartResponse" {
      @likeitem = split(/_/, @col[21], 2);
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[17]|@col[18]|@col[19]|@col[20]||||||||||@col[16]||||@col[15]\n";
      if (@likeitem) {
        print RFSel "banner|@col[0]|@col[2]|@col[3]|@col[4]|@col[6]|true|@col[20]|@col[17]|@col[18]|@col[19]|@col[16]|@likeitem[0]|@likeitem[1]\n";
      }
    }
    case ["community.account.UnsubscribeResponse","community.account.EditSettingsResponse"] {
      print EmailSettings "$WholeImp\n";
    }
    case "community.account.CampaignSurveyPayoffResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||||||@col[15]||@col[16]|@col[17]|@col[18]\n";
    }
    case "community.account.registration.CompatibilitySurveyEmailEntryInitResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[16]|@col[17]|@col[18]|@col[19]||||||||||@col[15]\n";
    }
    case "community.account.registration.CompatibilitySurveyEmailEntryResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[21]|@col[16]|@col[17]|@col[18]|@col[19]||||||||||@col[15]||||@col[20]\n";
    }
    case "community.account.registration.CompatibilitySurveyPayoffResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[16]|@col[17]|@col[18]|@col[19]||||||||||@col[15]|||||@col[21]|@col[20]\n";
    }
    case "community.account.RegisterResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[16]|@col[17]|@col[18]|@col[19]|@col[20]|||||||||@col[21]\n";
    }
    case "community.account.CompatibilitySurveySkipThisStepResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||||||||@col[16]|||[@col[15]\n";
    }
    case "community.account.CompatibilitySurveyBrandPreferencesInitResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[16]|@col[17]|@col[18]|@col[19]||||||||||@col[15]\n";
    }
    case "community.account.CompatibilitySurveyBrandPreferencesResponse" {
      @likeitem = split(/_/, @col[23], 2);
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[17]|@col[19]|@col[20]|@col[21]|@col[22]||@col[15]|@col[16]|||||||@col[18]\n";
      if (@likeitem) {
        print RFSel "brand_sel|@col[0]|@col[2]|@col[3]|@col[4]|@col[6]|@col[17]|@col[22]|@col[19]|@col[20]|@col[21]|@col[18]|@likeitem[0]|@likeitem[1]\n";
      }
    }
    case "community.AddRecommendationPreferencesResponse" {
      @likeitem = split(/_/, @col[23], 2);
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[16]|@col[17]|@col[18]|@col[19]||||||||||@col[15]\n";
      if (@likeitem) {
        print RFSel "add_rec|@col[0]|@col[2]|@col[3]|@col[4]|@col[6]||@col[15]|@col[16]|@col[17]|@col[18]|@col[19]|@likeitem[0]|@likeitem[1]\n";
      }
    } 
    case "community.account.CompatibilitySurveyProductRatingsInitResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||||||||@col[15]\n";
    }
    case "community.account.CompatibilitySurveyProductRatingsResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||@col[15]||||||@col[16]\n";
    }
    case "community.account.CampaignSurveyInterstitialResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||||||||@col[15]\n";
    }
    case "community.account.CampaignSurveyResultsResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||||||||@col[15]|@col[16]|@col[17]\n";
    }
    case "community.account.CampaignSurveyShowResultsResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||||||||@col[18]|@col[19]|@col[20]\n";
    }
    case "community.account.CompatibilitySurveyProfileSurveyInitResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]\n";
    }
    case "community.account.CompatibilitySurveyProfileSurveyResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||||||||||@col[15]|@col[16]\n";
    }
    case "community.account.CompatibilitySurveyImportContactsInitResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||||||||||||@col[15]|||@col[16]\n";
    }
    case "community.account.CompatibilitySurveyImportContactsResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||||||||||||@col[19]|@col[18]||@col[20]|\n";
    }
    case "community.account.CompatibilitySurveyInviteContactsResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||||||||||||||@col[18]|@col[19]|\n";
    }
    case "community.account.EmailVerificationResponse" {
      print NewReg "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[17]|@col[18]|@col[19]|@col[20]\n";
    }
    case "community.account.LoginResponse" {
      print Login "@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[16]|$ImpType|@col[15]\n";
    }
    case "community.account.LogoutResponse" {
      print Login "@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|$ImpType|\n";
    }
    case "guides.BuyingGuideIndexResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]\n";
    }
    case "guides.BuyingGuideOverviewResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]\n";
    }
    case "guides.BuyingGuidePrintResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|||||@col[17]\n";
    }
    case "guides.BuyingGuideDetailResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]\n";
    }
    case "community.guides.BuyingGuideEmailInitResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]\n";
    }
    case "community.guides.BuyingGuideEmailResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]\n";
    }
    case "community.guides.BuyingGuideTipResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|||@col[16]\n";
    }
    case "community.guides.BuyingGuideTipRetractionResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]\n";
    }
    case "community.guides.BuyingGuideTipsResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]\n";
    }
    case "community.guides.BuyingGuideUserTipFeedbackResponse" {
      print BuyingGuide "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|||@col[16]|@col[17]|@col[18]\n";
    }    
    case "community.UserProfileResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|@col[18]|@col[19]|@col[20]|@col[21]|@col[22]|||||||||||||@col[3]\n";
    }
    case "community.UserProfileWallResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||||||||||||||@col[3]\n";
    }
    case "community.ProfileDisplayProductsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|@col[18]|@col[19]|@col[24]|@col[21]|@col[22]|||||||||||||@col[3]\n";
    }
    case "community.friends.UserProfileFriendRequestsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||@col[18]||||||||||||@col[3]\n";
    }
    case "community.ProfileMessageInboxResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|||||||@col[18]|||||||||||@col[3]\n";
    }
    case "community.account.UpdateAccountResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||||||||||||||@col[3]\n";
    }
    case "community.BaseUserProfileResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||||||||||||||@col[3]\n";
    }
    case "community.account.ProfileSurveyResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[16]|@col[15]|@col[17]||||||||||||||||||@col[3]\n";
    }
    case "community.friends.FriendsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||@col[18]||||||||||||@col[3]\n";
    }
    case "community.friends.InviteFriendsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||||@col[18]||||||||||@col[3]\n";
    }
    case "community.friends.InviteFriendsInitResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]\n";
    }
    case "community.friends.ImportContactsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|||||||||@col[19]|@col[18]\n";
    }
    case "community.friends.SelectContactsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||||||||||||||@col[3]\n";
    }
    case "community.UserProfileOverviewResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|||@col[18]|||||||||||||||@col[3]\n";
    }
    case "community.UserProfileListsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||||||||||||@col[18]||@col[3]\n";
    }
    case "community.UserProfileListResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|||||||||||||||@col[18]|@col[19]|@col[20]|@col[3]|@col[21]\n";
    }
    case "community.UserProfileRatingsAndReviewsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|@col[19]||@col[18]||||||||@col[20]|@col[21]|@col[22]|@col[23]||||@col[3]\n";
    }
    case "community.UserProfileRatingsAndReviewsSuggestionsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|||@col[20]|@col[18]|@col[19]||||||||||||@col[3]\n";
    }
    case "community.UserProfileRecommendationPreferencesInitResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]||||||||||||||||||@col[3]||@col[18]\n";
    }
    case "community.UserProfileRecommendationPreferencesResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|||||||||||||||||||||@col[3]|||@col[15]|@col[16]\n";
    }
    case "community.contest.UserProfileContestEntryResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|||||||||||||||||@col[3]\n";
    }
    case "community.UserProfileRecommendationsResponse" {
      print Profile "$ImpType|@col[2]|@col[1]|@col[0]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|||@col[18]|||||||||||||||@col[3]\n";
    }
    case ["community.ProductEmailInitResponse","community.MuzeDataProductResponse","community.ProductProfileWebReviewsResponse"] {
      print ProdTab "$WholeImp\n";
    }
    case ["community.MerchantProfileResponse","community.MerchantLocationsFormResponse"] {
      print MerchantTab "$WholeImp\n";
    }
    case "community.BrandOverviewResponse" {
###      print BrandHeader "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[6]|@col[10]|@col[11]|@col[12]|@col[14]|@col[15]|@col[16]|\n";
      print BrandHeader "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[6]|@col[10]|@col[11]|@col[12]|@col[14]|@col[15]||\n";
    }
    case "community.BrandSearchResponse" {
      if (@col[29] eq 'HEADER') {
        print BrandHeader "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[6]|@col[10]|@col[11]|@col[12]|@col[14]|||@col[31]\n";
      }
    }
    case "community.BrandProfileResponse" {
      print BrandTab "$WholeImp\n";
    }
    case "community.lists.FindListsResponse" {
      print ListSearch "$WholeImp\n";
    }
    case ["lists.CreateListResponse","lists.RemoveListResponse","lists.EditListResponse","lists.CopyListResponse"] {
      print ListEvent "$WholeImp\n";
    }    
    case ["community.SendToFriendInitResponse","community.SendToFriendEmailResponse"] {
      print ListSend "$WholeImp\n";
    }
    case "lists.AddToListResponse" {
      print AddToList "$WholeImp\n";
    }
    case "lists.RemoveFromListResponse" {
      print RemoveFromList "$WholeImp\n";
    }
    case ["community.ItemReviewResponse","community.ItemReviewShowDialogResponse"] {
      print ItemReview "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[15]|@col[16]|@col[17]|@col[18]|@col[19]|@col[20]|@col[21]|@col[22]|@col[23]|@col[25]|@col[26]|@col[27]|@col[28]\n";
    }
    case ["local.LocalStoresBrowseResponse","local.LocalProductsBrowseResponse"] {
      print BrowseLocal "$WholeImp\n";
    }
    case "local.LocalProductsBrowseStateResponse" {
      print BrowseLocal "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]||@col[15]\n";
    }
    case "local.LocalProductsBrowseMarketResponse" {
      print BrowseLocal "$ImpType|@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[16]||@col[15]\n";
    }
    case "community.MerchantLocationsResponse" {
      print LocalMerchant "$WholeImp\n";
    }
    case "community.MerchantLocationDetailResponse" {
      print LocalMerchantDetail "$WholeImp\n";
    }
    case "local.LocalProductsListResponse" {
      print LocalProd "$WholeImp\n";
    }
    case "AffiliateSearchRedirectionResponse" {
      print Affiliate "$ImpType|@col[0]|@col[2]|@col[16]|@col[17]|@col[18]|@col[15]|@col[19]|@col[6]\n"; 
    } 
    case "AffiliateRedirectionResponse" {
      print Affiliate "$ImpType|@col[0]|@col[2]|@col[15]|@col[16]|@col[17]||@col[18]|@col[6]\n";
    }
    case "community.ProductEmailResponse" {
      print ProdEmail "$WholeImp\n";
    }
    case "community.message.ComposeMessageShowDialogResponse" {
      print MsgDialog "$Imp\n";
    }
    case "community.message.SendMessageResponse" {
      print MsgSent "$WholeImp\n";
    }
    case "community.friends.RequestFriendShowDialogResponse" {
      print FriendDialog "$Imp\n";
    }
    case "community.friends.RequestFriendResponse" {
      print FriendSent "$WholeImp\n";
    }
    case "community.friends.RespondToFriendRequestResponse" {
      print FriendAccept "$WholeImp\n";
    }
    case "community.account.UserAccountResponse" {
      print FriendResponse "$ImpType|@col[0]|@col[1]|@col[2]|@col[15]|@col[4]||@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]\n";
    }
    case "community.account.InitInvitationRegistrationResponse" {
      print FriendResponse "$ImpType|@col[0]|@col[1]|@col[2]|@col[15]|@col[4]||@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]\n";
    }
    case "GenericRedirectionResponse" {
      print GenericRedirect "@col[0]|@col[2]|@col[15]\n";
    }
    case "ProductRedirectionResponse" {
      switch (@col[26]) {
        case "MOBILE-WEB" {
          print ProductRedirectMBL "$Imp\n";
          print AllRequestMBL "$Imp\n";
        }
        else {
          print ProductRedirect "$Imp\n";
        }
      }
    }
    case ["RedirectionResponse","AdWordRedirectionResponse"] {
      print AdwordClick "@col[0]|@col[1]|@col[2]|@col[3]|@col[4]|@col[5]|@col[6]|@col[7]|@col[8]|@col[9]|@col[10]|@col[11]|@col[12]|@col[13]|@col[14]|@col[16]|@col[17]|@col[19]|@col[18]|@col[20]|@col[21]\n";
    }
    case ["netpromoterscore.NPSScoreSubmissionResponse","netpromoterscore.NPSCloseSurveyResponse"] {
      print NPS "$WholeImp\n";
    }
    case ["lightboxrefresh.LightBoxRefreshPromptResponse","lightboxrefresh.LightBoxRefreshResultsResponse"] {
      print LightboxRefresh "$WholeImp\n";
    }
    case "CustomSEORedirectResponse" {
      print SEORedirect "$WholeImp\n";
    }
    case "steals.StealSharingResponse" {
      print Sharing "$WholeImp\n";
    }
    case "SeeMoreProductInfoResponse" {
      print SeeMore "$Imp\n";
    }
    case "LogBrandImplantClickResponse" {
      print LogoCampClick "$WholeImp\n";
    }
    case "search.ForcedNoResultsSearchResponse" {
      print SearchForcedNR "$WholeImp\n";
    }
    case "QuickDetailsResponse" {
      print QuickDetails "$WholeImp\n";
    }
    case 
     ["PAPI"
     ,"InfographicsResponse"
     ,"MediaInquiryResponse"
     ,"ContactPrivacyOfficerResponse"
     ,"EmailPixelResponse"
     ,"community.brandormerchant.BrandOutlineResponse"
     ,"community.brandormerchant.MerchantOutlineResponse"
     ,"community.account.RemoveWishListResponse"
     ,"community.account.RemoveWishListItemResponse"
     ,"community.UserProfileWishListPreferencesInitResponse"
     ,"community.account.AddWishListItemResponse"
     ,"AdvertiseWithUsResponse"
     ,"NotFoundResponse"
     ,"microsite.offers.StorePromoTextsResponse"
     ,"steals.StealsListPageSharingResponse"
     ,"PartnerWithUsResponse"
     ,"microsite.offers.StorePromoTextResponse"
     ,"LoginRequiredResponse"
     ,"community.admin.AdminCacheStatusResponse"
     ,"TopSellersResponse"
     ,"community.account.RemoveAllSaleAlertsFormResponse"
     ,"community.account.RemoveAllSaleAlertsResponse"
     ,"SponsoredPageResponse" 
     ,"microsite.offers.MerchantOffersResponse"
     ,"ListViwerResponse"
     ,"community.account.AddSaleAlertFormResponse"
     ,"community.UserProfileSaleAlertPreferencesInitResponse"
     ,"community.account.AddSaleAlertResponse"
     ,"community.account.RemoveSaleAlertFormResponse"
     ,"community.account.RemoveSaleAlertResponse"
     ,"facebook.FacebookLikeResponse"
     ,"BackToTopScrollerClickResponse"
     ,"FlyInPageCloseResponse"
     ,"TwitterInterstitialResponse"
     ,"browse.BrowseSubTreeViewResponse"
     ,"NewsletterSliderResponse"
     ,"search.ProductsOnlySearchResponse"
     ,"trackingpixel.PermutoTrackingPixelResponse"
     ,"trackingpixel.TimingPixelTrackingResponse"
     ,"community.contest.ContestCommentResponse"
     ,"lists.DeleteListFeedbackResponse"
     ,"community.support.ReportContentResponse"
     ,"community.contest.ContestVoteResponse"
     ,"lists.ReserveListItemResponse"
     ,"promotion.BankOfAmericaWaysToSaveResponse"
     ,"report.SimpleReportResponse"
     ,"promotion.BestBuyHolidayResponse"
     ,"lists.DeleteListCommentResponse"
     ,"community.admin.AdminAssumeUserIdentityResponse"
     ,"community.admin.AdminHomePageResponse"
     ,"lists.PostListCommentResponse"
     ,"community.admin.AdminCacheStatusResponse"
     ."community.admin.AdminHomePageResponse"
     ,"ajax.PayoffDataAjaxResponse"
     ,"community.account.EditSettingsInitResponse"
     ,"community.account.UnsubscribeInitResponse"
     ,"community.UserImageDeletionResponse"
     ,"community.ReviewFeedbackResponse"
     ,"community.captcha.CaptchaValidationResponse"
     ,"community.contest.ContestSeeAllEntriesResponse"
     ,"promotion.HomeDepotHolidayShoppingDealsResponse"
     ,"report.NumProdsInNonLeafOrOtherFormResponse"
     ,"report.NumProductsInNonLeafOrOtherResponse"
     ,"community.message.DeleteMessageResponse"
     ,"community.friends.SelectFriendsShowDialogResponse"
     ,"community.contest.ContestOverviewResponse"
     ,"community.account.ManageEmailNotificationsResponse"
     ,"bookmarklet.BookmarkInsUpdResponse"
     ,"community.friends.ImportContactsInitResponse"
     ,"community.ProductProfileViewAllTagsResponse"
     ,"community.UserProfileNoRatingsAndReviewsResponse"
     ,"lists.UpdateListItemResponse"
     ,"lists.WishListReservationShowDialogResponse"
     ,"ProdRedirExitInterstitialResponse"
     ,"search.AnalyzedSearchInterceptResponse"
     ,"search.MicrositeSearchInterceptResponse"
     ,"community.account.ManageEmailNotificationsInitResponse"
     ,"bookmarklet.BookmarkletAddDialogResponse"
     ,"FeedbackResponse"
     ,"xml.LiteModelAvailResponse"
     ,"community.UserImageDisplayResponse"
     ,"community.account.ForgotPasswordResponse"
     ,"community.account.LoginFormResponse"
     ,"community.account.ResetPasswordResponse"
     ,"community.account.UpdatePasswordResponse"
     ,"community.async.IsValidResponse"
     ,"community.BaseUserProfileProductResponse"
     ,"community.BrandOnSaleResponse"
     ,"community.friends.FindFriendsResponse"
     ,"community.MerchantOnSaleResponse"
     ,"community.MerchantOverviewResponse"
     ,"community.MerchantStoreProfileResponse"
     ,"community.ProductAsynchDataRetrievalResponse"
     ,"community.ProductSpecsResponse"
     ,"community.UserProfileUserTipsResponse"
     ,"lists.AddToListShowDialogResponse"
     ,"lists.ListFeedbackResponse"
     ,"LoadingMessageResponse"
     ,"MerchantRedirectionResponse"
     ,"microsite.sitemap.BrandsSiteMapResponse"
     ,"microsite.sitemap.CategoriesSiteMapResponse"
     ,"microsite.sitemap.SearchesSiteMapResponse"
     ,"microsite.sitemap.SiteMapResponse"
     ,"ProductReviewRedirectionResponse"
     ,"search.ViewAllFiltersResponse"
     ,"sitemap.SiteMapResponse"
     ,"sitemap.SiteMapTopSearchesResponse"
     ,"LoadingMessageResponse"
     ,"ajax.BrowseCategoriesResponse"
     ,"monitor.HealthCheckResponse"
     ,"AjaxLogEventResponse"
     ,"sitemap.SiteMapFeaturesResponse"
     ,"MediaContactUsResponse"]
    { }
    else {
      print NoHome "$Server|$ImpType\n";
    }
  } ## END switch($ImpType)
}

############################################################################################################
############################################################################################################
############################################################################################################

sub bot_testing {

  foreach ($ind = 0; $ind < @bot; $ind++) {
    my $botname = lc(@bot[$ind]);
    if (index(@_[0], $botname) >= 0) {
      return 1;
    }
  }
  return 0;
}

############################################################################################################
############################################################################################################
############################################################################################################

sub get_imp_files { 
  
  #####
  ## clear out previous hours impressions
  if ($istest == 0) {
    system "rm $infile";
    system "touch $infile";
  }
  system "rm $NoFile";
  system "rm $filecheck";
  system "touch $filecheck";
  system "touch $filecheck_all";
  system "echo '#########################' >> $filecheck";
  system "echo '/redcarpet/log/impressions.log.$year-$mon-$mday-$hour' >> $filecheck";
  system "echo `/bin/date '+%m/%d/%Y %H:%M:%S'` >> $filecheck";
  

  #####
  ## variable declaration
  my $sl;
  my $servername;
  my @slarr1;
  my @slarr2;
  my $i;
  my $record;
  my @imp_request;
  my $filesfound=0;
  my $dwfile;
  my $checkfile;
  my $wwwfile = "/redcarpet/log/impressions.log.$year-$mon-$mday-$hour";
  my $missingfiles = "$logdir/missing_imp_files.log";
  my $s;
  my @server_list=split(/\|/, $serverlist);
  my $filesexpected=@server_list;
  
  
  #####
  ## get each file on server_list
  if ($istest == 0) {
     foreach $s (@server_list) {
     if ($s !~ /^\*/) {
     
      ## gzip the file on the www server
      system "ssh tomcat\@$s 'gzip -f $wwwfile'";
     
      ## name the DW file
      $dwfile = "$datadir/impressions.$s.log";
      system "rm -f $dwfile";
       
      ## scp the file   
      system "echo \"scp -C tomcat\@$s:$wwwfile.gz $dwfile.gz\" >> $filecheck";
      system "scp -C tomcat\@$s:$wwwfile.gz $dwfile.gz";
      if ($? != 0) { 
       system "sleep 10"; 
       system "echo \"scp -C tomcat\@$s:$wwwfile.gz $dwfile.gz\" >> $filecheck";
       system "scp -C tomcat\@$s:$wwwfile.gz $dwfile.gz"; 
       if ($? != 0) {
        system "echo \"scp -C tomcat\@$s:$wwwfile $dwfile\" >> $filecheck";
        system "scp -C tomcat\@$s:$wwwfile $dwfile"; 
        if ($? != 0) {
         system "sleep 10";
         system "echo \"scp -C tomcat\@$s:$wwwfile $dwfile\" >> $filecheck";
         system "scp -C tomcat\@$s:$wwwfile $dwfile"; 
          if ($? != 0) {
            system "echo '$s:$wwwfile not found!' >> $NoFile";
      }}}}
     
      ## gunzip the file
      system "gunzip -f $dwfile.gz";
     
      ## cat this file to the infile
      system "sed 's/^/$s\|/' $dwfile >> $infile";
     }}
  }
  
  
  system "echo `/bin/date '+%m/%d/%Y %H:%M:%S'` >> $filecheck";
  system "ls -ltrh $datadir/impressions.www* >> $filecheck";
  if ($istest == 0) {
    system "cat $filecheck >> $filecheck_all";
  }
}




