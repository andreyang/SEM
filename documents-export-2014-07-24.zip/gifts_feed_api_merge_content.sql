spool /home/dw/ayang/Log/GiftsFeedAPICMerge.log

/**
--remove header rows
delete from  stg.google_ad_api_c_daily_gifts t
where clicks > (select 0.49*sum(clicks) from  stg.google_ad_api_c_daily_gifts
where customerid = t.customerid
)
;
commit;
**/

drop table ay_temp_g_account_c_gifts;
create table ay_temp_g_account_c_gifts tablespace stage_temp_data nologging as
select distinct clientid, lower(accountname) accountname, accountid
from titan.account@be1
where searchengine = 'Google'
;
commit;

analyze table ay_temp_g_account_c_gifts compute statistics
;

insert into stg.google_ad_api_c_imp_gifts
(
clickdate,
AdGroup,
AdGroupId,
AdWordsType,
AdGroupStatus,
BottomPosition,
DailyBudget,
CampaignStatus,
Campaign,
CampaignId,
Clicks,
Cost,
Cpc,
CreativeStatus,
CreativeType,
CreativeVisionURL,
CreativeId,
Ctr,
DescriptionLine1,
DescriptionLine2,
DestinationUrl,
DescriptionLine3,
Impressions,
Keyword,
MinimumCpc,
KeywordId,
KeywordDestinationUrl,
KeywordStatus,
KeywordType,
MaxContentCPC,
MaximumCpc,
PageViewCount,
AveragePosition,
TopPosition,
AccountName,
qualityscore,
customerid,
accountid
) 
select 
startdate,
AdGroup,
AdGroupId,
AdWordsType,
AdGroupStatus,
BottomPosition,
DailyBudget,
CampaignStatus,
Campaign,
CampaignId,
Clicks,
Cost,
Cpc,
CreativeStatus,
CreativeType,
CreativeVisionURL,
CreativeId,
Ctr,
DescriptionLine1,
DescriptionLine2,
DestinationUrl,
DescriptionLine3,
Impressions,
Keyword,
MinimumCpc,
KeywordId,
KeywordDestinationUrl,
KeywordStatus,
KeywordType,
MaxContentCPC,
MaximumCpc,
PageViewCount,
AveragePosition,
TopPosition,
a.AccountName,
qualityscore,
customerid,
accountid
from stg.google_ad_api_c_daily_gifts ad, ay_temp_g_account_c_gifts a
where ad.customerid = a.clientid(+)
;

commit;

insert into stg.GOOGLE_AD_API_CONTENT_GIFTS
(
ADGROUP   ,             
ADGROUPID   ,           
ADWORDSTYPE  ,          
ADGROUPSTATUS   ,       
BOTTOMPOSITION   ,      
DAILYBUDGET      ,      
CAMPAIGNSTATUS    ,     
CAMPAIGN        ,       
CAMPAIGNID      ,       
CLICKS       ,          
COST           ,        
CPC          ,          
CREATIVESTATUS    ,     
CREATIVETYPE        ,   
CREATIVEVISIONURL     , 
CREATIVEID             ,
CTR                    ,
DESCRIPTIONLINE1       ,
DESCRIPTIONLINE2       ,
DESTINATIONURL         ,
DESCRIPTIONLINE3       ,
IMPRESSIONS            ,
KEYWORD                ,
MINIMUMCPC             ,
KEYWORDID              ,
--KEYWORDDESTINATIONURL  ,
KEYWORDSTATUS          ,
KEYWORDTYPE            ,
MAXCONTENTCPC          ,
MAXIMUMCPC             ,
PAGEVIEWCOUNT          ,
AVERAGEPOSITION        ,
TOPPOSITION            ,
ACCOUNTNAME            ,
CLICKDATE,
qualityscore,
customerid,
accountid      
)
select ADGROUP   ,             
ADGROUPID   ,           
ADWORDSTYPE  ,          
ADGROUPSTATUS   ,       
BOTTOMPOSITION   ,      
DAILYBUDGET      ,      
CAMPAIGNSTATUS    ,     
CAMPAIGN        ,       
CAMPAIGNID      ,       
CLICKS       ,          
COST           ,        
CPC             ,       
CREATIVESTATUS    ,     
CREATIVETYPE        ,   
CREATIVEVISIONURL     , 
CREATIVEID             ,
CTR                    ,
DESCRIPTIONLINE1       ,
DESCRIPTIONLINE2       ,
DESTINATIONURL         ,
DESCRIPTIONLINE3       ,
IMPRESSIONS            ,
KEYWORD                ,
MINIMUMCPC             ,
KEYWORDID              ,
--KEYWORDDESTINATIONURL  ,
KEYWORDSTATUS          ,
KEYWORDTYPE            ,
MAXCONTENTCPC          ,
MAXIMUMCPC             ,
PAGEVIEWCOUNT          ,
AVERAGEPOSITION        ,
TOPPOSITION            ,
ACCOUNTNAME            ,
CLICKDATE,
qualityscore,
customerid,
accountid  
from stg.google_ad_api_c_imp_gifts
where clickdate = to_date('&1', 'yyyy-mm-dd')
and (clicks <> 0 or cost <> 0)
;

commit;

truncate table stg.google_ad_api_c_daily_gifts
;

spool off

quit

