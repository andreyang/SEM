drop table ay_temp_google_click2;
create table ay_temp_google_click2 nologging as
select distinct * from 
(select  adid,
        adgroupid,
        campaignid,
        keywordid,
        customerid,
        keyword,
        maximumcpc/1000000 maximumcpc,
        minimumcpc/1000000 minimumcpc,
        averageposition pos,
        keywordtype,
	qualityscore,
        RANK() OVER (PARTITION BY adid ORDER BY clickdate desc, keyword, keywordid, adgroupid, campaignid, network, creativeid, keywordtype) rk
from stg.google_ad_api_imp t
where clickdate >= trunc(sysdate)  - 14
and clickdate < trunc(sysdate)
--and adid not like '%d-%'
--and adid not like '%-bmx%'
--and (lower(keyword) like '%halloween%' or lower(keyword) like '%costume%')
--and (lower(keyword) like '%fleece%' or lower(keyword) like '%scarf%' or lower(keyword) like '%scarves%' and lower(keyword) like '%coat%' or lower(keyword) like '%jacket%' or lower(keyword) like '%vest%' or lower(keyword) like '%glove%' or lower(keyword) like '%mitten%' or lower(keyword) like '%boot%' or lower(keyword) like '%flannel%' or lower(keyword) like '%hoodie%' or lower(keyword) like '%turtleneck%' or lower(keyword) like '%sweater%' or lower(keyword) like '%thermal%' or lower(keyword) like '%parka%' or lower(keyword) like '%snowsuit%' or lower(keyword) like '%cardigan%' or lower(keyword) like '%hats%' or lower(keyword) like '%beanies%')
)
where rk = 1
;

create table ay_temp_google_bid_history nologging as
select distinct adid from stg.google_bid_history
where createddate >= trunc(sysdate)  - 28
;

create unique index ay_temp_google_bid_hist$adid on ay_temp_google_bid_history (adid)
;
/**
create table ay_temp_gs_ds_as_adid nologging as
select adid
from stg.comm_search_header
where timestamp2 >= trunc(sysdate)  - 14
and timestamp2 < trunc(sysdate) 
and adid like '%gs'
group by adid
having (max(pagetype) = min(pagetype))
and max(pagetype) in ('ds', 'as')
;
**/

drop table ay_temp_google_click purge;
create table ay_temp_google_click nologging as
select t.* from ay_temp_google_click2 t--, ay_temp_gs_ds_as_adid t2
where /**t.adid = t2.adid
and**/ not exists (select * from ay_temp_google_bid_history where adid = t.adid)
;

drop table ay_temp_google_click2 purge;
drop table ay_temp_google_bid_history purge;

create table ay_temp_google_click2 nologging as
select c.adid
from 	(select ad.adid, sum(cost/1000000) cost, sum(clicks) clicks
	from stg.google_ad_api ad, ay_temp_google_click t
	where ad.adid = t.adid
	and clickdate >= trunc(sysdate)  - 14
        and clickdate < trunc(sysdate)
	group by ad.adid) c, 
	(select adid, sum(rev) rev
	from (select ad.adid, sum(cpc) rev from dw.merchant_lead ad, ay_temp_google_click t
        where ad.adid = t.adid
        and clickdate >= trunc(sysdate)  - 14
        and clickdate < trunc(sysdate)
	and isdup = 'n'
	group by ad.adid
	union all
	select ad.adid, sum(nvl(cpc_actual, cpc)*numclick) rev from dw.adword_adid ad, ay_temp_google_click t
        where ad.adid = t.adid
        and clickdate >= trunc(sysdate)  - 14
        and clickdate < trunc(sysdate)
	group by ad.adid
	)
	group by adid
	) r
where c.adid = r.adid(+)
and nvl(r.rev,0) < c.cost
--and c.clicks >= 2
;

/**
drop table ay_temp_google_click3 purge;
create table ay_temp_google_click3 nologging as
select ad.adid
from dw.merchant_lead ad
where clickdate >= trunc(sysdate)  - 14
and clickdate < trunc(sysdate)
and isdup = 'n'
and siteid = 1
and adid like '%gs'
and productsourceid = 20
group by ad.adid
;
**/

set heading off
set linesize 300
set trimspool on
spool /home/dw/ayang/Log/bids.google.raise.imp.txt

select
        to_char(t.customerid)||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
	least(round((1+greatest(/**decode(t3.adid, NULL, .15, .25)**/ .15, (pos-5)/20))*t.maximumcpc, 2), .75)||'|'|| --t.minimumcpc||'|'|| 
        lower(substr(t.keywordtype, 0, 1))||'|'||
        t.adid||'|'||
        to_char(t.campaignid)||'|'||
	t.keyword
from ay_temp_google_click t--, ay_temp_google_click3 t3
where /**t.adid = t3.adid(+)
and**/ t.pos > 5 
and t.qualityscore >= 5
and least(round((1+greatest(/**decode(t3.adid, NULL, .15, .25)**/ .15, (pos-5)/20))*t.maximumcpc, 2), .75) > t.maximumcpc
and not exists (select * from ay_temp_google_click2 where adid = t.adid)
;
spool off

drop table ay_temp_google_click purge;
drop table ay_temp_google_click2 purge;

quit
