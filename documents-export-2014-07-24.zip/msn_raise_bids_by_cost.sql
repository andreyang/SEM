--on dw
drop table ay_temp_msn_bid_history purge;
create table ay_temp_msn_bid_history nologging as
select distinct adid
from stg.msn_bid_history
where createddate >= trunc(sysdate) - 28
;

drop table ay_temp_msn_click purge;
create table ay_temp_msn_click nologging as
select distinct * from
(select  adid,
        orderid adgroupid,
        campaignid,
        orderitemid keywordid,
        account accountid,
        lower(keyword) keyword,
        currentmaximumcpc maximumcpc,
        avgpos pos,
        deliveredmatchtype keywordtype,
        RANK() OVER (PARTITION BY orderitemid, orderid, deliveredmatchtype, campaignid, account ORDER BY clickdate desc, adid, avgpos, msnadid, distchannel) rk
from stg.msn_ad_api_imp t
where clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate)
and campaign not like '%antconc_results%'
--and adid not like '%bmx%'
--and adid not like '%d-%'
--and (lower(keyword) like '%halloween%' or lower(keyword) like '%costume%')
--and (lower(keyword) like '%fleece%' or lower(keyword) like '%scarf%' or lower(keyword) like '%scarves%' and lower(keyword) like '%coat%' or lower(keyword) like '%jacket%' or lower(keyword) like '%vest%' or lower(keyword) like '%glove%' or lower(keyword) like '%mitten%' or lower(keyword) like '%boot%' or lower(keyword) like '%flannel%' or lower(keyword) like '%hoodie%' or lower(keyword) like '%turtleneck%' or lower(keyword) like '%sweater%' or lower(keyword) like '%thermal%' or lower(keyword) like '%parka%' or lower(keyword) like '%snowsuit%' or lower(keyword) like '%cardigan%' or lower(keyword) like '%hats%' or lower(keyword) like '%beanies%')
) ad
where rk = 1
and not exists (select * from ay_temp_msn_bid_history where adid = ad.adid)
;

drop table ay_temp_msn_click2 purge;
create table ay_temp_msn_click2 nologging as
select c.adid, rev, cost, click
from 	(select ad.adid, sum(clicks) click, sum(totalcost) cost
	from stg.msn_ad_api ad, ay_temp_msn_click t
	where ad.adid = t.adid
	and clickdate >= trunc(sysdate) - 28
        and clickdate < trunc(sysdate)
	group by ad.adid) c,
	(select adid, sum(rev) rev
	from (select ad.adid, sum(cpc) rev from dw.merchant_lead ad, ay_temp_msn_click t
        where ad.adid = t.adid
        and clickdate >= trunc(sysdate) - 28
        and clickdate < trunc(sysdate)
	and isdup = 'n'
	group by ad.adid
	union all
	select ad.adid, sum(nvl(cpc_actual, cpc)*numclick) rev from dw.adword_adid ad, ay_temp_msn_click t
        where ad.adid = t.adid
        and clickdate >= trunc(sysdate) - 28
        and clickdate < trunc(sysdate)
	group by ad.adid
	)
	group by adid
	) r
where c.adid = r.adid(+)
--and c.click >= 2
and nvl(rev, 0) < cost
;

drop table ay_temp_msn_click3 purge;
create table ay_temp_msn_click3 nologging as
select adid, sum(imp) imp
from stg.msn_ad_api_imp
where clickdate >= trunc(sysdate) - 28
group by adid
having sum(clicks) < 10
;

set heading off
set linesize 300
set trimspool on
spool /home/dw/ayang/Log/bids.msn.raise.txt

select  distinct
        to_char(accountid)||'|'||
        to_char(adgroupid)||'|'||
        to_char(keywordid)||'|'||
        least(round((1+greatest(.2, (nvl(pos, 10)-4)/20))*maximumcpc, 2), .5)||'|'||
        lower(substr(keywordtype, 1, 1))||'|'||
        t.adid||'|'||
        to_char(campaignid)
from ay_temp_msn_click t, ay_temp_msn_click3 t2
where t.adid = t2.adid
and nvl(t.pos, 10) >= 4
and t2.imp < 10
--and t2.imp >= 10
and least(round((1+greatest(.2, (nvl(pos, 10)-4)/20))*maximumcpc, 2), .5) > maximumcpc
and not exists (select * from ay_temp_msn_click2 where adid = t.adid)
and not exists (select * from ay_temp_msn_bid_history where adid = t.adid)
;
spool off

drop table ay_temp_msn_raise_adid purge;
create table ay_temp_msn_raise_adid nologging as
select distinct t.adid
from ay_temp_msn_click t, ay_temp_msn_click3 t2
where t.adid = t2.adid
and nvl(t.pos, 10) > 4
and t2.imp >= 10
and least(round((1+least(.15, (nvl(pos, 10)-4)/20))*maximumcpc, 2), .5) > maximumcpc
and not exists (select * from ay_temp_msn_click2 where adid = t.adid)
;

drop table ay_temp_msn_click purge;
drop table ay_temp_msn_click2 purge;
drop table ay_temp_msn_click3 purge;
quit
