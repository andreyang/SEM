spool /home/dw/ayang/Log/bids_msn.log

drop table ay_temp_msn_kwid purge;

create table ay_temp_msn_kwid tablespace stage_temp_data nologging as
select distinct
	adid, 
	mexpcategoryid,
	prontoadgroupid,
	adgroup, 
	adgroupid, 
	campaign,
	campaignid,
	keywordid,
   	accountname,
   	keyword,
	case when lower(keyword) like '%halloween%' or lower(keyword) like '%costume%' 
	then 'y' else 'n' end seasonal_flag,
	--'n' seasonal_flag,
	--case when clickdate >= trunc(sysdate) - 2 then maximumcpc else null end maximumcpc,
	maximumcpc,
	averageposition,
	creativeid,
--	keyworddestinationurl,
   	keywordtype,
	clickdate
from (
select 	adid, 
	REGEXP_REPLACE(adid,'s[[:digit:]]{1,4}-([[:digit:]]{1,6})-.*','\1') mexpcategoryid,
	REGEXP_REPLACE(adid,'-[[:digit:]]{1,6}_m.*s', '') prontoadgroupid,
	ordername adgroup, 
	orderid adgroupid, 
	campaign,
   	campaignid,
   	orderitemid keywordid,
   	account accountname,
   	keyword,
   	currentmaximumcpc maximumcpc,
   	avgpos averageposition,
   	msnadid creativeid,
--  	destinationurl keyworddestinationurl,
   	lower(substr(nvl(bidmatchtype,deliveredmatchtype), 1, 1)) keywordtype,
	clickdate,
   	RANK() OVER (PARTITION BY orderitemid, orderid, nvl(bidmatchtype,deliveredmatchtype), campaignid, account ORDER BY clickdate desc, adid, avgpos, msnadid, distchannel) rk
from stg.msn_ad_api 
where --if there was no activity in the past 7 days, why do we need to make bid change as there is no new info?
clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
--MT migration finished on August 25, 2012.
and clickdate >= '27-Aug-2012'
and clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
and adid is not null
and clicks > 0
) 
where rk = 1
;

drop table ay_temp_hv_msn_cost1 purge;

create table ay_temp_hv_msn_cost1 tablespace stage_temp_data nologging as
select 	adid, sum(totalcost) cost, sum(clicks) clicks, 
	sum(Imp) impressions
from stg.msn_ad_api
where clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate) and clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
--and account = 94853
and adid is not null
group by adid
having sum(clicks) >= 25
;

drop table ay_temp_hv_msn_rev1 purge;

create table ay_temp_hv_msn_rev1 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, 1.0*rev1 rev, ml1 ml, 0 ad_lead
from ay_temp_hv_msn_cost1 t, dw.merchant_lead_bid_pronto ml
where t.adid = ml.adid
union all
select t.adid, 1.0*rev1, 0, ad_lead1 ad_lead
from ay_temp_hv_msn_cost1 t, dw.adword_adid_bid_pronto ad
where t.adid = ad.adid
/**
union all
--cap logo campaign's comtribution to 10 cents
select t.adid, least(.05,sum(imps)/1000*6/min(t.clicks))*min(t.clicks), 0, 0
from ay_temp_hv_msn_cost1 t, dw.logo_campaign l
where t.adid = l.adid
and clickdate >= trunc(sysdate) - 7
and clickdate < trunc(sysdate)
group by t.adid
union all
--data not refreshed until 15:00
--cap rpc from cpm at .05
select t.adid, least(sum(revenue), .05*avg(clicks)), 0, 0
from dw.cpm_adid ad, ay_temp_hv_msn_cost1 t, 
--make sure that cpm did not totally disappear
(select adid from dw.cpm_adid where clickdate >= trunc(sysdate) - 3 group by adid having sum(revenue) > 0) t2
where t.adid = ad.adid
and ad.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 7 - 1
and ad.clickdate < trunc(sysdate) - 1
group by t.adid
union all
select t.adid, sum(guidestercpc), 0, 0
from dw.guidester_grid ad, ay_temp_hv_msn_cost1 t,
--make sure that guidester feed did not disappear
(select distinct goldenproductid from stg.guidester_product_feed where clickdate >= trunc(sysdate)) t2
where t.adid = ad.adid
and ad.goldenproductid = t2.goldenproductid
and ad.clickdate >= trunc(sysdate) - 7
and ad.clickdate < trunc(sysdate) and  ad.clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
group by t.adid
**/
)
group by adid
;

drop table ay_temp_msn_bids1 purge;

--SEASONAL KEYWORD'S BIDS ARE CONTROLLED BY THE NUMBER AFTER y.
create table ay_temp_msn_bids1 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t1.adid like '%mbs' then .9 else 1 end)*(case when t1.clicks/t1.impressions >= .01 and t1.adid not like '%d-__m_s' then 1.0 else 1 end)*decode(t4.margin_target, null, (case when t.averageposition >= 6 then 1.0 else .950 end), t4.margin_target)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.keywordtype,
	t1.clicks
from ay_temp_msn_kwid t, ay_temp_hv_msn_cost1 t1, ay_temp_hv_msn_rev1 t2, stg.seasonal_campaign t3, stg.break_even_pool t4
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t.campaignid = t3.campaignid(+)
and   t1.adid = t4.adid(+)
and   (t1.clicks >= 50 or (nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) <= 0.2))
;

drop table ay_temp_hv_msn_cost4 purge;

create table ay_temp_hv_msn_cost4 tablespace stage_temp_data nologging as
select  adid, sum(totalcost) cost, sum(clicks) clicks,
        sum(Imp) impressions
from stg.msn_ad_api
where clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate) and clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
--and account = 94853
and adid is not null
group by adid
having sum(clicks) >= 10
;

drop table ay_temp_hv_msn_rev4 purge;

create table ay_temp_hv_msn_rev4 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, 1.0*rev4 rev, ml4 ml, 0 ad_lead
from ay_temp_hv_msn_cost4 t, dw.merchant_lead_bid_pronto ml
where t.adid = ml.adid
union all
select t.adid, 1.0*rev4, 0, ad_lead4 ad_lead
from ay_temp_hv_msn_cost4 t, dw.adword_adid_bid_pronto ad
where t.adid = ad.adid
/**
union all
--cap logo campaign's comtribution to 10 cents
select t.adid, least(.05,sum(imps)/1000*6/min(t.clicks))*min(t.clicks), 0, 0
from ay_temp_hv_msn_cost4 t, dw.logo_campaign l
where t.adid = l.adid
and clickdate >= trunc(sysdate) - 28
and clickdate < trunc(sysdate)
group by t.adid
union all
--data not refreshed until 15:00
select t.adid, least(sum(revenue), .05*avg(clicks)), 0, 0
from dw.cpm_adid ad, ay_temp_hv_msn_cost4 t, 
(select adid from dw.cpm_adid where clickdate >= trunc(sysdate) - 3 group by adid having sum(revenue) > 0) t2
where t.adid = ad.adid
and ad.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 28 - 1
and ad.clickdate < trunc(sysdate) - 1
group by t.adid
union all
select t.adid, sum(guidestercpc), 0, 0
from dw.guidester_grid ad, ay_temp_hv_msn_cost4 t,
--make sure that guidester feed did not disappear
(select distinct goldenproductid from stg.guidester_product_feed where clickdate >= trunc(sysdate)) t2
where t.adid = ad.adid
and ad.goldenproductid = t2.goldenproductid
and ad.clickdate >= trunc(sysdate) - 28
and ad.clickdate < trunc(sysdate) and  ad.clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
group by t.adid
**/
)
group by adid
;

drop table ay_temp_msn_bids4 purge;

create table ay_temp_msn_bids4 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t1.adid like '%mbs' then .9 else 1 end)*(case when t1.clicks/t1.impressions >= .01 and t1.adid not like '%d-__m_s' then 1.0 else 1 end)*decode(t4.margin_target, null, (case when t.averageposition >= 6 then 1.0 else .950 end), t4.margin_target)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.keywordtype,
        t1.clicks
from ay_temp_msn_kwid t, ay_temp_hv_msn_cost4 t1, ay_temp_hv_msn_rev4 t2, stg.seasonal_campaign t3, stg.break_even_pool t4
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t1.adid = t4.adid(+)
and   t.campaignid = t3.campaignid(+)
;

drop table ay_temp_hv_msn_cost8 purge;

create table ay_temp_hv_msn_cost8 tablespace stage_temp_data nologging as
select  adid, sum(totalcost) cost, sum(clicks) clicks,
        sum(Imp) impressions, max(orderid) adgroupid, max(campaignid) campaignid
from stg.msn_ad_api
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) and clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
--and account = 94853
and adid is not null
group by adid
having sum(clicks) >= 10
;

drop table ay_temp_hv_msn_rev8 purge;

create table ay_temp_hv_msn_rev8 tablespace stage_temp_data nologging as
select adid, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adid, 1.0*rev8 rev, ml8 ml, 0 ad_lead
from ay_temp_hv_msn_cost8 t, dw.merchant_lead_bid_pronto ml
where t.adid = ml.adid
union all
select t.adid, 1.0*rev8, 0, ad_lead8 ad_lead
from ay_temp_hv_msn_cost8 t, dw.adword_adid_bid_pronto ad
where t.adid = ad.adid
/**
union all
--cap logo campaign's comtribution to 10 cents
select t.adid, least(.05,sum(imps)/1000*6/min(t.clicks))*min(t.clicks), 0, 0
from ay_temp_hv_msn_cost8 t, dw.logo_campaign l
where t.adid = l.adid
and clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate)
group by t.adid
union all
--data not refreshed until 15:00
select t.adid, least(sum(revenue), .05*avg(clicks)), 0, 0
from dw.cpm_adid ad, ay_temp_hv_msn_cost8 t, 
(select adid from dw.cpm_adid where clickdate >= trunc(sysdate) - 3 group by adid having sum(revenue) > 0) t2
where t.adid = ad.adid
and ad.adid = t2.adid
and ad.clickdate >= trunc(sysdate) - 56 - 1
and ad.clickdate < trunc(sysdate) - 1
group by t.adid
union all
select t.adid, sum(guidestercpc), 0, 0
from dw.guidester_grid ad, ay_temp_hv_msn_cost8 t,
--make sure that guidester feed did not disappear
(select distinct goldenproductid from stg.guidester_product_feed where clickdate >= trunc(sysdate)) t2
where t.adid = ad.adid
and ad.goldenproductid = t2.goldenproductid
and ad.clickdate >= trunc(sysdate) - 56
and ad.clickdate < trunc(sysdate) and  ad.clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
group by t.adid
**/
)
group by adid
;

drop table ay_temp_msn_bids8 purge;

create table ay_temp_msn_bids8 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t1.adid like '%mbs' then .9 else 1 end)*(case when t1.clicks/t1.impressions >= .01 and t1.adid not like '%d-__m_s' then 1.0 else 1 end)*decode(t4.margin_target, null, (case when t.averageposition >= 6 then 1.0 else .950 end), t4.margin_target)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t3.campaignid, null, decode(t.seasonal_flag, 'y', 1, 1), 1) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
        t.keywordtype,
        t1.clicks
from ay_temp_msn_kwid t, ay_temp_hv_msn_cost8 t1, ay_temp_hv_msn_rev8 t2, stg.seasonal_campaign t3, stg.break_even_pool t4
where t1.adid = t.adid
and   t1.adid = t2.adid(+)
and   t1.adid = t4.adid(+)
and   t.campaignid = t3.campaignid(+)
;

/**
drop table stg.msn_bmx_adgroup purge;
create table stg.msn_bmx_adgroup tablespace stage_temp_data nologging as
select distinct adgroupid, campaignid
from titan.keyword@be1
where adid like '%bmx%m_s'
and businessname = 'pronto.com'
;
analyze table stg.msn_bmx_adgroup compute statistics;
**/

drop table ay_temp_hv_grp_msn_cost8 purge;
--Alvin's optimization
create table ay_temp_hv_grp_msn_cost8 tablespace stage_temp_data nologging as
select adid,
       orderid adgroupid,
       campaignid,
       account accountname,
       sum(totalcost) cost,
       sum(clicks) clicks,
       sum(imp) impressions
from (select adid,
      orderid,
      campaignid,
      account,
      clicks,
      totalcost,
      imp,
      sum(clicks) over(partition by orderid, campaignid, account) sum_clicks
      from stg.msn_ad_api ad
      where clickdate >= trunc(sysdate) - 28
      and clickdate < trunc(sysdate) and clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
      --and account = 94853
      and adid is not null
--for adgroups with BMX keywords, exclude contribution from keywords under management
      and not exists (select * from ay_temp_hv_msn_cost8 c, stg.msn_bmx_adgroup g
			where c.adgroupid = g.adgroupid
			and c.campaignid = g.campaignid
			and c.adid = ad.adid)
	)
where sum_clicks >= 20
group by adid, orderid, campaignid, account
;

/**
select  adid, orderid adgroupid, campaignid, account accountname, sum(totalcost) cost, sum(clicks) clicks,
        sum(Imp) impressions
from stg.msn_ad_api
where clickdate >= trunc(sysdate) - 56
and clickdate < trunc(sysdate) and clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
--and account = 94853
and adid is not null
and (orderid, campaignid, account) IN 
	(select orderid, campaignid, account from stg.msn_ad_api
	where clickdate >= trunc(sysdate) - 56
	and clickdate < trunc(sysdate) and clickdate not IN ('12-Jun-2012', '30-Jun-2012', '18-Jul-2012')
	--and account = 94853
	and adid is not null
	group by orderid, campaignid, account
	having sum(clicks) >= 25
	)
group by adid, orderid, campaignid, account;
**/

--when the same adid is in multiple adgroups, revenue is allocated evenly
analyze table ay_temp_hv_grp_msn_cost8 compute statistics;

drop table ay_temp_hv_grp_msn_rev8 purge;
create table ay_temp_hv_grp_msn_rev8 tablespace stage_temp_data nologging as
select adgroupid, campaignid, accountname, sum(rev) revenue, sum(ml) ml, sum(ad_lead) adlead
from
(
select t.adgroupid, t.campaignid, t.accountname, sum(1.0*rev4*t.clicks/t2.clicks) rev, sum(ml4*t.clicks/t2.clicks) ml, 0 ad_lead
from ay_temp_hv_grp_msn_cost8 t, (select adid, sum(clicks) clicks from ay_temp_hv_grp_msn_cost8 group by adid ) t2, dw.merchant_lead_bid_pronto ml
where t.adid = ml.adid
and t.adid = t2.adid
group by t.adgroupid, t.campaignid, t.accountname
union all
select t.adgroupid, t.campaignid, t.accountname, sum(1.0*rev4*t.clicks/t2.clicks), 0 ml, sum(ad_lead4*t.clicks/t2.clicks) ad_lead
from ay_temp_hv_grp_msn_cost8 t, (select adid, sum(clicks) clicks from ay_temp_hv_grp_msn_cost8 group by adid ) t2, dw.adword_adid_bid_pronto ad
where t.adid = ad.adid
and t.adid = t2.adid
group by t.adgroupid, t.campaignid, t.accountname
)
group by adgroupid, campaignid, accountname
;

drop table ay_temp_grp_msn_bids8 purge;
create table ay_temp_grp_msn_bids8 tablespace stage_temp_data nologging as
select distinct
        t.accountname,
        t.campaign,
        t.campaignid,
        t.adgroup,
        t.prontoadgroupid,
        t.adgroupid,
        t.keywordid,
	t.maximumcpc,
        t.adid,
        trunc(least(0.85, (case when t.averageposition >= 6 then 1.0 else .950 end)*nvl(t2.revenue,0.01)/t1.clicks), 2)*decode(t.seasonal_flag, 'y', 1, 1)*(case when t.adid like '%_mbs' then .8 when t.adid like '%_mps' then .9 else 1 end) rpc,
        nvl(nvl(t2.revenue, 0)/decode(t1.cost, 0, null, t1.cost), 0) roi,
        t.averageposition,
        t.keyword,
	t.keywordtype,
        t1.clicks
from ay_temp_msn_kwid t, (select adgroupid, campaignid, accountname, sum(cost) cost, sum(clicks) clicks from ay_temp_hv_grp_msn_cost8 group by adgroupid, campaignid, accountname) t1, ay_temp_hv_grp_msn_rev8 t2
where t1.adgroupid = t.adgroupid
and   t1.campaignid = t.campaignid
and   t1.accountname = t.accountname
and   t1.adgroupid = t2.adgroupid(+)
and   t1.campaignid = t2.campaignid(+)
and   t1.accountname = t2.accountname(+)
;

drop table ay_temp_msn_bids_final purge;

create table ay_temp_msn_bids_final tablespace stage_temp_data nologging as
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(t.rpc, nvl(1.3*t.maximumcpc, t.rpc)) rpc,
        roi,
        averageposition,
        keyword,
        keywordtype,
        'HV -  25' type,
	clicks,
        case when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) > round(maximumcpc,2) then 'i'
                when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) < round(maximumcpc,2) then 'd'
                else 'u' end ischange
from ay_temp_msn_bids1 t
where (roi < 1/.950 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
union all
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(t.rpc, nvl(1.3*t.maximumcpc, t.rpc)) rpc,
	roi,
        averageposition,
        keyword,
        keywordtype,
        'HV - 10 - 4wk' type,
	clicks,
        case when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) > round(maximumcpc,2) then 'i'
                when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) < round(maximumcpc,2) then 'd'
                else 'u' end ischange
from ay_temp_msn_bids4 t
where (roi < 1/.950 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
and not exists (select * from ay_temp_msn_bids1
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
union all
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(t.rpc, nvl(1.3*t.maximumcpc, t.rpc)) rpc,
	roi,
        averageposition,
        keyword,
        keywordtype,
        'HV - 10 - 8wk' type,
	clicks,
        case when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) > round(maximumcpc,2) then 'i'
                when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) < round(maximumcpc,2) then 'd'
                else 'u' end ischange
from ay_temp_msn_bids8 t
where (roi < 1/.950 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
and not exists (select * from ay_temp_msn_bids1
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_msn_bids4
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
union all
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        least(t.rpc, nvl(1.3*t.maximumcpc, t.rpc)) rpc,
	roi,
        averageposition,
        keyword,
        keywordtype,
        'HV - adgrp20' type,
	clicks,
        case when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) > round(maximumcpc,2) then 'i'
                when round(least(rpc, nvl(1.3*maximumcpc, rpc)),2) < round(maximumcpc,2) then 'd'
                else 'u' end ischange
from ay_temp_grp_msn_bids8 t
where (roi < 1/.950 or averageposition > 3 or rpc < nvl(maximumcpc, 0))
--and rpc >= 0.05
and not exists (select * from ay_temp_msn_bids1
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_msn_bids4
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
and not exists (select * from ay_temp_msn_bids8
        where keywordid = t.keywordid
        and keywordtype = t.keywordtype
        and adgroupid = t.adgroupid
        and campaignid = t.campaignid
        and accountname = t.accountname
)
;
spool off

set heading off
set trimspool on
set linesize 300

spool &1
--/home/dw/ayang/Log/bids_msn.txt

select distinct
	t.accountname||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
        --case when t.adid like '%mbs' and t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0) < .01 then 0 else greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 'TUESDAY', 1.0, 1.0), 0.05) end||'|'||
	trunc(greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0), 0.05), 2)||'|'||
	t.keywordtype||'|'||
        t.adid||'|'||
        to_char(t.campaignid)
from ay_temp_msn_bids_final t
where exists (select avg(rpc) from ay_temp_msn_bids_final having avg(rpc) < .4)
;

spool off

spool &2

/**
--/home/dw/ayang/Log/bids_msn_0.txt

select distinct
        t.accountname||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
        0||'|'||
        t.keywordtype||'|'||
        t.adid||'|'||
        to_char(t.campaignid)
from ay_temp_msn_bids_final t
where rpc <= .01
and clicks >= 20
and exists (select avg(rpc) from ay_temp_msn_bids_final having avg(rpc) < .4 and avg(rpc) > .1)
;
**/

select distinct
	t.accountname||'|'||
        t.campaign||'|'||
        to_char(t.campaignid)||'|'||
        t.adgroup||'|'||
        to_char(t.adgroupid)||'|'||
        to_char(t.keywordid)||'|'||
        t.adid||'|'||
        t.keyword||'|'||
        t.keywordtype
from ay_temp_msn_bids_final t
where exists (select avg(rpc) from ay_temp_msn_bids_final having avg(rpc) < .4 and avg(rpc) >  .1 )
and rpc <= .01
and clicks >= 20
and  type <> 'HV - adgrp20'
;

spool off

insert into stg.msn_bid_history
(
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        rpc,
        roi,
        averageposition,
        keyword,
	keywordtype,
        type,
	ischange
)
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        --trunc(case when t.adid like '%mbs' and t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0) < .01 then 0 else greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 'TUESDAY', 1.0, 1.0), 0.05) end, 2),
        trunc(greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0), 0.05), 2),
	roi,
        averageposition,
        keyword,
	keywordtype,
        type,
	ischange
from ay_temp_msn_bids_final t
where exists (select avg(rpc) from ay_temp_msn_bids_final having avg(rpc) < .4)
union all
select distinct
        accountname,
        campaign,
        campaignid,
        adgroup,
        prontoadgroupid,
        adgroupid,
        keywordid,
        adid,
        --trunc(case when t.adid like '%mbs' and t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0) < .01 then 0 else greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.0, 'TUESDAY', 1.0, 1.0), 0.05) end, 2),
        trunc(greatest(t.rpc*decode(trim(to_char(sysdate, 'DAY')), 'SATURDAY', 1.0, 'SUNDAY', 1.05, 'MONDAY', 1.1, 1.0), 0.05), 2),
	roi,
        averageposition,
        keyword,
        keywordtype,
        'deleted', 
	NULL
from ay_temp_msn_bids_final t
where exists (select avg(rpc) from ay_temp_msn_bids_final having avg(rpc) < .4 and avg(rpc) >  .1 )
and rpc < .01
and clicks >= 20
and  type <> 'HV - adgrp20'
/**
and not exists (select * from stg.msn_bid_history tt
        where tt.keywordid = t.keywordid
        and tt.adgroupid = t.adgroupid
        and tt.campaignid = t.campaignid
        and tt.keywordtype = t.keywordtype
        and tt.accountname = t.accountname
        and tt.createddate >= trunc(sysdate) - 1
        and tt.type = 'deleted')
and not exists (select * from ay_temp_msn_bids_final tt
        where tt.keywordid = t.keywordid
        and tt.adgroupid = t.adgroupid
        and tt.campaignid = t.campaignid
        and tt.accountname = t.accountname
        and tt.rpc >= .1
	and tt.clicks >= 20)
**/
;

--drop table ay_temp_msn_kwid purge;
drop table ay_temp_hv_msn_cost1 purge;
drop table ay_temp_hv_msn_rev1 purge;
drop table ay_temp_msn_bids1 purge;
drop table ay_temp_hv_msn_cost4 purge;
drop table ay_temp_hv_msn_rev4 purge;
drop table ay_temp_msn_bids4 purge;
drop table ay_temp_hv_msn_cost8 purge;
drop table ay_temp_hv_msn_rev8 purge;
drop table ay_temp_msn_bids8 purge;
drop table ay_temp_hv_grp_msn_cost8 purge;
drop table ay_temp_hv_grp_msn_rev8 purge;
drop table ay_temp_grp_msn_bids8 purge;
drop table ay_temp_msn_bids_final purge;

quit;

